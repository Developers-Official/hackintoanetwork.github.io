#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int beta_pro();
int main()
{
    int f, e, d=0, c=0;

    while(d+c<5){
        f=beta_pro();
        scanf("%d", &e);
    if(e==f){
        printf("정답\n\n");
        d++;
    }
    else{
        printf("오답\n\n");
        c++;
    }
    }

    printf("정답 : %d개 오답 : %d개\n", d, c);
    if(d==5){
        printf("오~천재시군요!!\n");
    }
    return 0;
}
int beta_pro(){
    char h;
    int i, input;
    srand(time(NULL));
    int k=rand()%31;
    int s=rand()%41;
    int g=rand()%3;
    if(g==0){
        h='*';
        i=k*s;
    }
    else if(g==1){
        h='-';
        i=k-s;
    }
    else{
        h='+';
        i=k+s;
    }
    printf("%d%c%d=",k,h,s);
    return i;
}