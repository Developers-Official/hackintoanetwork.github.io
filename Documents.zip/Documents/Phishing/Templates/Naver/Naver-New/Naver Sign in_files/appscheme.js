!function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typeof define&&define.amd?define("sofa",[],t):"object"==typeof exports?exports.sofa=t():e.sofa=t()}("undefined"!=typeof self?self:this,function(){return function(e){function t(r){if(n[r])return n[r].exports;var o=n[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,t),o.l=!0,o.exports}var n={};return t.m=e,t.c=n,t.d=function(e,n,r){t.o(e,n)||Object.defineProperty(e,n,{configurable:!1,enumerable:!0,get:r})},t.n=function(e){var n=e&&e.__esModule?function(){return e["default"]}:function(){return e};return t.d(n,"a",n),n},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="",t(t.s=47)}([function(e,t,n){"use strict";t.__esModule=!0,t["default"]=function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}},function(e,t){var n=e.exports="undefined"!=typeof window&&window.Math==Math?window:"undefined"!=typeof self&&self.Math==Math?self:Function("return this")();"number"==typeof __g&&(__g=n)},function(e,t){var n={}.hasOwnProperty;e.exports=function(e,t){return n.call(e,t)}},function(e,t,n){"use strict";function r(e){for(var t=arguments.length,n=Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];return n.length&&(0,c.forEach)(n,function(t){for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n])}),e}function o(){var e=arguments.length>0&&arguments[0]!==undefined?arguments[0]:[],t=arguments[1];(0,c.forEach)(e,function(e){t[e]=l(t[e],t)})}function i(){return f||(f=document.documentElement||document.body),f}function a(e,t){try{return e()}catch(n){return u["default"].set(t||{},n)}}t.__esModule=!0,t.removeEventListener=t.addEventListener=t.bind=undefined,t.objectAssign=r,t.bindAll=o,t.getDocumentElement=i,t.runErrorSafe=a;var s=n(33),u=function(e){return e&&e.__esModule?e:{"default":e}}(s),c=n(10),l=t.bind=function(){return Function.prototype.bind?function(e){for(var t=arguments.length,n=Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];return e.bind.apply(e,n)}:function(e,t){for(var n=arguments.length,r=Array(n>2?n-2:0),o=2;o<n;o++)r[o-2]=arguments[o];var i=[].concat(r);return function(){for(var n=arguments.length,r=Array(n),o=0;o<n;o++)r[o]=arguments[o];return e.apply(t,i.concat([].concat(r||[])))}}}(),f=null;t.addEventListener=function(){if(document.addEventListener){var e=!1;try{var t=Object.defineProperty({},"passive",{get:function(){e=!0}});window.addEventListener("test",null,t)}catch(n){}return function(t,n,o,i){var a=!1;return e&&i&&(a=r({capture:!1,passive:!1,once:!1},i)),t.addEventListener(n,o,a)}}return function(e,t,n){return e.attachEvent("on"+t,n)}}(),t.removeEventListener=function(){return document.removeEventListener?function(e,t,n){return e.removeEventListener(t,n,!1)}:function(e,t,n){return e.detachEvent("on"+t,n)}}()},function(e,t,n){var r=n(5),o=n(15);e.exports=n(7)?function(e,t,n){return r.f(e,t,o(1,n))}:function(e,t,n){return e[t]=n,e}},function(e,t,n){var r=n(12),o=n(38),i=n(22),a=Object.defineProperty;t.f=n(7)?Object.defineProperty:function(e,t,n){if(r(e),t=i(t,!0),r(n),o)try{return a(e,t,n)}catch(s){}if("get"in n||"set"in n)throw TypeError("Accessors not supported!");return"value"in n&&(e[t]=n.value),e}},function(e,t){e.exports=function(e){return"object"==typeof e?null!==e:"function"==typeof e}},function(e,t,n){e.exports=!n(14)(function(){return 7!=Object.defineProperty({},"a",{get:function(){return 7}}).a})},function(e,t,n){var r=n(56),o=n(20);e.exports=function(e){return r(o(e))}},function(e,t,n){var r=n(27)("wks"),o=n(16),i=n(1).Symbol,a="function"==typeof i;(e.exports=function(e){return r[e]||(r[e]=a&&i[e]||(a?i:o)("Symbol."+e))}).store=r},function(e,t,n){"use strict";function r(e){for(var t=arguments.length>1&&arguments[1]!==undefined?arguments[1]:function(){},n=0,r=e.length;n<r;n++)t(e[n],n,e)}function o(e){for(var t=arguments.length>1&&arguments[1]!==undefined?arguments[1]:function(){},n=[],r=0,o=e.length;r<o;r++)n[r]=t(e[r],r,e);return n}function i(e,t,n){for(var r=-1,o=n||0,i=e.length;o<i;o++)if(e[o]===t){r=o;break}return r}t.__esModule=!0,t.forEach=r,t.map=o,t.indexOf=i},function(e,t){var n=e.exports={version:"2.5.5"};"number"==typeof __e&&(__e=n)},function(e,t,n){var r=n(6);e.exports=function(e){if(!r(e))throw TypeError(e+" is not an object!");return e}},function(e,t,n){var r=n(1),o=n(11),i=n(37),a=n(4),s=n(2),u=function(e,t,n){var c,l,f,d=e&u.F,h=e&u.G,p=e&u.S,g=e&u.P,_=e&u.B,y=e&u.W,m=h?o:o[t]||(o[t]={}),v=m.prototype,w=h?r:p?r[t]:(r[t]||{}).prototype;h&&(n=t);for(c in n)(l=!d&&w&&w[c]!==undefined)&&s(m,c)||(f=l?w[c]:n[c],m[c]=h&&"function"!=typeof w[c]?n[c]:_&&l?i(f,r):y&&w[c]==f?function(e){var t=function(t,n,r){if(this instanceof e){switch(arguments.length){case 0:return new e;case 1:return new e(t);case 2:return new e(t,n)}return new e(t,n,r)}return e.apply(this,arguments)};return t.prototype=e.prototype,t}(f):g&&"function"==typeof f?i(Function.call,f):f,g&&((m.virtual||(m.virtual={}))[c]=f,e&u.R&&v&&!v[c]&&a(v,c,f)))};u.F=1,u.G=2,u.S=4,u.P=8,u.B=16,u.W=32,u.U=64,u.R=128,e.exports=u},function(e,t){e.exports=function(e){try{return!!e()}catch(t){return!0}}},function(e,t){e.exports=function(e,t){return{enumerable:!(1&e),configurable:!(2&e),writable:!(4&e),value:t}}},function(e,t){var n=0,r=Math.random();e.exports=function(e){return"Symbol(".concat(e===undefined?"":e,")_",(++n+r).toString(36))}},function(e,t,n){"use strict";function r(e){return window.JSON?window.JSON.stringify(e):"IE7 and older are not supported"}t.__esModule=!0,t.stringify=r},function(e,t,n){"use strict";function r(e){return e&&e.__esModule?e:{"default":e}}t.__esModule=!0;var o=n(49),i=r(o),a=n(67),s=r(a),u="function"==typeof s["default"]&&"symbol"==typeof i["default"]?function(e){return typeof e}:function(e){return e&&"function"==typeof s["default"]&&e.constructor===s["default"]&&e!==s["default"].prototype?"symbol":typeof e};t["default"]="function"==typeof s["default"]&&"symbol"===u(i["default"])?function(e){return void 0===e?"undefined":u(e)}:function(e){return e&&"function"==typeof s["default"]&&e.constructor===s["default"]&&e!==s["default"].prototype?"symbol":void 0===e?"undefined":u(e)}},function(e,t){var n=Math.ceil,r=Math.floor;e.exports=function(e){return isNaN(e=+e)?0:(e>0?r:n)(e)}},function(e,t){e.exports=function(e){if(e==undefined)throw TypeError("Can't call method on  "+e);return e}},function(e,t){e.exports=!0},function(e,t,n){var r=n(6);e.exports=function(e,t){if(!r(e))return e;var n,o;if(t&&"function"==typeof(n=e.toString)&&!r(o=n.call(e)))return o;if("function"==typeof(n=e.valueOf)&&!r(o=n.call(e)))return o;if(!t&&"function"==typeof(n=e.toString)&&!r(o=n.call(e)))return o;throw TypeError("Can't convert object to primitive value")}},function(e,t){e.exports={}},function(e,t,n){var r=n(12),o=n(55),i=n(28),a=n(26)("IE_PROTO"),s=function(){},u=function(){var e,t=n(39)("iframe"),r=i.length;for(t.style.display="none",n(60).appendChild(t),t.src="javascript:",e=t.contentWindow.document,e.open(),e.write("<script>document.F=Object<\/script>"),e.close(),u=e.F;r--;)delete u.prototype[i[r]];return u()};e.exports=Object.create||function(e,t){var n;return null!==e?(s.prototype=r(e),n=new s,s.prototype=null,n[a]=e):n=u(),t===undefined?n:o(n,t)}},function(e,t,n){var r=n(41),o=n(28);e.exports=Object.keys||function(e){return r(e,o)}},function(e,t,n){var r=n(27)("keys"),o=n(16);e.exports=function(e){return r[e]||(r[e]=o(e))}},function(e,t,n){var r=n(1),o=r["__core-js_shared__"]||(r["__core-js_shared__"]={});e.exports=function(e){return o[e]||(o[e]={})}},function(e,t){e.exports="constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",")},function(e,t,n){var r=n(5).f,o=n(2),i=n(9)("toStringTag");e.exports=function(e,t,n){e&&!o(e=n?e:e.prototype,i)&&r(e,i,{configurable:!0,value:t})}},function(e,t,n){t.f=n(9)},function(e,t,n){var r=n(1),o=n(11),i=n(21),a=n(30),s=n(5).f;e.exports=function(e){var t=o.Symbol||(o.Symbol=i?{}:r.Symbol||{});"_"==e.charAt(0)||e in t||s(t,e,{value:a.f(e)})}},function(e,t){t.f={}.propertyIsEnumerable},function(e,t,n){"use strict";function r(e){return e&&e.__esModule?e:{"default":e}}function o(e){return e?u["default"].compressToEncodedURIComponent(e):""}t.__esModule=!0,t.ERROR_PREFIX=undefined;var i=n(0),a=r(i),s=n(34),u=r(s),c=n(17),l=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t["default"]=e,t}(c),f=null,d="WhatAreYouLookingFor|",h=(t.ERROR_PREFIX=d,function(){function e(){(0,a["default"])(this,e)}return e.set=function(t,n){if(f)return e;var r=void 0,o={};"string"==typeof t?r=t:(r=t.location||"",o=t.properties||{});try{o=l.stringify(o||{})}catch(i){o=""}return f={location:r,properties:o,err:n},e},e.get=function(){var e=(f||{err:{}}).err,t=e.name,n=e.message,r=e.stack;if(!f)return"";var i=f,a=i.location,s=i.properties,u=navigator.userAgent,c=["version:1.3.4","location:"+a,"properties:"+s,"user-agent:"+u,"name:"+t,"message:"+n,"stack:"+r],l=c.join("|");try{return d+o(l)}catch(h){return""+d+l}},e}());t["default"]=h},function(e,t,n){var r,o=function(){function e(e,t){if(!o[e]){o[e]={};for(var n=0;n<e.length;n++)o[e][e.charAt(n)]=n}return o[e][t]}var t=String.fromCharCode,n="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$",o={},i={compressToBase64:function(e){if(null==e)return"";var t=i._compress(e,6,function(e){return n.charAt(e)});switch(t.length%4){default:case 0:return t;case 1:return t+"===";case 2:return t+"==";case 3:return t+"="}},decompressFromBase64:function(t){return null==t?"":""==t?null:i._decompress(t.length,32,function(r){return e(n,t.charAt(r))})},compressToUTF16:function(e){return null==e?"":i._compress(e,15,function(e){return t(e+32)})+" "},decompressFromUTF16:function(e){return null==e?"":""==e?null:i._decompress(e.length,16384,function(t){return e.charCodeAt(t)-32})},compressToUint8Array:function(e){for(var t=i.compress(e),n=new Uint8Array(2*t.length),r=0,o=t.length;r<o;r++){var a=t.charCodeAt(r);n[2*r]=a>>>8,n[2*r+1]=a%256}return n},decompressFromUint8Array:function(e){if(null===e||e===undefined)return i.decompress(e);for(var n=new Array(e.length/2),r=0,o=n.length;r<o;r++)n[r]=256*e[2*r]+e[2*r+1];var a=[];return n.forEach(function(e){a.push(t(e))}),i.decompress(a.join(""))},compressToEncodedURIComponent:function(e){return null==e?"":i._compress(e,6,function(e){return r.charAt(e)})},decompressFromEncodedURIComponent:function(t){return null==t?"":""==t?null:(t=t.replace(/ /g,"+"),i._decompress(t.length,32,function(n){return e(r,t.charAt(n))}))},compress:function(e){return i._compress(e,16,function(e){return t(e)})},_compress:function(e,t,n){if(null==e)return"";var r,o,i,a={},s={},u="",c="",l="",f=2,d=3,h=2,p=[],g=0,_=0;for(i=0;i<e.length;i+=1)if(u=e.charAt(i),Object.prototype.hasOwnProperty.call(a,u)||(a[u]=d++,s[u]=!0),c=l+u,Object.prototype.hasOwnProperty.call(a,c))l=c;else{if(Object.prototype.hasOwnProperty.call(s,l)){if(l.charCodeAt(0)<256){for(r=0;r<h;r++)g<<=1,_==t-1?(_=0,p.push(n(g)),g=0):_++;for(o=l.charCodeAt(0),r=0;r<8;r++)g=g<<1|1&o,_==t-1?(_=0,p.push(n(g)),g=0):_++,o>>=1}else{for(o=1,r=0;r<h;r++)g=g<<1|o,_==t-1?(_=0,p.push(n(g)),g=0):_++,o=0;for(o=l.charCodeAt(0),r=0;r<16;r++)g=g<<1|1&o,_==t-1?(_=0,p.push(n(g)),g=0):_++,o>>=1}f--,0==f&&(f=Math.pow(2,h),h++),delete s[l]}else for(o=a[l],r=0;r<h;r++)g=g<<1|1&o,_==t-1?(_=0,p.push(n(g)),g=0):_++,o>>=1;f--,0==f&&(f=Math.pow(2,h),h++),a[c]=d++,l=String(u)}if(""!==l){if(Object.prototype.hasOwnProperty.call(s,l)){if(l.charCodeAt(0)<256){for(r=0;r<h;r++)g<<=1,_==t-1?(_=0,p.push(n(g)),g=0):_++;for(o=l.charCodeAt(0),r=0;r<8;r++)g=g<<1|1&o,_==t-1?(_=0,p.push(n(g)),g=0):_++,o>>=1}else{for(o=1,r=0;r<h;r++)g=g<<1|o,_==t-1?(_=0,p.push(n(g)),g=0):_++,o=0;for(o=l.charCodeAt(0),r=0;r<16;r++)g=g<<1|1&o,_==t-1?(_=0,p.push(n(g)),g=0):_++,o>>=1}f--,0==f&&(f=Math.pow(2,h),h++),delete s[l]}else for(o=a[l],r=0;r<h;r++)g=g<<1|1&o,_==t-1?(_=0,p.push(n(g)),g=0):_++,o>>=1;f--,0==f&&(f=Math.pow(2,h),h++)}for(o=2,r=0;r<h;r++)g=g<<1|1&o,_==t-1?(_=0,p.push(n(g)),g=0):_++,o>>=1;for(;;){if(g<<=1,_==t-1){p.push(n(g));break}_++}return p.join("")},decompress:function(e){return null==e?"":""==e?null:i._decompress(e.length,32768,function(t){return e.charCodeAt(t)})},_decompress:function(e,n,r){var o,i,a,s,u,c,l,f=[],d=4,h=4,p=3,g="",_=[],y={val:r(0),position:n,index:1};for(o=0;o<3;o+=1)f[o]=o;for(a=0,u=Math.pow(2,2),c=1;c!=u;)s=y.val&y.position,y.position>>=1,0==y.position&&(y.position=n,y.val=r(y.index++)),a|=(s>0?1:0)*c,c<<=1;switch(a){case 0:for(a=0,u=Math.pow(2,8),c=1;c!=u;)s=y.val&y.position,y.position>>=1,0==y.position&&(y.position=n,y.val=r(y.index++)),a|=(s>0?1:0)*c,c<<=1;l=t(a);break;case 1:for(a=0,u=Math.pow(2,16),c=1;c!=u;)s=y.val&y.position,y.position>>=1,0==y.position&&(y.position=n,y.val=r(y.index++)),a|=(s>0?1:0)*c,c<<=1;l=t(a);break;case 2:return""}for(f[3]=l,i=l,_.push(l);;){if(y.index>e)return"";for(a=0,u=Math.pow(2,p),c=1;c!=u;)s=y.val&y.position,y.position>>=1,0==y.position&&(y.position=n,y.val=r(y.index++)),a|=(s>0?1:0)*c,c<<=1;switch(l=a){case 0:for(a=0,u=Math.pow(2,8),c=1;c!=u;)s=y.val&y.position,y.position>>=1,0==y.position&&(y.position=n,y.val=r(y.index++)),a|=(s>0?1:0)*c,c<<=1;f[h++]=t(a),l=h-1,d--;break;case 1:for(a=0,u=Math.pow(2,16),c=1;c!=u;)s=y.val&y.position,y.position>>=1,0==y.position&&(y.position=n,y.val=r(y.index++)),a|=(s>0?1:0)*c,c<<=1;f[h++]=t(a),l=h-1,d--;break;case 2:return _.join("")}if(0==d&&(d=Math.pow(2,p),p++),f[l])g=f[l];else{if(l!==h)return null;g=i+i.charAt(0)}_.push(g),f[h++]=i+g.charAt(0),d--,i=g,0==d&&(d=Math.pow(2,p),p++)}}};return i}();(r=function(){return o}.call(t,n,t,e))!==undefined&&(e.exports=r)},function(e,t,n){"use strict";function r(e){var t=e.a,n=e.b,r=e.c;return 444===t&&444===n&&444===r}function o(e){return isNaN(parseFloat(e))?444:parseFloat(e.toFixed(6))}function i(e){return a[e]||e}t.__esModule=!0,t.isWrong=r,t.refine=o,t.refineBfAttrName=i;var a={user_agent:"a",language:"b",color_depth:"c",device_memory:"d",pixel_ratio:"e",hardware_concurrency:"f",resolution:"g",available_resolution:"h",timezone_offset:"i",session_storage:"j",local_storage:"k",indexed_db:"l",cpu_class:"m",navigator_platform:"n",do_not_track:"o",canvas:"p",webgl:"q",webgl_vendor:"r",adblock:"s",has_lied_languages:"t",has_lied_resolution:"u",has_lied_os:"v",has_lied_browser:"w",touch_support:"x",js_fonts:"y",open_database:"z",regular_plugins:"aa",add_behavior:"ab"}},function(e,t,n){"use strict";var r=n(21),o=n(13),i=n(40),a=n(4),s=n(23),u=n(54),c=n(29),l=n(61),f=n(9)("iterator"),d=!([].keys&&"next"in[].keys()),h=function(){return this};e.exports=function(e,t,n,p,g,_,y){u(n,t,p);var m,v,w,b=function(e){if(!d&&e in E)return E[e];switch(e){case"keys":case"values":return function(){return new n(this,e)}}return function(){return new n(this,e)}},S=t+" Iterator",T="values"==g,x=!1,E=e.prototype,M=E[f]||E["@@iterator"]||g&&E[g],A=M||b(g),C=g?T?b("entries"):A:undefined,P="Array"==t?E.entries||M:M;if(P&&(w=l(P.call(new e)))!==Object.prototype&&w.next&&(c(w,S,!0),r||"function"==typeof w[f]||a(w,f,h)),T&&M&&"values"!==M.name&&(x=!0,A=function(){return M.call(this)}),r&&!y||!d&&!x&&E[f]||a(E,f,A),s[t]=A,s[S]=h,g)if(m={values:T?A:b("values"),keys:_?A:b("keys"),entries:C},y)for(v in m)v in E||i(E,v,m[v]);else o(o.P+o.F*(d||x),t,m);return m}},function(e,t,n){var r=n(53);e.exports=function(e,t,n){if(r(e),t===undefined)return e;switch(n){case 1:return function(n){return e.call(t,n)};case 2:return function(n,r){return e.call(t,n,r)};case 3:return function(n,r,o){return e.call(t,n,r,o)}}return function(){return e.apply(t,arguments)}}},function(e,t,n){e.exports=!n(7)&&!n(14)(function(){return 7!=Object.defineProperty(n(39)("div"),"a",{get:function(){return 7}}).a})},function(e,t,n){var r=n(6),o=n(1).document,i=r(o)&&r(o.createElement);e.exports=function(e){return i?o.createElement(e):{}}},function(e,t,n){e.exports=n(4)},function(e,t,n){var r=n(2),o=n(8),i=n(57)(!1),a=n(26)("IE_PROTO");e.exports=function(e,t){var n,s=o(e),u=0,c=[];for(n in s)n!=a&&r(s,n)&&c.push(n);for(;t.length>u;)r(s,n=t[u++])&&(~i(c,n)||c.push(n));return c}},function(e,t){var n={}.toString;e.exports=function(e){return n.call(e).slice(8,-1)}},function(e,t){t.f=Object.getOwnPropertySymbols},function(e,t,n){var r=n(41),o=n(28).concat("length","prototype");t.f=Object.getOwnPropertyNames||function(e){return r(e,o)}},function(e,t,n){var r=n(32),o=n(15),i=n(8),a=n(22),s=n(2),u=n(38),c=Object.getOwnPropertyDescriptor;t.f=n(7)?c:function(e,t){if(e=i(e),t=a(t,!0),u)try{return c(e,t)}catch(n){}if(s(e,t))return o(!r.f.call(e,t),e[t])}},function(e,t){var n={utf8:{stringToBytes:function(e){return n.bin.stringToBytes(unescape(encodeURIComponent(e)))},bytesToString:function(e){return decodeURIComponent(escape(n.bin.bytesToString(e)))}},bin:{stringToBytes:function(e){for(var t=[],n=0;n<e.length;n++)t.push(255&e.charCodeAt(n));return t},bytesToString:function(e){for(var t=[],n=0;n<e.length;n++)t.push(String.fromCharCode(e[n]));return t.join("")}}};e.exports=n},function(e,t,n){e.exports=n(48)},function(e,t,n){"use strict";function r(e){return e&&e.__esModule?e:{"default":e}}function o(){var e=window.sofa;return e&&e.Koop===g&&_&&(window.sofa=_),e||{__esModule:!0,VERSION:y,Koop:g,noConflict:o}}t.__esModule=!0,t.Koop=t.VERSION=undefined;var i=n(18),a=r(i),s=n(0),u=r(s);t.noConflict=o;var c=n(33),l=r(c),f=n(77),d=n(103),h=r(d),p=n(3),g=function(){function e(){var t=this,n=arguments.length>0&&arguments[0]!==undefined?arguments[0]:{};(0,u["default"])(this,e),(0,p.runErrorSafe)(function(){t._prop={keyboard:n.keyboard||[],modeProperties:(0,p.objectAssign)({mode:1,url:"",chunkSize:1800,timeout:1500,bfTimeout:500},n.modeProperties||{})},t._data=new f.CaptchaData(t._prop)},{location:"NCaptcha Constructor",properties:n})}return e.prototype.f=function(e,t){var n=this._prop.modeProperties.mode,r=this._defineDefaultOptions(n),o=t;return"function"==typeof e&&(o=e),"object"===(void 0===e?"undefined":(0,a["default"])(e))&&(r=(0,p.objectAssign)(r,e)),2===n?this._handleMode2(r,o):4===n?this._handleMode4(r,o):this._handleMode1(r)},e.prototype._defineDefaultOptions=function(e){return{compressMode:1===e||4===e?"old":"new"}},e.prototype._handleMode1=function(e){var t=this;return(0,p.runErrorSafe)(function(){return l["default"].get()||t._data.get(e).body},{location:"mode1 f",properties:this._prop})},e.prototype._handleMode2=function(e,t){this._send("mode2 f",e,t)},e.prototype._handleMode4=function(e,t){var n=this;if(!this._data.getBFP())return void this._afterBFPComplete(function(){n._handleMode4(e,t)});var r=(0,p.runErrorSafe)(function(){return l["default"].get()||n._data.get(e).body},{location:"mode4 f",properties:this._prop});t(r||"mode4 f result is empty")},e.prototype._afterBFPComplete=function(e){var t=this._data,n=function r(){t.off("bfpTimeout",r),t.off("bfpLoad",r),e()};t.on({bfpTimeout:n,bfpLoad:n})},e.prototype._send=function(e,t,n){var r=this;if(!this._data.getBFP())return void this._afterBFPComplete(function(){r._send(e,t,n)});var o=(0,p.runErrorSafe)(function(){var e=l["default"].get()||r._data.get(t);return(0,h["default"])(e,r._prop.modeProperties,n)},{location:e,properties:this._prop});o&&n(o)},e.prototype.addKeyboardWatch=function(e){var t=this;(0,p.runErrorSafe)(function(){return t._data.addKeyboardWatch(e)},{location:"add keyboard watch",properties:this._prop})},e.prototype.removeKeyboardWatch=function(e){var t=this;(0,p.runErrorSafe)(function(){return t._data.removeKeyboardWatch(e)},{location:"remove keyboard watch",properties:this._prop})},e}(),_=window.sofa,y=t.VERSION="1.3.4";t.Koop=g},function(e,t,n){e.exports={"default":n(50),__esModule:!0}},function(e,t,n){n(51),n(63),e.exports=n(30).f("iterator")},function(e,t,n){"use strict";var r=n(52)(!0);n(36)(String,"String",function(e){this._t=String(e),this._i=0},function(){var e,t=this._t,n=this._i;return n>=t.length?{value:undefined,done:!0}:(e=r(t,n),this._i+=e.length,{value:e,done:!1})})},function(e,t,n){var r=n(19),o=n(20);e.exports=function(e){return function(t,n){var i,a,s=String(o(t)),u=r(n),c=s.length;return u<0||u>=c?e?"":undefined:(i=s.charCodeAt(u),i<55296||i>56319||u+1===c||(a=s.charCodeAt(u+1))<56320||a>57343?e?s.charAt(u):i:e?s.slice(u,u+2):a-56320+(i-55296<<10)+65536)}}},function(e,t){e.exports=function(e){if("function"!=typeof e)throw TypeError(e+" is not a function!");return e}},function(e,t,n){"use strict";var r=n(24),o=n(15),i=n(29),a={};n(4)(a,n(9)("iterator"),function(){return this}),e.exports=function(e,t,n){e.prototype=r(a,{next:o(1,n)}),i(e,t+" Iterator")}},function(e,t,n){var r=n(5),o=n(12),i=n(25);e.exports=n(7)?Object.defineProperties:function(e,t){o(e);for(var n,a=i(t),s=a.length,u=0;s>u;)r.f(e,n=a[u++],t[n]);return e}},function(e,t,n){var r=n(42);e.exports=Object("z").propertyIsEnumerable(0)?Object:function(e){return"String"==r(e)?e.split(""):Object(e)}},function(e,t,n){var r=n(8),o=n(58),i=n(59);e.exports=function(e){return function(t,n,a){var s,u=r(t),c=o(u.length),l=i(a,c);if(e&&n!=n){for(;c>l;)if((s=u[l++])!=s)return!0}else for(;c>l;l++)if((e||l in u)&&u[l]===n)return e||l||0;return!e&&-1}}},function(e,t,n){var r=n(19),o=Math.min;e.exports=function(e){return e>0?o(r(e),9007199254740991):0}},function(e,t,n){var r=n(19),o=Math.max,i=Math.min;e.exports=function(e,t){return e=r(e),e<0?o(e+t,0):i(e,t)}},function(e,t,n){var r=n(1).document;e.exports=r&&r.documentElement},function(e,t,n){var r=n(2),o=n(62),i=n(26)("IE_PROTO"),a=Object.prototype;e.exports=Object.getPrototypeOf||function(e){return e=o(e),r(e,i)?e[i]:"function"==typeof e.constructor&&e instanceof e.constructor?e.constructor.prototype:e instanceof Object?a:null}},function(e,t,n){var r=n(20);e.exports=function(e){return Object(r(e))}},function(e,t,n){n(64);for(var r=n(1),o=n(4),i=n(23),a=n(9)("toStringTag"),s="CSSRuleList,CSSStyleDeclaration,CSSValueList,ClientRectList,DOMRectList,DOMStringList,DOMTokenList,DataTransferItemList,FileList,HTMLAllCollection,HTMLCollection,HTMLFormElement,HTMLSelectElement,MediaList,MimeTypeArray,NamedNodeMap,NodeList,PaintRequestList,Plugin,PluginArray,SVGLengthList,SVGNumberList,SVGPathSegList,SVGPointList,SVGStringList,SVGTransformList,SourceBufferList,StyleSheetList,TextTrackCueList,TextTrackList,TouchList".split(","),u=0;u<s.length;u++){var c=s[u],l=r[c],f=l&&l.prototype;f&&!f[a]&&o(f,a,c),i[c]=i.Array}},function(e,t,n){"use strict";var r=n(65),o=n(66),i=n(23),a=n(8);e.exports=n(36)(Array,"Array",function(e,t){this._t=a(e),this._i=0,this._k=t},function(){var e=this._t,t=this._k,n=this._i++;return!e||n>=e.length?(this._t=undefined,o(1)):"keys"==t?o(0,n):"values"==t?o(0,e[n]):o(0,[n,e[n]])},"values"),i.Arguments=i.Array,r("keys"),r("values"),r("entries")},function(e,t){e.exports=function(){}},function(e,t){e.exports=function(e,t){return{value:t,done:!!e}}},function(e,t,n){e.exports={"default":n(68),__esModule:!0}},function(e,t,n){n(69),n(74),n(75),n(76),e.exports=n(11).Symbol},function(e,t,n){"use strict";var r=n(1),o=n(2),i=n(7),a=n(13),s=n(40),u=n(70).KEY,c=n(14),l=n(27),f=n(29),d=n(16),h=n(9),p=n(30),g=n(31),_=n(71),y=n(72),m=n(12),v=n(6),w=n(8),b=n(22),S=n(15),T=n(24),x=n(73),E=n(45),M=n(5),A=n(25),C=E.f,P=M.f,O=x.f,L=r.Symbol,I=r.JSON,F=I&&I.stringify,R=h("_hidden"),B=h("toPrimitive"),k={}.propertyIsEnumerable,D=l("symbol-registry"),N=l("symbols"),H=l("op-symbols"),G=Object.prototype,K="function"==typeof L,j=r.QObject,W=!j||!j.prototype||!j.prototype.findChild,U=i&&c(function(){return 7!=T(P({},"a",{get:function(){return P(this,"a",{value:7}).a}})).a})?function(e,t,n){var r=C(G,t);r&&delete G[t],P(e,t,n),r&&e!==G&&P(G,t,r)}:P,V=function(e){var t=N[e]=T(L.prototype);return t._k=e,t},X=K&&"symbol"==typeof L.iterator?function(e){return"symbol"==typeof e}:function(e){return e instanceof L},z=function(e,t,n){return e===G&&z(H,t,n),m(e),t=b(t,!0),m(n),o(N,t)?(n.enumerable?(o(e,R)&&e[R][t]&&(e[R][t]=!1),n=T(n,{enumerable:S(0,!1)})):(o(e,R)||P(e,R,S(1,{})),e[R][t]=!0),U(e,t,n)):P(e,t,n)},Y=function(e,t){m(e);for(var n,r=_(t=w(t)),o=0,i=r.length;i>o;)z(e,n=r[o++],t[n]);return e},J=function(e,t){return t===undefined?T(e):Y(T(e),t)},Z=function(e){var t=k.call(this,e=b(e,!0));return!(this===G&&o(N,e)&&!o(H,e))&&(!(t||!o(this,e)||!o(N,e)||o(this,R)&&this[R][e])||t)},q=function(e,t){if(e=w(e),t=b(t,!0),e!==G||!o(N,t)||o(H,t)){var n=C(e,t);return!n||!o(N,t)||o(e,R)&&e[R][t]||(n.enumerable=!0),n}},Q=function(e){for(var t,n=O(w(e)),r=[],i=0;n.length>i;)o(N,t=n[i++])||t==R||t==u||r.push(t);return r},$=function(e){for(var t,n=e===G,r=O(n?H:w(e)),i=[],a=0;r.length>a;)!o(N,t=r[a++])||n&&!o(G,t)||i.push(N[t]);return i};K||(L=function(){if(this instanceof L)throw TypeError("Symbol is not a constructor!");var e=d(arguments.length>0?arguments[0]:undefined),t=function(n){this===G&&t.call(H,n),o(this,R)&&o(this[R],e)&&(this[R][e]=!1),U(this,e,S(1,n))};return i&&W&&U(G,e,{configurable:!0,set:t}),V(e)},s(L.prototype,"toString",function(){return this._k}),E.f=q,M.f=z,n(44).f=x.f=Q,n(32).f=Z,n(43).f=$,i&&!n(21)&&s(G,"propertyIsEnumerable",Z,!0),p.f=function(e){return V(h(e))}),a(a.G+a.W+a.F*!K,{Symbol:L});for(var ee="hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables".split(","),te=0;ee.length>te;)h(ee[te++]);for(var ne=A(h.store),re=0;ne.length>re;)g(ne[re++]);a(a.S+a.F*!K,"Symbol",{"for":function(e){return o(D,e+="")?D[e]:D[e]=L(e)},keyFor:function(e){if(!X(e))throw TypeError(e+" is not a symbol!");for(var t in D)if(D[t]===e)return t},useSetter:function(){W=!0},useSimple:function(){W=!1}}),a(a.S+a.F*!K,"Object",{create:J,defineProperty:z,defineProperties:Y,getOwnPropertyDescriptor:q,getOwnPropertyNames:Q,getOwnPropertySymbols:$}),I&&a(a.S+a.F*(!K||c(function(){var e=L();return"[null]"!=F([e])||"{}"!=F({a:e})||"{}"!=F(Object(e))})),"JSON",{stringify:function(e){for(var t,n,r=[e],o=1;arguments.length>o;)r.push(arguments[o++]);if(n=t=r[1],(v(t)||e!==undefined)&&!X(e))return y(t)||(t=function(e,t){if("function"==typeof n&&(t=n.call(this,e,t)),!X(t))return t}),r[1]=t,F.apply(I,r)}}),L.prototype[B]||n(4)(L.prototype,B,L.prototype.valueOf),f(L,"Symbol"),f(Math,"Math",!0),f(r.JSON,"JSON",!0)},function(e,t,n){var r=n(16)("meta"),o=n(6),i=n(2),a=n(5).f,s=0,u=Object.isExtensible||function(){return!0},c=!n(14)(function(){return u(Object.preventExtensions({}))}),l=function(e){a(e,r,{value:{i:"O"+ ++s,w:{}}})},f=function(e,t){if(!o(e))return"symbol"==typeof e?e:("string"==typeof e?"S":"P")+e;if(!i(e,r)){if(!u(e))return"F";if(!t)return"E";l(e)}return e[r].i},d=function(e,t){if(!i(e,r)){if(!u(e))return!0;if(!t)return!1;l(e)}return e[r].w},h=function(e){return c&&p.NEED&&u(e)&&!i(e,r)&&l(e),e},p=e.exports={KEY:r,NEED:!1,fastKey:f,getWeak:d,onFreeze:h}},function(e,t,n){var r=n(25),o=n(43),i=n(32);e.exports=function(e){var t=r(e),n=o.f;if(n)for(var a,s=n(e),u=i.f,c=0;s.length>c;)u.call(e,a=s[c++])&&t.push(a);return t}},function(e,t,n){var r=n(42);e.exports=Array.isArray||function(e){return"Array"==r(e)}},function(e,t,n){var r=n(8),o=n(44).f,i={}.toString,a="object"==typeof window&&window&&Object.getOwnPropertyNames?Object.getOwnPropertyNames(window):[],s=function(e){try{return o(e)}catch(t){return a.slice()}};e.exports.f=function(e){return a&&"[object Window]"==i.call(e)?s(e):o(r(e))}},function(e,t){},function(e,t,n){n(31)("asyncIterator")},function(e,t,n){n(31)("observable")},function(e,t,n){"use strict";function r(e){return e&&e.__esModule?e:{"default":e}}t.__esModule=!0,t.CaptchaData=undefined;var o=n(0),i=r(o),a=n(78),s=r(a),u=n(79),c=r(u),l=n(87),f=r(l),d=n(91),h=r(d),p=n(94),g=r(p),_=n(95),y=n(97),m=r(y),v=n(98),w=r(v),b=n(99),S=r(b),T=n(100),x=r(T),E=n(101),M=r(E),A=n(35),C=n(102),P=r(C),O=n(3),L=n(10),I=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t["default"]=e,t}(L);t.CaptchaData=function(e){function t(n){(0,i["default"])(this,t);var r=(0,s["default"])(this,e.call(this));return r._prop=n,r._uuid=(0,f["default"])(),r._tseq=0,r._keyboard=new w["default"](n.keyboard),r._deviceOrientation=new S["default"],r._deviceMotion=new x["default"],r._mouse=new M["default"],1===r._prop.modeProperties.mode?(0,_.getBFP)(function(e,t,n){r._fpHash=e,r._fpComponent=r._refineComponents(t),r._fpDuration=n}):r._prepare(),r}return(0,c["default"])(t,e),t.prototype.getBFP=function(){return this._fpHash?{hash:this._fpHash,component:this._fpComponent,duration:this._fpDuration}:null},t.prototype._prepare=function(){var e=this;"complete"===document.readyState?this._loadBFP():(0,O.addEventListener)(window,"load",function(){e._loadBFP()})},t.prototype._loadBFP=function(){var e=this;if(!this._loadTimer&&!this._fpHash){var t=this._prop.modeProperties.bfTimeout||500;this._loadTimer=window.setTimeout(function(){(0,O.runErrorSafe)(function(){e._timeoutTimer=window.setTimeout(function(){e._fpHash||e.trigger("bfpTimeout")},t),(0,_.getBFP)(function(t,n,r){e._fpHash=t,e._fpComponent=e._refineComponents(n),e._fpDuration=r,window.clearTimeout(e._timeoutTimer),delete e._timeoutTimer,delete e._loadTimer,e.trigger("bfpLoad")})},{location:"Fingerprint2 Constructor",properties:e._prop})},10)}},t.prototype._getTransactionId=function(){return this._uuid+"-"+this._tseq++},t.prototype._refineComponents=function(e){var t={};return I.forEach(e,function(e){"canvas"!==e.key&&"webgl"!==e.key||!e.value||(e.value=(0,h["default"])(e.value)),t[(0,A.refineBfAttrName)(e.key)]=e.value}),t},t.prototype.get=function(){var e=arguments.length>0&&arguments[0]!==undefined?arguments[0]:{},t=e.compressMode||"new",n=this._getTransactionId(),r=this._keyboard.get({filter:e.keyboardLogs}),o={a:n,b:"1.3.4",c:(0,m["default"])(),d:r,e:this._deviceOrientation.get(),f:this._deviceMotion.get(),g:this._mouse.get(),j:this._fpDuration||_.NOT_YET,h:this._fpHash||"",i:this._fpComponent||[]};return{type:"c",uuid:n,body:(0,P["default"])(o,t)}},t.prototype.addKeyboardWatch=function(e){this._keyboard.addWatch(e)},t.prototype.removeKeyboardWatch=function(e){this._keyboard.removeWatch(e)},t}(g["default"])},function(e,t,n){"use strict";t.__esModule=!0;var r=n(18),o=function(e){return e&&e.__esModule?e:{"default":e}}(r);t["default"]=function(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!==(void 0===t?"undefined":(0,o["default"])(t))&&"function"!=typeof t?e:t}},function(e,t,n){"use strict";function r(e){return e&&e.__esModule?e:{"default":e}}t.__esModule=!0;var o=n(80),i=r(o),a=n(84),s=r(a),u=n(18),c=r(u);t["default"]=function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+(void 0===t?"undefined":(0,c["default"])(t)));e.prototype=(0,s["default"])(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(i["default"]?(0,i["default"])(e,t):e.__proto__=t)}},function(e,t,n){e.exports={"default":n(81),__esModule:!0}},function(e,t,n){n(82),e.exports=n(11).Object.setPrototypeOf},function(e,t,n){var r=n(13);r(r.S,"Object",{setPrototypeOf:n(83).set})},function(e,t,n){var r=n(6),o=n(12),i=function(e,t){if(o(e),!r(t)&&null!==t)throw TypeError(t+": can't set as prototype!")};e.exports={set:Object.setPrototypeOf||("__proto__"in{}?function(e,t,r){try{r=n(37)(Function.call,n(45).f(Object.prototype,"__proto__").set,2),r(e,[]),t=!(e instanceof Array)}catch(o){t=!0}return function(e,n){return i(e,n),t?e.__proto__=n:r(e,n),e}}({},!1):undefined),check:i}},function(e,t,n){e.exports={"default":n(85),__esModule:!0}},function(e,t,n){n(86);var r=n(11).Object;e.exports=function(e,t){return r.create(e,t)}},function(e,t,n){var r=n(13);r(r.S,"Object",{create:n(24)})},function(e,t,n){function r(e,t,n){var r=t&&n||0;"string"==typeof e&&(t="binary"==e?new Array(16):null,e=null),e=e||{};var a=e.random||(e.rng||o)();if(a[6]=15&a[6]|64,a[8]=63&a[8]|128,t)for(var s=0;s<16;++s)t[r+s]=a[s];return t||i(a)}var o=n(88),i=n(90);e.exports=r},function(e,t,n){(function(t){var n,r=t.crypto||t.msCrypto;if(r&&r.getRandomValues){var o=new Uint8Array(16);n=function(){return r.getRandomValues(o),o}}if(!n){var i=new Array(16);n=function(){for(var e,t=0;t<16;t++)0==(3&t)&&(e=4294967296*Math.random()),i[t]=e>>>((3&t)<<3)&255;return i}}e.exports=n}).call(t,n(89))},function(e,t){var n;n=function(){return this}();try{n=n||Function("return this")()||(0,eval)("this")}catch(r){"object"==typeof window&&(n=window)}e.exports=n},function(e,t){function n(e,t){var n=t||0,o=r;return o[e[n++]]+o[e[n++]]+o[e[n++]]+o[e[n++]]+"-"+o[e[n++]]+o[e[n++]]+"-"+o[e[n++]]+o[e[n++]]+"-"+o[e[n++]]+o[e[n++]]+"-"+o[e[n++]]+o[e[n++]]+o[e[n++]]+o[e[n++]]+o[e[n++]]+o[e[n++]]}for(var r=[],o=0;o<256;++o)r[o]=(o+256).toString(16).substr(1);e.exports=n},function(e,t,n){!function(){var t=n(92),r=n(46).utf8,o=n(93),i=n(46).bin,a=function(e,n){e.constructor==String?e=n&&"binary"===n.encoding?i.stringToBytes(e):r.stringToBytes(e):o(e)?e=Array.prototype.slice.call(e,0):Array.isArray(e)||(e=e.toString());for(var s=t.bytesToWords(e),u=8*e.length,c=1732584193,l=-271733879,f=-1732584194,d=271733878,h=0;h<s.length;h++)s[h]=16711935&(s[h]<<8|s[h]>>>24)|4278255360&(s[h]<<24|s[h]>>>8);s[u>>>5]|=128<<u%32,s[14+(u+64>>>9<<4)]=u;for(var p=a._ff,g=a._gg,_=a._hh,y=a._ii,h=0;h<s.length;h+=16){var m=c,v=l,w=f,b=d;c=p(c,l,f,d,s[h+0],7,-680876936),d=p(d,c,l,f,s[h+1],12,-389564586),f=p(f,d,c,l,s[h+2],17,606105819),l=p(l,f,d,c,s[h+3],22,-1044525330),c=p(c,l,f,d,s[h+4],7,-176418897),d=p(d,c,l,f,s[h+5],12,1200080426),f=p(f,d,c,l,s[h+6],17,-1473231341),l=p(l,f,d,c,s[h+7],22,-45705983),c=p(c,l,f,d,s[h+8],7,1770035416),d=p(d,c,l,f,s[h+9],12,-1958414417),f=p(f,d,c,l,s[h+10],17,-42063),l=p(l,f,d,c,s[h+11],22,-1990404162),c=p(c,l,f,d,s[h+12],7,1804603682),d=p(d,c,l,f,s[h+13],12,-40341101),f=p(f,d,c,l,s[h+14],17,-1502002290),l=p(l,f,d,c,s[h+15],22,1236535329),c=g(c,l,f,d,s[h+1],5,-165796510),d=g(d,c,l,f,s[h+6],9,-1069501632),f=g(f,d,c,l,s[h+11],14,643717713),l=g(l,f,d,c,s[h+0],20,-373897302),c=g(c,l,f,d,s[h+5],5,-701558691),d=g(d,c,l,f,s[h+10],9,38016083),f=g(f,d,c,l,s[h+15],14,-660478335),l=g(l,f,d,c,s[h+4],20,-405537848),c=g(c,l,f,d,s[h+9],5,568446438),d=g(d,c,l,f,s[h+14],9,-1019803690),f=g(f,d,c,l,s[h+3],14,-187363961),l=g(l,f,d,c,s[h+8],20,1163531501),c=g(c,l,f,d,s[h+13],5,-1444681467),d=g(d,c,l,f,s[h+2],9,-51403784),f=g(f,d,c,l,s[h+7],14,1735328473),l=g(l,f,d,c,s[h+12],20,-1926607734),c=_(c,l,f,d,s[h+5],4,-378558),d=_(d,c,l,f,s[h+8],11,-2022574463),f=_(f,d,c,l,s[h+11],16,1839030562),l=_(l,f,d,c,s[h+14],23,-35309556),c=_(c,l,f,d,s[h+1],4,-1530992060),d=_(d,c,l,f,s[h+4],11,1272893353),f=_(f,d,c,l,s[h+7],16,-155497632),l=_(l,f,d,c,s[h+10],23,-1094730640),c=_(c,l,f,d,s[h+13],4,681279174),d=_(d,c,l,f,s[h+0],11,-358537222),f=_(f,d,c,l,s[h+3],16,-722521979),l=_(l,f,d,c,s[h+6],23,76029189),c=_(c,l,f,d,s[h+9],4,-640364487),d=_(d,c,l,f,s[h+12],11,-421815835),f=_(f,d,c,l,s[h+15],16,530742520),l=_(l,f,d,c,s[h+2],23,-995338651),c=y(c,l,f,d,s[h+0],6,-198630844),d=y(d,c,l,f,s[h+7],10,1126891415),f=y(f,d,c,l,s[h+14],15,-1416354905),l=y(l,f,d,c,s[h+5],21,-57434055),c=y(c,l,f,d,s[h+12],6,1700485571),d=y(d,c,l,f,s[h+3],10,-1894986606),f=y(f,d,c,l,s[h+10],15,-1051523),l=y(l,f,d,c,s[h+1],21,-2054922799),c=y(c,l,f,d,s[h+8],6,1873313359),d=y(d,c,l,f,s[h+15],10,-30611744),f=y(f,d,c,l,s[h+6],15,-1560198380),l=y(l,f,d,c,s[h+13],21,1309151649),c=y(c,l,f,d,s[h+4],6,-145523070),d=y(d,c,l,f,s[h+11],10,-1120210379),f=y(f,d,c,l,s[h+2],15,718787259),l=y(l,f,d,c,s[h+9],21,-343485551),c=c+m>>>0,l=l+v>>>0,f=f+w>>>0,d=d+b>>>0}return t.endian([c,l,f,d])};a._ff=function(e,t,n,r,o,i,a){var s=e+(t&n|~t&r)+(o>>>0)+a;return(s<<i|s>>>32-i)+t},a._gg=function(e,t,n,r,o,i,a){var s=e+(t&r|n&~r)+(o>>>0)+a;return(s<<i|s>>>32-i)+t},a._hh=function(e,t,n,r,o,i,a){var s=e+(t^n^r)+(o>>>0)+a;return(s<<i|s>>>32-i)+t},a._ii=function(e,t,n,r,o,i,a){var s=e+(n^(t|~r))+(o>>>0)+a;return(s<<i|s>>>32-i)+t},a._blocksize=16,a._digestsize=16,e.exports=function(e,n){if(e===undefined||null===e)throw new Error("Illegal argument "+e);var r=t.wordsToBytes(a(e,n));return n&&n.asBytes?r:n&&n.asString?i.bytesToString(r):t.bytesToHex(r)}}()},function(e,t){!function(){var t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",n={rotl:function(e,t){return e<<t|e>>>32-t},rotr:function(e,t){return e<<32-t|e>>>t},endian:function(e){if(e.constructor==Number)return 16711935&n.rotl(e,8)|4278255360&n.rotl(e,24);for(var t=0;t<e.length;t++)e[t]=n.endian(e[t]);return e},randomBytes:function(e){for(var t=[];e>0;e--)t.push(Math.floor(256*Math.random()));return t},bytesToWords:function(e){for(var t=[],n=0,r=0;n<e.length;n++,r+=8)t[r>>>5]|=e[n]<<24-r%32;return t},wordsToBytes:function(e){for(var t=[],n=0;n<32*e.length;n+=8)t.push(e[n>>>5]>>>24-n%32&255);return t},bytesToHex:function(e){for(var t=[],n=0;n<e.length;n++)t.push((e[n]>>>4).toString(16)),t.push((15&e[n]).toString(16));return t.join("")},hexToBytes:function(e){for(var t=[],n=0;n<e.length;n+=2)t.push(parseInt(e.substr(n,2),16));return t},bytesToBase64:function(e){for(var n=[],r=0;r<e.length;r+=3)for(var o=e[r]<<16|e[r+1]<<8|e[r+2],i=0;i<4;i++)8*r+6*i<=8*e.length?n.push(t.charAt(o>>>6*(3-i)&63)):n.push("=");return n.join("")},base64ToBytes:function(e){e=e.replace(/[^A-Z0-9+\/]/gi,"");for(var n=[],r=0,o=0;r<e.length;o=++r%4)0!=o&&n.push((t.indexOf(e.charAt(r-1))&Math.pow(2,-2*o+8)-1)<<2*o|t.indexOf(e.charAt(r))>>>6-2*o);return n}};e.exports=n}()},function(e,t){function n(e){return!!e.constructor&&"function"==typeof e.constructor.isBuffer&&e.constructor.isBuffer(e)}function r(e){return"function"==typeof e.readFloatLE&&"function"==typeof e.slice&&n(e.slice(0,0))}/*!
 * Determine if an object is a Buffer
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
    e.exports=function(e){return null!=e&&(n(e)||r(e)||!!e._isBuffer)}},function(e,t,n){/*!
 * Copyright (c) 2017 NAVER Corp.
 * @egjs/component project is licensed under the MIT license
 *
 * @egjs/component JavaScript library
 * http://naver.github.io/egjs/component
 *
 * @version 2.1.1
 */
!function(t,n){e.exports=n()}(0,function(){return function(e){function t(r){if(n[r])return n[r].exports;var o=n[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,t),o.l=!0,o.exports}var n={};return t.m=e,t.c=n,t.d=function(e,n,r){t.o(e,n)||Object.defineProperty(e,n,{configurable:!1,enumerable:!0,get:r})},t.n=function(e){var n=e&&e.__esModule?function(){return e["default"]}:function(){return e};return t.d(n,"a",n),n},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="",t(t.s=2)}([function(e,t,n){"use strict";function r(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}t.__esModule=!0;var o="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},i=function(){function e(){r(this,e),this._eventHandler={},this.options={}}return e.prototype.trigger=function(e){var t=arguments.length>1&&arguments[1]!==undefined?arguments[1]:{},n=this._eventHandler[e]||[];if(!(n.length>0))return!0;n=n.concat(),t.eventType=e;var r=!1,o=[t],i=0;t.stop=function(){r=!0},t.currentTarget=this;for(var a=arguments.length,s=Array(a>2?a-2:0),u=2;u<a;u++)s[u-2]=arguments[u];for(s.length>=1&&(o=o.concat(s)),i=0;n[i];i++)n[i].apply(this,o);return!r},e.prototype.once=function(e,t){if("object"===(void 0===e?"undefined":o(e))&&void 0===t){var n=e,r=void 0;for(r in n)this.once(r,n[r]);return this}if("string"==typeof e&&"function"==typeof t){var i=this;this.on(e,function a(){for(var n=arguments.length,r=Array(n),o=0;o<n;o++)r[o]=arguments[o];t.apply(i,r),i.off(e,a)})}return this},e.prototype.hasOn=function(e){return!!this._eventHandler[e]},e.prototype.on=function(e,t){if("object"===(void 0===e?"undefined":o(e))&&void 0===t){var n=e,r=void 0;for(r in n)this.on(r,n[r]);return this}if("string"==typeof e&&"function"==typeof t){var i=this._eventHandler[e];void 0===i&&(this._eventHandler[e]=[],i=this._eventHandler[e]),i.push(t)}return this},e.prototype.off=function(e,t){if(void 0===e)return this._eventHandler={},this;if(void 0===t){if("string"==typeof e)return this._eventHandler[e]=undefined,this;var n=e,r=void 0;for(r in n)this.off(r,n[r]);return this}var o=this._eventHandler[e];if(o){var i=void 0,a=void 0;for(i=0;(a=o[i])!==undefined;i++)if(a===t){o=o.splice(i,1);break}}return this},e}();t["default"]=i,e.exports=t["default"]},,function(e,t,n){"use strict";t.__esModule=!0;var r=n(0),o=function(e){return e&&e.__esModule?e:{"default":e}}(r);o["default"].VERSION="2.1.1",t["default"]=o["default"],e.exports=t["default"]}])})},function(e,t,n){"use strict";function r(){var e=arguments.length>0&&arguments[0]!==undefined?arguments[0]:function(){};if(s)return void u.push(e);var t="v"+i["default"].VERSION,n=f[t];n?e(n.hash,n.components,n.duration):(c[t]||(c[t]=(new Date).getTime()),s=!0,d.get(function(n,r){var o=c[t]?(new Date).getTime()-c[t]:l;s=!1,f[t]={hash:n,components:r,duration:o},e(n,r,o),(0,a.forEach)(u,function(e){return e(n,r,o)}),u.length=0,u=[]}))}t.__esModule=!0,t.fingerprint2=t.registry=t.NOT_YET=undefined,t.getBFP=r;var o=n(96),i=function(e){return e&&e.__esModule?e:{"default":e}}(o),a=n(10);window.__sofabfp_registry||(window.__sofabfp_registry={});var s=!1,u=[],c=[],l=-1,f=(t.NOT_YET=-2,t.registry=window.__sofabfp_registry),d=t.fingerprint2=new i["default"]},function(e,t){!function(t,n,r){"use strict";"function"==typeof window.define&&window.define.amd?window.define(r):void 0!==e&&e.exports?e.exports=r():n.exports?n.exports=r():n.Fingerprint2=r()}(0,this,function(){"use strict";var e=function(t){if(!(this instanceof e))return new e(t);var n={swfContainerId:"fingerprintjs2",swfPath:"flash/compiled/FontList.swf",detectScreenOrientation:!0,sortPluginsFor:[/palemoon/i],userDefinedFonts:[]};this.options=n;for(var r in t||{})this.options[r]=t[r];this.nativeForEach=Array.prototype.forEach,this.nativeMap=Array.prototype.map};return e.prototype={extend:function(e,t){if(null==e)return t;for(var n in e)null!=e[n]&&t[n]!==e[n]&&(t[n]=e[n]);return t},get:function(e){var t=this,n={data:[],addPreprocessedComponent:function(e){var r=e.value;"function"==typeof t.options.preprocessor&&(r=t.options.preprocessor(e.key,r)),n.data.push({key:e.key,value:r})}};n=this.userAgentKey(n),n=this.languageKey(n),n=this.colorDepthKey(n),n=this.deviceMemoryKey(n),n=this.pixelRatioKey(n),n=this.hardwareConcurrencyKey(n),n=this.screenResolutionKey(n),n=this.availableScreenResolutionKey(n),n=this.timezoneOffsetKey(n),n=this.sessionStorageKey(n),n=this.localStorageKey(n),n=this.indexedDbKey(n),n=this.addBehaviorKey(n),n=this.openDatabaseKey(n),n=this.cpuClassKey(n),n=this.platformKey(n),n=this.doNotTrackKey(n),n=this.pluginsKey(n),n=this.canvasKey(n),n=this.webglKey(n),n=this.webglVendorAndRendererKey(n),n=this.adBlockKey(n),n=this.hasLiedLanguagesKey(n),n=this.hasLiedResolutionKey(n),n=this.hasLiedOsKey(n),n=this.hasLiedBrowserKey(n),n=this.touchSupportKey(n),n=this.customEntropyFunction(n),this.fontsKey(n,function(n){var r=[];t.each(n.data,function(e){var t=e.value;t&&"undefined"===t.join&&(t=t.join(";")),r.push(t)});var o=t.x64hash128(r.join("~~~"),31);return e(o,n.data)})},customEntropyFunction:function(e){return"function"==typeof this.options.customFunction&&e.addPreprocessedComponent({key:"custom",value:this.options.customFunction()}),e},userAgentKey:function(e){return this.options.excludeUserAgent||e.addPreprocessedComponent({key:"user_agent",value:this.getUserAgent()}),e},getUserAgent:function(){return navigator.userAgent},languageKey:function(e){return this.options.excludeLanguage||e.addPreprocessedComponent({key:"language",value:navigator.language||navigator.userLanguage||navigator.browserLanguage||navigator.systemLanguage||""}),e},colorDepthKey:function(e){return this.options.excludeColorDepth||e.addPreprocessedComponent({key:"color_depth",value:window.screen.colorDepth||-1}),e},deviceMemoryKey:function(e){return this.options.excludeDeviceMemory||e.addPreprocessedComponent({key:"device_memory",value:this.getDeviceMemory()}),e},getDeviceMemory:function(){return navigator.deviceMemory||-1},pixelRatioKey:function(e){return this.options.excludePixelRatio||e.addPreprocessedComponent({key:"pixel_ratio",value:this.getPixelRatio()}),e},getPixelRatio:function(){return window.devicePixelRatio||""},screenResolutionKey:function(e){return this.options.excludeScreenResolution?e:this.getScreenResolution(e)},getScreenResolution:function(e){var t;return t=this.options.detectScreenOrientation&&window.screen.height>window.screen.width?[window.screen.height,window.screen.width]:[window.screen.width,window.screen.height],e.addPreprocessedComponent({key:"resolution",value:t}),e},availableScreenResolutionKey:function(e){return this.options.excludeAvailableScreenResolution?e:this.getAvailableScreenResolution(e)},getAvailableScreenResolution:function(e){var t;return window.screen.availWidth&&window.screen.availHeight&&(t=this.options.detectScreenOrientation?window.screen.availHeight>window.screen.availWidth?[window.screen.availHeight,window.screen.availWidth]:[window.screen.availWidth,window.screen.availHeight]:[window.screen.availHeight,window.screen.availWidth]),void 0!==t&&e.addPreprocessedComponent({key:"available_resolution",value:t}),e},timezoneOffsetKey:function(e){return this.options.excludeTimezoneOffset||e.addPreprocessedComponent({key:"timezone_offset",value:(new Date).getTimezoneOffset()}),e},sessionStorageKey:function(e){return!this.options.excludeSessionStorage&&this.hasSessionStorage()&&e.addPreprocessedComponent({key:"session_storage",value:1}),e},localStorageKey:function(e){return!this.options.excludeSessionStorage&&this.hasLocalStorage()&&e.addPreprocessedComponent({key:"local_storage",value:1}),e},indexedDbKey:function(e){return!this.options.excludeIndexedDB&&this.hasIndexedDB()&&e.addPreprocessedComponent({key:"indexed_db",value:1}),e},addBehaviorKey:function(e){return document.body&&!this.options.excludeAddBehavior&&document.body.addBehavior&&e.addPreprocessedComponent({key:"add_behavior",value:1}),e},openDatabaseKey:function(e){return!this.options.excludeOpenDatabase&&window.openDatabase&&e.addPreprocessedComponent({key:"open_database",value:1}),e},cpuClassKey:function(e){return this.options.excludeCpuClass||e.addPreprocessedComponent({key:"cpu_class",value:this.getNavigatorCpuClass()}),e},platformKey:function(e){return this.options.excludePlatform||e.addPreprocessedComponent({key:"navigator_platform",value:this.getNavigatorPlatform()}),e},doNotTrackKey:function(e){return this.options.excludeDoNotTrack||e.addPreprocessedComponent({key:"do_not_track",value:this.getDoNotTrack()}),e},canvasKey:function(e){return!this.options.excludeCanvas&&this.isCanvasSupported()&&e.addPreprocessedComponent({key:"canvas",value:this.getCanvasFp()}),e},webglKey:function(e){return!this.options.excludeWebGL&&this.isWebGlSupported()&&e.addPreprocessedComponent({key:"webgl",value:this.getWebglFp()}),e},webglVendorAndRendererKey:function(e){return!this.options.excludeWebGLVendorAndRenderer&&this.isWebGlSupported()&&e.addPreprocessedComponent({key:"webgl_vendor",value:this.getWebglVendorAndRenderer()}),e},adBlockKey:function(e){return this.options.excludeAdBlock||e.addPreprocessedComponent({key:"adblock",value:this.getAdBlock()}),e},hasLiedLanguagesKey:function(e){return this.options.excludeHasLiedLanguages||e.addPreprocessedComponent({key:"has_lied_languages",value:this.getHasLiedLanguages()}),e},hasLiedResolutionKey:function(e){return this.options.excludeHasLiedResolution||e.addPreprocessedComponent({key:"has_lied_resolution",value:this.getHasLiedResolution()}),e},hasLiedOsKey:function(e){return this.options.excludeHasLiedOs||e.addPreprocessedComponent({key:"has_lied_os",value:this.getHasLiedOs()}),e},hasLiedBrowserKey:function(e){return this.options.excludeHasLiedBrowser||e.addPreprocessedComponent({key:"has_lied_browser",value:this.getHasLiedBrowser()}),e},fontsKey:function(e,t){return this.options.excludeJsFonts?this.flashFontsKey(e,t):this.jsFontsKey(e,t)},flashFontsKey:function(e,t){return this.options.excludeFlashFonts?t(e):this.hasSwfObjectLoaded()&&this.hasMinFlashInstalled()?"undefined"==typeof this.options.swfPath?t(e):void this.loadSwfAndDetectFonts(function(n){e.addPreprocessedComponent({key:"swf_fonts",value:n.join(";")}),t(e)}):t(e)},jsFontsKey:function(e,t){var n=this;return setTimeout(function(){var r=["monospace","sans-serif","serif"],o=["Andale Mono","Arial","Arial Black","Arial Hebrew","Arial MT","Arial Narrow","Arial Rounded MT Bold","Arial Unicode MS","Bitstream Vera Sans Mono","Book Antiqua","Bookman Old Style","Calibri","Cambria","Cambria Math","Century","Century Gothic","Century Schoolbook","Comic Sans","Comic Sans MS","Consolas","Courier","Courier New","Garamond","Geneva","Georgia","Helvetica","Helvetica Neue","Impact","Lucida Bright","Lucida Calligraphy","Lucida Console","Lucida Fax","LUCIDA GRANDE","Lucida Handwriting","Lucida Sans","Lucida Sans Typewriter","Lucida Sans Unicode","Microsoft Sans Serif","Monaco","Monotype Corsiva","MS Gothic","MS Outlook","MS PGothic","MS Reference Sans Serif","MS Sans Serif","MS Serif","MYRIAD","MYRIAD PRO","Palatino","Palatino Linotype","Segoe Print","Segoe Script","Segoe UI","Segoe UI Light","Segoe UI Semibold","Segoe UI Symbol","Tahoma","Times","Times New Roman","Times New Roman PS","Trebuchet MS","Verdana","Wingdings","Wingdings 2","Wingdings 3"],i=["Abadi MT Condensed Light","Academy Engraved LET","ADOBE CASLON PRO","Adobe Garamond","ADOBE GARAMOND PRO","Agency FB","Aharoni","Albertus Extra Bold","Albertus Medium","Algerian","Amazone BT","American Typewriter","American Typewriter Condensed","AmerType Md BT","Andalus","Angsana New","AngsanaUPC","Antique Olive","Aparajita","Apple Chancery","Apple Color Emoji","Apple SD Gothic Neo","Arabic Typesetting","ARCHER","ARNO PRO","Arrus BT","Aurora Cn BT","AvantGarde Bk BT","AvantGarde Md BT","AVENIR","Ayuthaya","Bandy","Bangla Sangam MN","Bank Gothic","BankGothic Md BT","Baskerville","Baskerville Old Face","Batang","BatangChe","Bauer Bodoni","Bauhaus 93","Bazooka","Bell MT","Bembo","Benguiat Bk BT","Berlin Sans FB","Berlin Sans FB Demi","Bernard MT Condensed","BernhardFashion BT","BernhardMod BT","Big Caslon","BinnerD","Blackadder ITC","BlairMdITC TT","Bodoni 72","Bodoni 72 Oldstyle","Bodoni 72 Smallcaps","Bodoni MT","Bodoni MT Black","Bodoni MT Condensed","Bodoni MT Poster Compressed","Bookshelf Symbol 7","Boulder","Bradley Hand","Bradley Hand ITC","Bremen Bd BT","Britannic Bold","Broadway","Browallia New","BrowalliaUPC","Brush Script MT","Californian FB","Calisto MT","Calligrapher","Candara","CaslonOpnface BT","Castellar","Centaur","Cezanne","CG Omega","CG Times","Chalkboard","Chalkboard SE","Chalkduster","Charlesworth","Charter Bd BT","Charter BT","Chaucer","ChelthmITC Bk BT","Chiller","Clarendon","Clarendon Condensed","CloisterBlack BT","Cochin","Colonna MT","Constantia","Cooper Black","Copperplate","Copperplate Gothic","Copperplate Gothic Bold","Copperplate Gothic Light","CopperplGoth Bd BT","Corbel","Cordia New","CordiaUPC","Cornerstone","Coronet","Cuckoo","Curlz MT","DaunPenh","Dauphin","David","DB LCD Temp","DELICIOUS","Denmark","DFKai-SB","Didot","DilleniaUPC","DIN","DokChampa","Dotum","DotumChe","Ebrima","Edwardian Script ITC","Elephant","English 111 Vivace BT","Engravers MT","EngraversGothic BT","Eras Bold ITC","Eras Demi ITC","Eras Light ITC","Eras Medium ITC","EucrosiaUPC","Euphemia","Euphemia UCAS","EUROSTILE","Exotc350 Bd BT","FangSong","Felix Titling","Fixedsys","FONTIN","Footlight MT Light","Forte","FrankRuehl","Fransiscan","Freefrm721 Blk BT","FreesiaUPC","Freestyle Script","French Script MT","FrnkGothITC Bk BT","Fruitger","FRUTIGER","Futura","Futura Bk BT","Futura Lt BT","Futura Md BT","Futura ZBlk BT","FuturaBlack BT","Gabriola","Galliard BT","Gautami","Geeza Pro","Geometr231 BT","Geometr231 Hv BT","Geometr231 Lt BT","GeoSlab 703 Lt BT","GeoSlab 703 XBd BT","Gigi","Gill Sans","Gill Sans MT","Gill Sans MT Condensed","Gill Sans MT Ext Condensed Bold","Gill Sans Ultra Bold","Gill Sans Ultra Bold Condensed","Gisha","Gloucester MT Extra Condensed","GOTHAM","GOTHAM BOLD","Goudy Old Style","Goudy Stout","GoudyHandtooled BT","GoudyOLSt BT","Gujarati Sangam MN","Gulim","GulimChe","Gungsuh","GungsuhChe","Gurmukhi MN","Haettenschweiler","Harlow Solid Italic","Harrington","Heather","Heiti SC","Heiti TC","HELV","Herald","High Tower Text","Hiragino Kaku Gothic ProN","Hiragino Mincho ProN","Hoefler Text","Humanst 521 Cn BT","Humanst521 BT","Humanst521 Lt BT","Imprint MT Shadow","Incised901 Bd BT","Incised901 BT","Incised901 Lt BT","INCONSOLATA","Informal Roman","Informal011 BT","INTERSTATE","IrisUPC","Iskoola Pota","JasmineUPC","Jazz LET","Jenson","Jester","Jokerman","Juice ITC","Kabel Bk BT","Kabel Ult BT","Kailasa","KaiTi","Kalinga","Kannada Sangam MN","Kartika","Kaufmann Bd BT","Kaufmann BT","Khmer UI","KodchiangUPC","Kokila","Korinna BT","Kristen ITC","Krungthep","Kunstler Script","Lao UI","Latha","Leelawadee","Letter Gothic","Levenim MT","LilyUPC","Lithograph","Lithograph Light","Long Island","Lydian BT","Magneto","Maiandra GD","Malayalam Sangam MN","Malgun Gothic","Mangal","Marigold","Marion","Marker Felt","Market","Marlett","Matisse ITC","Matura MT Script Capitals","Meiryo","Meiryo UI","Microsoft Himalaya","Microsoft JhengHei","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Uighur","Microsoft YaHei","Microsoft Yi Baiti","MingLiU","MingLiU_HKSCS","MingLiU_HKSCS-ExtB","MingLiU-ExtB","Minion","Minion Pro","Miriam","Miriam Fixed","Mistral","Modern","Modern No. 20","Mona Lisa Solid ITC TT","Mongolian Baiti","MONO","MoolBoran","Mrs Eaves","MS LineDraw","MS Mincho","MS PMincho","MS Reference Specialty","MS UI Gothic","MT Extra","MUSEO","MV Boli","Nadeem","Narkisim","NEVIS","News Gothic","News GothicMT","NewsGoth BT","Niagara Engraved","Niagara Solid","Noteworthy","NSimSun","Nyala","OCR A Extended","Old Century","Old English Text MT","Onyx","Onyx BT","OPTIMA","Oriya Sangam MN","OSAKA","OzHandicraft BT","Palace Script MT","Papyrus","Parchment","Party LET","Pegasus","Perpetua","Perpetua Titling MT","PetitaBold","Pickwick","Plantagenet Cherokee","Playbill","PMingLiU","PMingLiU-ExtB","Poor Richard","Poster","PosterBodoni BT","PRINCETOWN LET","Pristina","PTBarnum BT","Pythagoras","Raavi","Rage Italic","Ravie","Ribbon131 Bd BT","Rockwell","Rockwell Condensed","Rockwell Extra Bold","Rod","Roman","Sakkal Majalla","Santa Fe LET","Savoye LET","Sceptre","Script","Script MT Bold","SCRIPTINA","Serifa","Serifa BT","Serifa Th BT","ShelleyVolante BT","Sherwood","Shonar Bangla","Showcard Gothic","Shruti","Signboard","SILKSCREEN","SimHei","Simplified Arabic","Simplified Arabic Fixed","SimSun","SimSun-ExtB","Sinhala Sangam MN","Sketch Rockwell","Skia","Small Fonts","Snap ITC","Snell Roundhand","Socket","Souvenir Lt BT","Staccato222 BT","Steamer","Stencil","Storybook","Styllo","Subway","Swis721 BlkEx BT","Swiss911 XCm BT","Sylfaen","Synchro LET","System","Tamil Sangam MN","Technical","Teletype","Telugu Sangam MN","Tempus Sans ITC","Terminal","Thonburi","Traditional Arabic","Trajan","TRAJAN PRO","Tristan","Tubular","Tunga","Tw Cen MT","Tw Cen MT Condensed","Tw Cen MT Condensed Extra Bold","TypoUpright BT","Unicorn","Univers","Univers CE 55 Medium","Univers Condensed","Utsaah","Vagabond","Vani","Vijaya","Viner Hand ITC","VisualUI","Vivaldi","Vladimir Script","Vrinda","Westminster","WHITNEY","Wide Latin","ZapfEllipt BT","ZapfHumnst BT","ZapfHumnst Dm BT","Zapfino","Zurich BlkEx BT","Zurich Ex BT","ZWAdobeF"];n.options.extendedJsFonts&&(o=o.concat(i)),o=o.concat(n.options.userDefinedFonts);var a=document.getElementsByTagName("body")[0],s=document.createElement("div"),u=document.createElement("div"),c={},l={},f=function(){var e=document.createElement("span");return e.style.position="absolute",e.style.left="-9999px",e.style.fontSize="72px",e.style.lineHeight="normal",e.innerHTML="mmmmmmmmmmlli",e},d=function(e,t){var n=f();return n.style.fontFamily="'"+e+"',"+t,n},h=function(){for(var e=[],t=0,n=r.length;t<n;t++){var o=f();o.style.fontFamily=r[t],s.appendChild(o),e.push(o)}return e}();a.appendChild(s);for(var p=0,g=r.length;p<g;p++)c[r[p]]=h[p].offsetWidth,l[r[p]]=h[p].offsetHeight;var _=function(){for(var e={},t=0,n=o.length;t<n;t++){for(var i=[],a=0,s=r.length;a<s;a++){var c=d(o[t],r[a]);u.appendChild(c),i.push(c)}e[o[t]]=i}return e}();a.appendChild(u);for(var y=[],m=0,v=o.length;m<v;m++)(function(e){for(var t=!1,n=0;n<r.length;n++)if(t=e[n].offsetWidth!==c[r[n]]||e[n].offsetHeight!==l[r[n]])return t;return t})(_[o[m]])&&y.push(o[m]);a.removeChild(u),a.removeChild(s),e.addPreprocessedComponent({key:"js_fonts",value:y}),t(e)},1)},pluginsKey:function(e){return this.options.excludePlugins||(this.isIE()?this.options.excludeIEPlugins||e.addPreprocessedComponent({key:"ie_plugins",value:this.getIEPlugins()}):e.addPreprocessedComponent({key:"regular_plugins",value:this.getRegularPlugins()})),e},getRegularPlugins:function(){var e=[];if(navigator.plugins)for(var t=0,n=navigator.plugins.length;t<n;t++)navigator.plugins[t]&&e.push(navigator.plugins[t]);return this.pluginsShouldBeSorted()&&(e=e.sort(function(e,t){return e.name>t.name?1:e.name<t.name?-1:0})),this.map(e,function(e){var t=this.map(e,function(e){return[e.type,e.suffixes].join("~")}).join(",");return[e.name,e.description,t].join("::")},this)},getIEPlugins:function(){var e=[];if(Object.getOwnPropertyDescriptor&&Object.getOwnPropertyDescriptor(window,"ActiveXObject")||"ActiveXObject"in window){var t=["AcroPDF.PDF","Adodb.Stream","AgControl.AgControl","DevalVRXCtrl.DevalVRXCtrl.1","MacromediaFlashPaper.MacromediaFlashPaper","Msxml2.DOMDocument","Msxml2.XMLHTTP","PDF.PdfCtrl","QuickTime.QuickTime","QuickTimeCheckObject.QuickTimeCheck.1","RealPlayer","RealPlayer.RealPlayer(tm) ActiveX Control (32-bit)","RealVideo.RealVideo(tm) ActiveX Control (32-bit)","Scripting.Dictionary","SWCtl.SWCtl","Shell.UIHelper","ShockwaveFlash.ShockwaveFlash","Skype.Detection","TDCCtl.TDCCtl","WMPlayer.OCX","rmocx.RealPlayer G2 Control","rmocx.RealPlayer G2 Control.1"];e=this.map(t,function(e){try{return new window.ActiveXObject(e),e}catch(t){return null}})}return navigator.plugins&&(e=e.concat(this.getRegularPlugins())),e},pluginsShouldBeSorted:function(){for(var e=!1,t=0,n=this.options.sortPluginsFor.length;t<n;t++){var r=this.options.sortPluginsFor[t];if(navigator.userAgent.match(r)){e=!0;break}}return e},touchSupportKey:function(e){return this.options.excludeTouchSupport||e.addPreprocessedComponent({key:"touch_support",value:this.getTouchSupport()}),e},hardwareConcurrencyKey:function(e){return this.options.excludeHardwareConcurrency||e.addPreprocessedComponent({key:"hardware_concurrency",value:this.getHardwareConcurrency()}),e},hasSessionStorage:function(){try{return!!window.sessionStorage}catch(e){return!0}},hasLocalStorage:function(){try{return!!window.localStorage}catch(e){return!0}},hasIndexedDB:function(){try{return!!window.indexedDB}catch(e){return!0}},getHardwareConcurrency:function(){return navigator.hardwareConcurrency?navigator.hardwareConcurrency:"unknown"},getNavigatorCpuClass:function(){return navigator.cpuClass?navigator.cpuClass:"unknown"},getNavigatorPlatform:function(){return navigator.platform?navigator.platform:"unknown"},getDoNotTrack:function(){return navigator.doNotTrack?navigator.doNotTrack:navigator.msDoNotTrack?navigator.msDoNotTrack:window.doNotTrack?window.doNotTrack:"unknown"},getTouchSupport:function(){var e=0,t=!1;"undefined"!=typeof navigator.maxTouchPoints?e=navigator.maxTouchPoints:"undefined"!=typeof navigator.msMaxTouchPoints&&(e=navigator.msMaxTouchPoints);try{document.createEvent("TouchEvent"),t=!0}catch(n){}return[e,t,"ontouchstart"in window]},getCanvasFp:function(){var e=[],t=document.createElement("canvas");t.width=2e3,t.height=200,t.style.display="inline";var n=t.getContext("2d");n.rect(0,0,10,10),n.rect(2,2,6,6);try{e.push("canvas winding:"+(!1===n.isPointInPath(5,5,"evenodd")?"yes":"no"))}catch(r){}return n.textBaseline="alphabetic",n.fillStyle="#f60",n.fillRect(125,1,62,20),n.fillStyle="#069",this.options.dontUseFakeFontInCanvas?n.font="11pt Arial":n.font="11pt no-real-font-123",n.fillText("Cwm fjordbank glyphs vext quiz, ??",2,15),n.fillStyle="rgba(102, 204, 0, 0.2)",n.font="18pt Arial",n.fillText("Cwm fjordbank glyphs vext quiz, ??",4,45),n.globalCompositeOperation="multiply",n.fillStyle="rgb(255,0,255)",n.beginPath(),n.arc(50,50,50,0,2*Math.PI,!0),n.closePath(),n.fill(),n.fillStyle="rgb(0,255,255)",n.beginPath(),n.arc(100,50,50,0,2*Math.PI,!0),n.closePath(),n.fill(),n.fillStyle="rgb(255,255,0)",n.beginPath(),n.arc(75,100,50,0,2*Math.PI,!0),n.closePath(),n.fill(),n.fillStyle="rgb(255,0,255)",n.arc(75,75,75,0,2*Math.PI,!0),n.arc(75,75,25,0,2*Math.PI,!0),n.fill("evenodd"),t.toDataURL&&e.push("canvas fp:"+t.toDataURL()),e.join("~")},getWebglFp:function(){var e,t=function(t){return e.clearColor(0,0,0,1),e.enable(e.DEPTH_TEST),e.depthFunc(e.LEQUAL),e.clear(e.COLOR_BUFFER_BIT|e.DEPTH_BUFFER_BIT),"["+t[0]+", "+t[1]+"]"};if(!(e=this.getWebglCanvas()))return null;var n=[];try{var r=e.createBuffer()}catch(c){throw c.message+="|getWebglFp_2.1|",c}try{e.bindBuffer(e.ARRAY_BUFFER,r)}catch(c){throw c.message+="|getWebglFp_2.2|",c}try{var o=new Float32Array([-.2,-.9,0,.4,-.26,0,0,.732134444,0])}catch(c){throw c.message+="|getWebglFp_2.3|",c}try{e.bufferData(e.ARRAY_BUFFER,o,e.STATIC_DRAW)}catch(c){throw c.message+="|getWebglFp_2.4|",c}try{r.itemSize=3}catch(c){throw c.message+="|getWebglFp_2.5|",c}try{r.numItems=3}catch(c){throw c.message+="|getWebglFp_2.6|",c}try{var i=e.createProgram()}catch(c){throw c.message+="|getWebglFp_2.7|",c}try{var a=e.createShader(e.VERTEX_SHADER)}catch(c){throw c.message+="|getWebglFp_2.8|",c}try{e.shaderSource(a,"attribute vec2 attrVertex;varying vec2 varyinTexCoordinate;uniform vec2 uniformOffset;void main(){varyinTexCoordinate=attrVertex+uniformOffset;gl_Position=vec4(attrVertex,0,1);}")}catch(c){throw c.message+="|getWebglFp_2.9|",c}try{e.compileShader(a)}catch(c){throw c.message+="|getWebglFp_2.10|",c}try{var s=e.createShader(e.FRAGMENT_SHADER)}catch(c){throw c.message+="|getWebglFp_2.11|",c}try{e.shaderSource(s,"precision mediump float;varying vec2 varyinTexCoordinate;void main() {gl_FragColor=vec4(varyinTexCoordinate,0,1);}")}catch(c){throw c.message+="|getWebglFp_2.12|",c}try{e.compileShader(s)}catch(c){throw c.message+="|getWebglFp_2.13|",c}try{e.attachShader(i,a)}catch(c){throw c.message+="|getWebglFp_2.14|",c}try{e.attachShader(i,s)}catch(c){throw c.message+="|getWebglFp_2.15|",c}try{e.linkProgram(i)}catch(c){throw c.message+="|getWebglFp_2.16|",c}try{e.useProgram(i)}catch(c){throw c.message+="|getWebglFp_2.17|",c}try{i.vertexPosAttrib=e.getAttribLocation(i,"attrVertex")}catch(c){throw c.message+="|getWebglFp_2.18|",c}try{i.offsetUniform=e.getUniformLocation(i,"uniformOffset")}catch(c){throw c.message+="|getWebglFp_2.19|",c}try{e.enableVertexAttribArray(i.vertexPosArray)}catch(c){throw c.message+="|getWebglFp_2.20|",c}try{e.vertexAttribPointer(i.vertexPosAttrib,r.itemSize,e.FLOAT,!1,0,0)}catch(c){throw c.message+="|getWebglFp_2.21|",c}try{e.uniform2f(i.offsetUniform,1,1)}catch(c){throw c.message+="|getWebglFp_2.22|",c}try{e.drawArrays(e.TRIANGLE_STRIP,0,r.numItems)}catch(c){throw c.message+="|getWebglFp_2.23|",c}try{e.canvas&&e.canvas.toDataURL&&n.push(e.canvas.toDataURL()),n.push("extensions:"+(e.getSupportedExtensions()||[]).join(";")),n.push("webgl aliased line width range:"+t(e.getParameter(e.ALIASED_LINE_WIDTH_RANGE))),n.push("webgl aliased point size range:"+t(e.getParameter(e.ALIASED_POINT_SIZE_RANGE))),n.push("webgl alpha bits:"+e.getParameter(e.ALPHA_BITS)),n.push("webgl antialiasing:"+(e.getContextAttributes().antialias?"yes":"no")),n.push("webgl blue bits:"+e.getParameter(e.BLUE_BITS)),n.push("webgl depth bits:"+e.getParameter(e.DEPTH_BITS)),n.push("webgl green bits:"+e.getParameter(e.GREEN_BITS)),n.push("webgl max anisotropy:"+function(e){var t=e.getExtension("EXT_texture_filter_anisotropic")||e.getExtension("WEBKIT_EXT_texture_filter_anisotropic")||e.getExtension("MOZ_EXT_texture_filter_anisotropic");if(t){var n=e.getParameter(t.MAX_TEXTURE_MAX_ANISOTROPY_EXT);return 0===n&&(n=2),n}return null}(e)),n.push("webgl max combined texture image units:"+e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS)),n.push("webgl max cube map texture size:"+e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE)),n.push("webgl max fragment uniform vectors:"+e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS)),n.push("webgl max render buffer size:"+e.getParameter(e.MAX_RENDERBUFFER_SIZE)),n.push("webgl max texture image units:"+e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS)),n.push("webgl max texture size:"+e.getParameter(e.MAX_TEXTURE_SIZE)),n.push("webgl max varying vectors:"+e.getParameter(e.MAX_VARYING_VECTORS)),n.push("webgl max vertex attribs:"+e.getParameter(e.MAX_VERTEX_ATTRIBS)),n.push("webgl max vertex texture image units:"+e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS)),n.push("webgl max vertex uniform vectors:"+e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS)),n.push("webgl max viewport dims:"+t(e.getParameter(e.MAX_VIEWPORT_DIMS))),n.push("webgl red bits:"+e.getParameter(e.RED_BITS)),n.push("webgl renderer:"+e.getParameter(e.RENDERER)),n.push("webgl shading language version:"+e.getParameter(e.SHADING_LANGUAGE_VERSION)),n.push("webgl stencil bits:"+e.getParameter(e.STENCIL_BITS)),n.push("webgl vendor:"+e.getParameter(e.VENDOR)),n.push("webgl version:"+e.getParameter(e.VERSION))}catch(c){throw c.message+="|getWebglFp_3|",c}try{var u=e.getExtension("WEBGL_debug_renderer_info");u&&(n.push("webgl unmasked vendor:"+e.getParameter(u.UNMASKED_VENDOR_WEBGL)),n.push("webgl unmasked renderer:"+e.getParameter(u.UNMASKED_RENDERER_WEBGL)))}catch(l){}if(!e.getShaderPrecisionFormat)return n.join("~");try{n.push("webgl vertex shader high float precision:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision),n.push("webgl vertex shader high float precision rangeMin:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).rangeMin),n.push("webgl vertex shader high float precision rangeMax:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).rangeMax),n.push("webgl vertex shader medium float precision:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision),n.push("webgl vertex shader medium float precision rangeMin:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).rangeMin),n.push("webgl vertex shader medium float precision rangeMax:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).rangeMax),n.push("webgl vertex shader low float precision:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.LOW_FLOAT).precision),n.push("webgl vertex shader low float precision rangeMin:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.LOW_FLOAT).rangeMin),n.push("webgl vertex shader low float precision rangeMax:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.LOW_FLOAT).rangeMax),n.push("webgl fragment shader high float precision:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision),n.push("webgl fragment shader high float precision rangeMin:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).rangeMin),n.push("webgl fragment shader high float precision rangeMax:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).rangeMax),n.push("webgl fragment shader medium float precision:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision),n.push("webgl fragment shader medium float precision rangeMin:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).rangeMin),n.push("webgl fragment shader medium float precision rangeMax:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).rangeMax),n.push("webgl fragment shader low float precision:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.LOW_FLOAT).precision),n.push("webgl fragment shader low float precision rangeMin:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.LOW_FLOAT).rangeMin),n.push("webgl fragment shader low float precision rangeMax:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.LOW_FLOAT).rangeMax),n.push("webgl vertex shader high int precision:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_INT).precision),n.push("webgl vertex shader high int precision rangeMin:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_INT).rangeMin),n.push("webgl vertex shader high int precision rangeMax:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_INT).rangeMax),n.push("webgl vertex shader medium int precision:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_INT).precision),n.push("webgl vertex shader medium int precision rangeMin:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_INT).rangeMin),n.push("webgl vertex shader medium int precision rangeMax:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_INT).rangeMax),n.push("webgl vertex shader low int precision:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.LOW_INT).precision),n.push("webgl vertex shader low int precision rangeMin:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.LOW_INT).rangeMin),n.push("webgl vertex shader low int precision rangeMax:"+e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.LOW_INT).rangeMax),n.push("webgl fragment shader high int precision:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_INT).precision),n.push("webgl fragment shader high int precision rangeMin:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_INT).rangeMin),n.push("webgl fragment shader high int precision rangeMax:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_INT).rangeMax),n.push("webgl fragment shader medium int precision:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_INT).precision),n.push("webgl fragment shader medium int precision rangeMin:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_INT).rangeMin),n.push("webgl fragment shader medium int precision rangeMax:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_INT).rangeMax),n.push("webgl fragment shader low int precision:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.LOW_INT).precision),n.push("webgl fragment shader low int precision rangeMin:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.LOW_INT).rangeMin),n.push("webgl fragment shader low int precision rangeMax:"+e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.LOW_INT).rangeMax)}catch(c){throw c.message+="|getWebglFp_4|",c}return n.join("~")},getWebglVendorAndRenderer:function(){try{var e=this.getWebglCanvas(),t=e.getExtension("WEBGL_debug_renderer_info");return e.getParameter(t.UNMASKED_VENDOR_WEBGL)+"~"+e.getParameter(t.UNMASKED_RENDERER_WEBGL)}catch(n){return""}},getAdBlock:function(){var e=document.createElement("div");e.innerHTML="&nbsp;",e.className="adsbox";var t=!1;try{document.body.appendChild(e),t=0===document.getElementsByClassName("adsbox")[0].offsetHeight,document.body.removeChild(e)}catch(n){t=!1}return t},getHasLiedLanguages:function(){if("undefined"!=typeof navigator.languages)try{if(navigator.languages[0].substr(0,2)!==navigator.language.substr(0,2))return!0}catch(e){return!0}return!1},getHasLiedResolution:function(){return window.screen.width<window.screen.availWidth||window.screen.height<window.screen.availHeight},getHasLiedOs:function(){var e,t=navigator.userAgent.toLowerCase(),n=navigator.oscpu,r=navigator.platform.toLowerCase();e=t.indexOf("windows phone")>=0?"Windows Phone":t.indexOf("win")>=0?"Windows":t.indexOf("android")>=0?"Android":t.indexOf("linux")>=0?"Linux":t.indexOf("iphone")>=0||t.indexOf("ipad")>=0?"iOS":t.indexOf("mac")>=0?"Mac":"Other";if(("ontouchstart"in window||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0)&&"Windows Phone"!==e&&"Android"!==e&&"iOS"!==e&&"Other"!==e)return!0;if(void 0!==n){if(n=n.toLowerCase(),n.indexOf("win")>=0&&"Windows"!==e&&"Windows Phone"!==e)return!0;if(n.indexOf("linux")>=0&&"Linux"!==e&&"Android"!==e)return!0;if(n.indexOf("mac")>=0&&"Mac"!==e&&"iOS"!==e)return!0;if((-1===n.indexOf("win")&&-1===n.indexOf("linux")&&-1===n.indexOf("mac"))!=("Other"===e))return!0}return r.indexOf("win")>=0&&"Windows"!==e&&"Windows Phone"!==e||((r.indexOf("linux")>=0||r.indexOf("android")>=0||r.indexOf("pike")>=0)&&"Linux"!==e&&"Android"!==e||((r.indexOf("mac")>=0||r.indexOf("ipad")>=0||r.indexOf("ipod")>=0||r.indexOf("iphone")>=0)&&"Mac"!==e&&"iOS"!==e||((-1===r.indexOf("win")&&-1===r.indexOf("linux")&&-1===r.indexOf("mac"))!=("Other"===e)||"undefined"==typeof navigator.plugins&&"Windows"!==e&&"Windows Phone"!==e)))},getHasLiedBrowser:function(){var e,t=navigator.userAgent.toLowerCase(),n=navigator.productSub;if(("Chrome"===(e=t.indexOf("firefox")>=0?"Firefox":t.indexOf("opera")>=0||t.indexOf("opr")>=0?"Opera":t.indexOf("chrome")>=0?"Chrome":t.indexOf("safari")>=0?"Safari":t.indexOf("trident")>=0?"Internet Explorer":"Other")||"Safari"===e||"Opera"===e)&&"20030107"!==n)return!0;var r=eval.toString().length;if(37===r&&"Safari"!==e&&"Firefox"!==e&&"Other"!==e)return!0;if(39===r&&"Internet Explorer"!==e&&"Other"!==e)return!0;if(33===r&&"Chrome"!==e&&"Opera"!==e&&"Other"!==e)return!0;var o;try{throw"a"}catch(i){try{i.toSource(),o=!0}catch(a){o=!1}}return!(!o||"Firefox"===e||"Other"===e)},isCanvasSupported:function(){var e=document.createElement("canvas");return!(!e.getContext||!e.getContext("2d"))},isWebGlSupported:function(){if(!this.isCanvasSupported())return!1;var e=this.getWebglCanvas();return!!window.WebGLRenderingContext&&!!e},isIE:function(){return"Microsoft Internet Explorer"===navigator.appName||!("Netscape"!==navigator.appName||!/Trident/.test(navigator.userAgent))},hasSwfObjectLoaded:function(){return"undefined"!=typeof window.swfobject},hasMinFlashInstalled:function(){return window.swfobject.hasFlashPlayerVersion("9.0.0")},addFlashDivNode:function(){var e=document.createElement("div");e.setAttribute("id",this.options.swfContainerId),document.body.appendChild(e)},loadSwfAndDetectFonts:function(e){window.___fp_swf_loaded=function(t){e(t)};var t=this.options.swfContainerId;this.addFlashDivNode();var n={onReady:"___fp_swf_loaded"},r={allowScriptAccess:"always",menu:"false"};window.swfobject.embedSWF(this.options.swfPath,t,"1","1","9.0.0",!1,n,r,{})},getWebglCanvas:function(){try{var e=document.createElement("canvas"),t=null;try{t=e.getContext("webgl")||e.getContext("experimental-webgl")}catch(n){}return t||(t=null),t}catch(r){throw r.message+="|getWebglCanvas|",r}},each:function(e,t,n){if(null!==e)if(this.nativeForEach&&e.forEach===this.nativeForEach)e.forEach(t,n);else if(e.length===+e.length){for(var r=0,o=e.length;r<o;r++)if(t.call(n,e[r],r,e)==={})return}else for(var i in e)if(e.hasOwnProperty(i)&&t.call(n,e[i],i,e)==={})return},map:function(e,t,n){var r=[];return null==e?r:this.nativeMap&&e.map===this.nativeMap?e.map(t,n):(this.each(e,function(e,o,i){r[r.length]=t.call(n,e,o,i)}),r)},x64Add:function(e,t){e=[e[0]>>>16,65535&e[0],e[1]>>>16,65535&e[1]],t=[t[0]>>>16,65535&t[0],t[1]>>>16,65535&t[1]];var n=[0,0,0,0];return n[3]+=e[3]+t[3],n[2]+=n[3]>>>16,n[3]&=65535,n[2]+=e[2]+t[2],n[1]+=n[2]>>>16,n[2]&=65535,n[1]+=e[1]+t[1],n[0]+=n[1]>>>16,n[1]&=65535,n[0]+=e[0]+t[0],n[0]&=65535,[n[0]<<16|n[1],n[2]<<16|n[3]]},x64Multiply:function(e,t){e=[e[0]>>>16,65535&e[0],e[1]>>>16,65535&e[1]],t=[t[0]>>>16,65535&t[0],t[1]>>>16,65535&t[1]];var n=[0,0,0,0];return n[3]+=e[3]*t[3],n[2]+=n[3]>>>16,n[3]&=65535,n[2]+=e[2]*t[3],n[1]+=n[2]>>>16,n[2]&=65535,n[2]+=e[3]*t[2],n[1]+=n[2]>>>16,n[2]&=65535,n[1]+=e[1]*t[3],n[0]+=n[1]>>>16,n[1]&=65535,n[1]+=e[2]*t[2],n[0]+=n[1]>>>16,n[1]&=65535,n[1]+=e[3]*t[1],n[0]+=n[1]>>>16,n[1]&=65535,n[0]+=e[0]*t[3]+e[1]*t[2]+e[2]*t[1]+e[3]*t[0],n[0]&=65535,[n[0]<<16|n[1],n[2]<<16|n[3]]},x64Rotl:function(e,t){return t%=64,32===t?[e[1],e[0]]:t<32?[e[0]<<t|e[1]>>>32-t,e[1]<<t|e[0]>>>32-t]:(t-=32,[e[1]<<t|e[0]>>>32-t,e[0]<<t|e[1]>>>32-t])},x64LeftShift:function(e,t){return t%=64,0===t?e:t<32?[e[0]<<t|e[1]>>>32-t,e[1]<<t]:[e[1]<<t-32,0]},x64Xor:function(e,t){return[e[0]^t[0],e[1]^t[1]]},x64Fmix:function(e){return e=this.x64Xor(e,[0,e[0]>>>1]),e=this.x64Multiply(e,[4283543511,3981806797]),e=this.x64Xor(e,[0,e[0]>>>1]),e=this.x64Multiply(e,[3301882366,444984403]),e=this.x64Xor(e,[0,e[0]>>>1])},x64hash128:function(e,t){e=e||"",t=t||0;for(var n=e.length%16,r=e.length-n,o=[0,t],i=[0,t],a=[0,0],s=[0,0],u=[2277735313,289559509],c=[1291169091,658871167],l=0;l<r;l+=16)a=[255&e.charCodeAt(l+4)|(255&e.charCodeAt(l+5))<<8|(255&e.charCodeAt(l+6))<<16|(255&e.charCodeAt(l+7))<<24,255&e.charCodeAt(l)|(255&e.charCodeAt(l+1))<<8|(255&e.charCodeAt(l+2))<<16|(255&e.charCodeAt(l+3))<<24],s=[255&e.charCodeAt(l+12)|(255&e.charCodeAt(l+13))<<8|(255&e.charCodeAt(l+14))<<16|(255&e.charCodeAt(l+15))<<24,255&e.charCodeAt(l+8)|(255&e.charCodeAt(l+9))<<8|(255&e.charCodeAt(l+10))<<16|(255&e.charCodeAt(l+11))<<24],a=this.x64Multiply(a,u),a=this.x64Rotl(a,31),a=this.x64Multiply(a,c),o=this.x64Xor(o,a),o=this.x64Rotl(o,27),o=this.x64Add(o,i),o=this.x64Add(this.x64Multiply(o,[0,5]),[0,1390208809]),s=this.x64Multiply(s,c),s=this.x64Rotl(s,33),s=this.x64Multiply(s,u),i=this.x64Xor(i,s),i=this.x64Rotl(i,31),i=this.x64Add(i,o),i=this.x64Add(this.x64Multiply(i,[0,5]),[0,944331445]);switch(a=[0,0],s=[0,0],n){case 15:s=this.x64Xor(s,this.x64LeftShift([0,e.charCodeAt(l+14)],48));case 14:s=this.x64Xor(s,this.x64LeftShift([0,e.charCodeAt(l+13)],40));case 13:s=this.x64Xor(s,this.x64LeftShift([0,e.charCodeAt(l+12)],32));case 12:s=this.x64Xor(s,this.x64LeftShift([0,e.charCodeAt(l+11)],24));case 11:s=this.x64Xor(s,this.x64LeftShift([0,e.charCodeAt(l+10)],16));case 10:s=this.x64Xor(s,this.x64LeftShift([0,e.charCodeAt(l+9)],8));case 9:s=this.x64Xor(s,[0,e.charCodeAt(l+8)]),s=this.x64Multiply(s,c),s=this.x64Rotl(s,33),s=this.x64Multiply(s,u),i=this.x64Xor(i,s);case 8:a=this.x64Xor(a,this.x64LeftShift([0,e.charCodeAt(l+7)],56));case 7:a=this.x64Xor(a,this.x64LeftShift([0,e.charCodeAt(l+6)],48));case 6:a=this.x64Xor(a,this.x64LeftShift([0,e.charCodeAt(l+5)],40));case 5:a=this.x64Xor(a,this.x64LeftShift([0,e.charCodeAt(l+4)],32));case 4:a=this.x64Xor(a,this.x64LeftShift([0,e.charCodeAt(l+3)],24));case 3:a=this.x64Xor(a,this.x64LeftShift([0,e.charCodeAt(l+2)],16));case 2:a=this.x64Xor(a,this.x64LeftShift([0,e.charCodeAt(l+1)],8));case 1:a=this.x64Xor(a,[0,e.charCodeAt(l)]),a=this.x64Multiply(a,u),a=this.x64Rotl(a,31),a=this.x64Multiply(a,c),o=this.x64Xor(o,a)}return o=this.x64Xor(o,[0,e.length]),i=this.x64Xor(i,[0,e.length]),o=this.x64Add(o,i),i=this.x64Add(i,o),o=this.x64Fmix(o),i=this.x64Fmix(i),o=this.x64Add(o,i),i=this.x64Add(i,o),("00000000"+(o[0]>>>0).toString(16)).slice(-8)+("00000000"+(o[1]>>>0).toString(16)).slice(-8)+("00000000"+(i[0]>>>0).toString(16)).slice(-8)+("00000000"+(i[1]>>>0).toString(16)).slice(-8)}},e.VERSION="1.5.1",e})},function(e,t,n){"use strict";function r(){return!!("ontouchstart"in window||navigator.maxTouchPoints)}t.__esModule=!0,t["default"]=r},function(e,t,n){"use strict";function r(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t["default"]=e,t}t.__esModule=!0;var o=n(0),i=function(e){return e&&e.__esModule?e:{"default":e}}(o),a=n(3),s=r(a),u=n(10),c=r(u),l=["37","38","39","40"],f=new RegExp(/^[0-9]*$/),d={8:"BACKSPACE",9:"TAB",13:"ENTER",16:"SHIFT",17:"CTRL",18:"ALT",20:"CAPSLOCK",32:"SPACE",46:"DELETE"},h={0:"UN0",229:"UN1"},p=function(){function e(){var t=arguments.length>0&&arguments[0]!==undefined?arguments[0]:[];(0,i["default"])(this,e),this._inputFieldProps={},this._inputFieldLogsInfos={};for(var n=0,r=t.length;n<r;n++)this.addWatch(t[n])}return e.prototype.addWatch=function(e){this._hasNecessaryProp(e)&&(this._inputFieldProps[e.id]={element:document.getElementById(e.id)},this._initInputFieldLogInfos(e),this._setInitialValue(e.id),this._attachKeyEventHandler(e.id),this._attachInputDetectHandler(e.id))},e.prototype.removeWatch=function(e){var t=this._getProp(e),n=t.element;s.removeEventListener(n,"keydown",t.onKeydown),s.removeEventListener(n,"keyup",t.onKeyup),t.onInputChange?s.removeEventListener(n,"input",t.onInputChange):"onInputChangeTimer"in t&&clearInterval(t.onInputChangeTimer),delete this._inputFieldProps[e],delete this._inputFieldLogsInfos[e]},e.prototype.get=function(){var e=arguments.length>0&&arguments[0]!==undefined?arguments[0]:{},t=[],n=e.filter||[];for(var r in this._inputFieldLogsInfos)(0===n.length||c.indexOf(n,r)>-1)&&t.push({i:r,a:this._getKeyStrokeLogById(r),b:this._getInputIntervalLogById(r),c:this._getInitialValue(r),d:this._getCompleteValue(r),e:this._inputFieldLogsInfos[r].secureMode,f:this._inputFieldLogsInfos[r].hideValueMode});return t},e.prototype._getProp=function(e,t){var n=this._inputFieldProps[e];return t?n[t]:n},e.prototype._hasNecessaryProp=function(e){return e.id},e.prototype._getKeyStrokeLogById=function(e){var t=this._inputFieldLogsInfos[e],n=this._getLogs(t.keyStrokeLogs,t.keyStrokeLogLength);return c.map(n,function(e){return e.a+","+e.b+","+e.c+","+e.d})},e.prototype._getInputIntervalLogById=function(e){var t=this._inputFieldLogsInfos[e],n=this._getLogs(t.inputIntervalLogs,t.inputIntervalLogLength)||[];return{a:c.map(n,function(e){return e.a+","+e.c}),b:this._getLast(n,{d:0}).d}},e.prototype._getLast=function(e,t){return e&&0!==e.length?e[e.length-1]||t:t},e.prototype._getLogs=function(){var e=arguments.length>0&&arguments[0]!==undefined?arguments[0]:[],t=arguments[1];return e.length<=t?e:e.slice(e.length-t,e.length)},e.prototype._attachKeyEventHandler=function(e){var t=this._getProp(e),n=t.element,r=s.bind(this._keydownEventHandler,this,n),o=s.bind(this._keyupEventHandler,this,n);t.onKeydown=r,t.onKeyup=o,s.addEventListener(n,"keydown",r),s.addEventListener(n,"keyup",o)},e.prototype._attachInputDetectHandler=function(e){var t=this._getProp(e),n=t.element,r=s.bind(this._detectInputChange,this,n);"oninput"in n?(t.onInputChange=r,s.addEventListener(n,"input",r)):t.onInputChangeTimer=setInterval(r,50)},e.prototype._setInitialValue=function(e){var t=this._getProp(e),n=t.logInfos,r=t.element;n.secureMode?n.initialValue="":n.initialValue=r.value},e.prototype._getInitialValue=function(e){return this._inputFieldLogsInfos[e].initialValue},e.prototype._getCompleteValue=function(e){var t=this._inputFieldProps[e];return this._inputFieldLogsInfos[e].secureMode?"":t.element.value},e.prototype._initInputFieldLogInfos=function(e){var t={lastEventTime:0,keyIndex:0,keyStrokeLogs:[],downKeyMap:{},lastInputTime:(new Date).getTime(),lastInputText:"",inputIntervalLogs:[],inputIntervalLogIdx:0,initialValue:0,completeValue:0,keyStrokeLogLength:e.keyStrokeLogLength||65,inputIntervalLogLength:e.inputIntervalLogLength||30,secureMode:e.secureMode||!1,hideValueMode:e.hideValueMode||!1};this._inputFieldLogsInfos[e.id]=t,this._inputFieldProps[e.id].logInfos=t},e.prototype._detectInputChange=function(e,t){var n=e.value,r=(new Date).getTime(),o=this._inputFieldLogsInfos[e.id],i=o.secureMode,a=i||o.hideValueMode,s=void 0,u=void 0;o.lastInputText!==n&&(s=0===o.inputIntervalLogs.length?0:r-o.lastInputTime,u={a:s,c:a?"":n,d:o.inputIntervalLogIdx++,e:i?-1:n.length},o.inputIntervalLogs.push(u),o.lastInputTime=r,o.lastInputText=n),0===n.length&&(o.inputIntervalLogs=[])},e.prototype._keydownEventHandler=function(t){var n=arguments.length>1&&arguments[1]!==undefined?arguments[1]:window.event;if(!this._isValidKeyUpOrDownEvent(n))return!0;var r=this._getKeyCode(n.keyCode),o=this._inputFieldLogsInfos[t.id],i=this._isIMEKeyCode(r),a=(new Date).getTime(),s=0,u=null;return!!this._isArrowKey(r)||!(!i&&e._isAlreadyDown(o,r)&&!e._isDeleteCharKey(r))&&(u=this._getKeyInfo(o,r),0!==o.keyStrokeLogs.length&&(s=Math.max(0,a-o.lastEventTime)),o.lastEventTime=a,i||e._isAlreadyDown(o,r)||(o.downKeyMap[r]=u),o.keyStrokeLogs.push({a:s,b:"d",c:u,d:o.secureMode?"":""+n.keyCode}),!0)},e.prototype._keyupEventHandler=function(t){var n=arguments.length>1&&arguments[1]!==undefined?arguments[1]:window.event;if(!this._isValidKeyUpOrDownEvent(n))return!0;var r=this._getKeyCode(n.keyCode),o=this._inputFieldLogsInfos[t.id],i=this._isIMEKeyCode(r),a=(new Date).getTime(),s=0,u=null;return!!this._isArrowKey(r)||!(!i&&!e._isAlreadyDown(o,r))&&(u=i?h[r]:o.downKeyMap[r],delete o.downKeyMap[r],s=Math.max(0,a-o.lastEventTime),o.keyStrokeLogs.push({a:s,b:"u",c:u,d:o.secureMode?"":""+n.keyCode}),(e._isEmptyLog(o.keyStrokeLogs)||0===t.value.length)&&(o.keyStrokeLogs=[]),!0)},e.prototype._isValidKeyUpOrDownEvent=function(e){return e&&e.keyCode&&e.keyCode.toString},e.prototype._getKeyCode=function(e){var t=e.toString();return d[e]&&(t=d[e]),t},e.prototype._getKeyInfo=function(e,t){return this._isSpecialKey(t)?t:h[t]?h[t]:"i"+e.keyIndex++},e._isAlreadyDown=function(e,t){return e.downKeyMap[t]},e.prototype._isIMEKeyCode=function(e){return!!h[e]},e._isDeleteCharKey=function(e){return"BACKSPACE"===e||"DELETE"===e},e.prototype._isArrowKey=function(e){return!this._isSpecialKey(e)&&-1!==c.indexOf(l,e)},e.prototype._isSpecialKey=function(e){return!f.test(e)},e._isEmptyLog=function(e){return 0===e.length},e}();t["default"]=p},function(e,t,n){"use strict";t.__esModule=!0;var r=n(0),o=function(e){return e&&e.__esModule?e:{"default":e}}(r),i=n(35),a=n(3),s=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t["default"]=e,t}(a),u=s.objectAssign,c=function(){function e(){(0,o["default"])(this,e),this._isFirst=!0,this._firstOrientation={a:999,b:999,c:999},this._currentOrientation=u({},this._firstOrientation),s.bindAll(["_onDeviceOrientation"],this),window.DeviceOrientationEvent?s.addEventListener(window,"deviceorientation",this._onDeviceOrientation):(this._firstOrientation={a:777,b:777,c:777},this._currentOrientation=u({},this._firstOrientation))}return e.prototype.getCurrentOrientation=function(){return u({},this._currentOrientation)},e.prototype.get=function(){return{a:u({},this._firstOrientation),b:this.getCurrentOrientation()}},e.prototype._onDeviceOrientation=function(e){var t=e.alpha,n=e.beta,r=e.gamma,o={a:(0,i.refine)(t),b:(0,i.refine)(n),c:(0,i.refine)(r)};this._isFirst&&(this._isFirst=!1,this._firstOrientation=u({},o)),this._currentOrientation=u({},o),(0,i.isWrong)(this._currentOrientation)&&s.removeEventListener(window,"deviceorientation",this._onDeviceOrientation)},e}();t["default"]=c},function(e,t,n){"use strict";t.__esModule=!0;var r=n(0),o=function(e){return e&&e.__esModule?e:{"default":e}}(r),i=n(35),a=n(3),s=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t["default"]=e,t}(a),u=s.objectAssign,c=function(){function e(){(0,o["default"])(this,e),this._isFirst=!0,this._firstAcceleration={a:999,b:999,c:999},this._currentAcceleration=u({},this._firstAcceleration),this._firstAccelerationIncludingGravity=u({},this._firstAcceleration),this._currentAccelerationIncludingGravity=u({},this._firstAcceleration),s.bindAll(["_onDeviceMotion"],this),window.DeviceMotionEvent?s.addEventListener(window,"devicemotion",this._onDeviceMotion):(this._firstAcceleration={a:777,b:777,c:777},this._currentAcceleration=u({},this._firstAcceleration),this._firstAccelerationIncludingGravity=u({},this._firstAcceleration),this._currentAccelerationIncludingGravity=u({},this._firstAcceleration))}return e.prototype.get=function(){return{a:{a:u({},this._firstAcceleration),b:u({},this._firstAccelerationIncludingGravity)},b:{a:u({},this._currentAcceleration),b:u({},this._currentAccelerationIncludingGravity)}}},e.prototype._onDeviceMotion=function(e){var t=e.acceleration;t=t===undefined?{}:t;var n=t.x,r=t.y,o=t.z,a=e.accelerationIncludingGravity;a=a===undefined?{}:a;var c=a.x,l=a.y,f=a.z,d={a:(0,i.refine)(n),b:(0,i.refine)(r),c:(0,i.refine)(o)},h={a:(0,i.refine)(c),b:(0,i.refine)(l),c:(0,i.refine)(f)};this._isFirst&&(this._isFirst=!1,this._firstAcceleration=u({},d),this._firstAccelerationIncludingGravity=u({},h)),this._currentAcceleration=u({},d),this._currentAccelerationIncludingGravity=u({},h),(0,i.isWrong)(this._currentAcceleration)&&(0,i.isWrong)(this._currentAccelerationIncludingGravity)&&s.removeEventListener(window,"devicemotion",this._onDeviceMotion)},e}();t["default"]=c},function(e,t,n){"use strict";function r(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t["default"]=e,t}t.__esModule=!0;var o=n(0),i=function(e){return e&&e.__esModule?e:{"default":e}}(o),a=n(3),s=r(a),u=n(10),c=r(u),l=function(){function e(){var t=this,n=arguments.length>0&&arguments[0]!==undefined?arguments[0]:{};(0,i["default"])(this,e),this._count=0,this._errCount=0,this._mouse=[],this._temp=[],this._time=+new Date,this._totalInterval=-1,this._pageX=0,this._pageY=0,this._lastAbX=0,this._lastAbY=0,this._logLength=n.logLength||200,this._debounce=n.debounce||0,s.bindAll(["_flush"],this),this._wrappedOnMouseEvent=function(e){try{t._onMouseEvent(e)}catch(n){t._errCount++}},c.forEach(["mousemove","mousedown","mouseup"],function(e){s.addEventListener(document,e,t._wrappedOnMouseEvent)})}return e.prototype.get=function(){return{a:c.map(this._mouse,function(e){return e.b+"|"+e.c+"|"+e.d+"|"+e.e}),b:(this._mouse.pop()||{a:0}).a,c:this._lastAbX,d:this._lastAbY,e:this._totalInterval,f:this._errCount}},e.prototype._flush=function(){this._mouse=this._mouse.concat(this._temp).slice(-this._logLength),this._temp.length=0},e.prototype._onMouseEvent=function(e){var t=e.clientX,n=e.clientY,r=e.type,o=s.getDocumentElement(),i={mousemove:0,mousedown:1,mouseup:2}[r],a=o.scrollLeft||0,u=o.scrolTop||0,c=+new Date,l=c-this._time,f=t+a,d=n+u,h=this._refinePageDiff(f-this._pageX),p=this._refinePageDiff(d-this._pageY),g={a:this._count,b:i,c:l,d:h,e:p};this._count++,this._totalInterval+=l,this._time=c,this._pageX=f,this._pageY=d,this._lastAbX=this._refinePageDiff(f),this._lastAbY=this._refinePageDiff(d),this._temp.push(g),this._debounce?(clearTimeout(this._timeoutRef),this._timeoutRef=setTimeout(this._flush,this._debounce)):(this._mouse.push(g),this._mouse=this._mouse.slice(-this._logLength))},e.prototype._refinePageDiff=function(e){if(isNaN(parseFloat(e)))return 0;if(parseInt(e,10)===parseFloat(e))return e;try{return e.toFixed(3)}catch(t){return e}},e}();t["default"]=l},function(e,t,n){"use strict";function r(e,t){var n=null,r=null,o=null;if(!e)return"";try{o=s.stringify(e)}catch(a){return a.uuid=e.a,Error.set("Compress JSON Stringify nCaptcha",a).get()}try{r=i["default"].compressToEncodedURIComponent(o)}catch(a){return a.uuid=e.a,Error.set("Compress",a).get()}if("old"!==t)return r;try{n=s.stringify({uuid:e.a,encData:r})}catch(a){return a.uuid=e.a,Error.set("Compress JSON Stringify encNCaptcha",a).get()}return n}t.__esModule=!0,t["default"]=r;var o=n(34),i=function(e){return e&&e.__esModule?e:{"default":e}}(o),a=n(17),s=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t["default"]=e,t}(a)},function(e,t,n){"use strict";function r(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t["default"]=e,t}function o(e){return e&&e.__esModule?e:{"default":e}}function i(e,t){return e.match(new RegExp(".{1,"+t+"}","g"))}function a(){++b===w&&(E["s"+M]=S,E["u"+M]=x,E["t"+M]=T,C&&C(d["default"].compressToEncodedURIComponent(v.stringify(E))))}function s(e){e.match(/fail\|/)?(E.s=e,S++):e.match(/success/)||x++,a()}function u(e,t,n,r){b=0,S=0,T=0,x=0,M=e.type,A=t.mode,w=n.length,C=r,E={t:e.uuid,s:"",m:A,sb:0,sc:0,ub:0,uc:0,tnb:"b"===M?w:0,tnc:"c"===M?w:0}}function c(e){return"string"==typeof e&&0===e.indexOf(g.ERROR_PREFIX)||!e.body}function l(e,t,n){if(c(e)&&n)return void n(e);var r=t.url,o=t.chunkSize,l=t.timeout,f=y.map(i(e.body,o),function(t,n,r){return e.uuid+"|"+e.type+"|"+(n+1)+"|"+r.length+"|"+t});u(e,t,f,n),y.forEach(f,function(e){new p["default"]({timeout:l,ontimeout:function(e){return++T&&a(e)},onerror:function(e){return++x&&a(e)},onload:function(e){return s(e)}}).open("POST",r).setRequestHeader("Content-Type","text/plain").send(e)})}t.__esModule=!0,t["default"]=l;var f=n(34),d=o(f),h=n(104),p=o(h),g=n(33),_=n(10),y=r(_),m=n(17),v=r(m),w=void 0,b=void 0,S=void 0,T=void 0,x=void 0,E=void 0,M=void 0,A=void 0,C=void 0},function(e,t,n){"use strict";function r(e){return e&&e.__esModule?e:{"default":e}}t.__esModule=!0;var o=n(0),i=r(o),a=n(105),s=r(a),u=n(106),c=n(17),l=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t["default"]=e,t}(c),f=function(){function e(t){(0,i["default"])(this,e),this._prop=t,this.jsonp=!0,this._itf=new s["default"]}return e.prototype.setRequestHeader=function(e,t){if(/Content-Type/i.test(e))try{this._itf.contentType=t}catch(n){}return this._itf.setRequestHeader&&this._itf.setRequestHeader(e,t),this},e.prototype.open=function(e,t){var n=this,r=this._itf,o=this._prop,i=o.timeout,a=o.withCredentials;try{r.open(e,t,!0),r.timeout=i,r.withCredentials=a,r.ontimeout=function(e){return n._onTimeout(e)},r.onerror=function(e){return n._onError(e)},r.onload=function(e){return n._onLoad(n._itf)}}catch(s){this._onError()}return this},e.prototype.send=function(e){var t=this;(0,u.isAndroidLT444)()&&(this._timeoutref=setTimeout(function(){return t._clearCallback()},this._itf.timeout));try{this._itf.send("a="+e)}catch(n){}return this},e.prototype._clearCallback=function(e){return e.onload=null,e.onerror=null,e.ontimeout=null,clearTimeout(this._timeoutref),this},e.prototype._onTimeout=function(e){this._clearCallback(this._itf)._prop.ontimeout()},e.prototype._onError=function(e){this._clearCallback(this._itf)._prop.onerror()},e.prototype._onLoad=function(e){var t=e.response,n=e.responseText,r=(e.status,t||n);"string"!=typeof r&&(r=l.stringify(r)),this._clearCallback(this._itf)._prop.onload(r)},e}();t["default"]=f},function(e,t,n){"use strict";t.__esModule=!0;var r=n(0),o=function(e){return e&&e.__esModule?e:{"default":e}}(r),i=n(3),a=0,s=function(){function e(t){(0,o["default"])(this,e),this._prop=(0,i.objectAssign)({charset:"utf-8",callbackname:"callback",callback:null,prefix:"_kjcb_"},t),this.id=a++}return e.prototype.open=function(e,t,n){var r=this,o=document.createElement("script"),i=document.getElementsByTagName("head")[0],a=document.body,s=""+this._prop.prefix+this.id,u=this;if(!window[s]){o.type="text/javascript",o.charset=this._prop.charset;try{(i||a).appendChild(o)}catch(c){}window[s]=function(e){try{r.__onSuccess(e)}catch(c){}},this.callbackString=s,this._url=t+(-1===t.indexOf("?")?"?":"&")+this._prop.callbackname+"="+s,"onreadystatechange"in o?o.onreadystatechange=function(){"loaded"===o.readyState&&(window[s]?u.__onError():u._teardown(),o.onreadystatechange=null)}:(o.onload=function(){o.onload=null,o.onerror=null},o.onerror=function(){u.__onError(),o.onload=null,o.onerror=null}),this.sEl=o}},e.prototype.send=function(e){var t=this,n=this._url;e&&(0!==e.indexOf("?")&&0!==e.indexOf("&")||(e=e.substr(1)),n+="&"+e),"timeout"in this&&this.timeout>0&&(this._timer=window.setTimeout(function(){t.__loading&&t.__onTimeout()},this.timeout)),this.sEl.src=n,this.__loading=!0},e.prototype._teardown=function(){this.__loading=!1,delete this.response;var e=this.sEl,t=this.callbackString;window.setTimeout(function(){try{e.parentNode.removeChild(e)}catch(n){}window[t]=null},10)},e.prototype.__onSuccess=function(e){var t=this.sEl;t.onreadystatechange&&(t.onreadystatechange=null),this.onload&&(this.response=e,this.onload()),this._prop.callback&&this._prop.callback(e),this._teardown()},e.prototype.__onTimeout=function(){this.ontimeout&&this.ontimeout(),this._teardown()},e.prototype.__onError=function(){this.onerror&&this.onerror(),this._prop.error&&this._prop.error(),this._teardown()},e}();t["default"]=s},function(e,t,n){"use strict";function r(e){return navigator.userAgent.match(e)}function o(){return!!r(/MSIE 8/i)}function i(){return!!r(/MSIE 9/i)}function a(){return o()||i()}function s(){var e=r(/Android ([\d|.]+)/);return e&&e[1]<"4.4.4"}t.__esModule=!0,t.match=r,t.isIE8=o,t.isIE9=i,t.isIE8or9=a,t.isAndroidLT444=s}])});
//lcs nclicks
!function(e){var n=function(e,t,o,r,c,i,a){var l,d,u,f=e,s=e;if("nodeType"in e&&e.nodeType>=1)f=window.event||e;else if(e){var m=e.srcElement||e.currentTarget||e.target;m&&(s=n.findLink(m))}return i||(i=""),u=n.gcp(s,f),d=n.gl(t,o,r,u,"",0,n.st,i,a),l=n.l(s,d),n.sd(l),!0},t=e.ccsrv||"cc.naver.com",o=e.nsc||"decide.me";function r(e,t,o,r,c,i){var a,l,d,u=e,f=e;if("nodeType"in e&&e.nodeType>=1)u=window.event||e;else if(e){var s=e.srcElement||e.currentTarget||e.target;s&&(f=n.findLink(s))}return c||(c=""),d=n.gcp(f,u),l=n.gl(t,o,r,d,"",0,n.st,c,i),a=n.l(f,l),n.sd(a),!0}n.vs="0.4.2",n.md="cc",n.pt="https:"==window.location.protocol?"https:":"http:",n.ct=0,n.ec=encodeURIComponent,n.st=1,n.findLink=function(e){for(var n=e;n&&"BODY"!==n.tagName&&"HTML"!==n.tagName&&"A"!==n.tagName;)n=n.parentNode;return"A"!==n.tagName&&(n=e),n},n.l=function(e,o){var r,c,i;return e&&e.href?(c=e.tagName.toLowerCase(),(i=e.href.toLowerCase())&&0==i.indexOf(n.pt+"//"+t)?r=e.href:i&&0!=i.indexOf(n.pt+"//"+t)&&c&&"img"!=c&&(r=o+"&u="+n.ec(e.href)),r):o+"&u=about%3Ablank"},n.sd=function(e,t){var o,r=0;n.ct>0&&(e+="&nt="+(new Date).getTime());"function"==typeof t&&(r=1);var c=new Image;c.src=e,c.onload=function(){o&&clearTimeout(o),r&&t(),c.onload=null},c.onerror=function(){o&&clearTimeout(o),r&&t(),c.onerror=null},r&&(o=setTimeout(function(){t()},5e3)),n.ct++},n.gl=function(r,c,i,a,l,d,u,f,s){var m=e.g_ssc||"",p=e.g_query||"",v=e.lcs_get_lpid||null,h=e.g_pid||"",g=e.g_sid||"";null==d&&(d=1),null==u&&(u=1);var w=n.pt+"//"+t+"/"+n.md+"?a="+r+"&r="+i+"&i="+c+"&m="+d;return 1==u?(m&&(w+="&ssc="+m),p&&(w+="&q="+n.ec(p)),g&&(w+="&s="+g),s?w+="&p="+s:h?w+="&p="+h:v?w+="&p="+v():console.warn("'g_pid / lcs_get_lpid' is not exist.")):(w+="&nsc="+o,console.warn("[DEPRECATED] NSC mode")),f&&(w+="&g="+f),l&&(w+="&u="+n.ec(l)),a&&(w+=a),w},n.al=function(e,n){var t=window;t.addEventListener?t.addEventListener(e,n,!1):t.attachEvent&&t.attachEvent("on"+e,n)},n.oo="",n.of="","onpageshow"in window&&n.al("pageshow",function(){n.oo.onclick=n.of}),n.gsbw=function(){var e=document.createElement("p");e.style.width="200px",e.style.height="200px";var n=document.createElement("div");n.style.position="absolute",n.style.top="0px",n.style.left="0px",n.style.visibility="hidden",n.style.width="200px",n.style.height="150px",n.style.overflow="hidden",n.appendChild(e),document.body.appendChild(n);var t=e.offsetWidth;n.style.overflow="scroll";var o=e.offsetWidth;return t==o&&(o=n.clientWidth),document.body.removeChild(n),t-o},n.fp=function(e){var n=curtop=0;try{if(e.offsetParent)do{n+=e.offsetLeft,curtop+=e.offsetTop}while(e=e.offsetParent);else(e.x||e.y)&&(e.x&&(n+=e.x),e.y&&(curtop+=e.y))}catch(e){}return[n,curtop]},n.ws=function(e){e||(e=window);var t=0;if(e.innerWidth){if(t=e.innerWidth,"number"==typeof e.innerWidth){var o=n.gsbw();t=e.innerWidth-o}}else document.documentElement&&document.documentElement.clientWidth?t=document.documentElement.clientWidth:document.body&&(document.body.clientWidth||document.body.clientHeight)&&(t=document.body.clientWidth);return t},n.ci=function(e){document.URL;var n,t=e.parentNode;if(null==t||null==t)return!1;for(;;)if("#document"==t.nodeName.toLowerCase()){n=t.parentWindow?t.parentWindow:t.defaultView;try{return null!=n.frameElement&&null!=n.frameElement&&"iframe"==n.frameElement.nodeName.toLowerCase()&&n.frameElement.id||!1}catch(e){return!1}}else if(null==(t=t.parentNode)||null==t)return!1},n.gcp=function(e,t){var o,r,c,i=-1,a=-1,l=-1,d=-1,u="",f=window.event?window.event:e;t&&(f=t||window.event);try{if(bw=n.ws(window),c=n.ci(e)){var s=n.fp(document.getElementById(c));f.clientX&&null!=f.clientX&&((o=document.body).clientLeft&&o.clientTop?(ifrSx=f.clientX-o.clientLeft,ifrSy=f.clientY-o.clientTop):(ifrSx=f.clientX,ifrSy=f.clientY)),l=s[0]+ifrSx,d=s[1]+ifrSy,document.body&&(document.body.scrollTop||document.body.scrollLeft)?(i=l-(o=document.body).scrollLeft,a=d-o.scrollTop):document.documentElement&&(document.documentElement.scrollTop||document.documentElement.scrollLeft)?(i=l-(r=document.documentElement).scrollLeft,a=d-r.scrollTop):(i=l,a=d)}else f.clientX&&null!=f.clientX&&((o=document.body).clientLeft&&o.clientTop?(i=f.clientX-o.clientLeft,a=f.clientY-o.clientTop):(i=f.clientX,a=f.clientY)),document.body&&(document.body.scrollTop||document.body.scrollLeft)?(l=document.body.scrollLeft+(i<0?0:i),d=document.body.scrollTop+(a<0?0:a)):document.documentElement&&(document.documentElement.scrollTop||document.documentElement.scrollLeft)?(null!=(r=document.documentElement).scrollLeft&&(l=r.scrollLeft+(i<0?0:i)),null!=r.scrollTop&&(d=r.scrollTop+(a<0?0:a))):(l=i<0?0:i,d=a<0?0:a),f.pageX&&(l=f.pageX),f.pageY&&(d=f.pageY)}catch(t){}return-1!=l&&-1!=d&&(u+="&px="+l+"&py="+d),-1!=i&&-1!=a&&(u+="&sx="+i+"&sy="+a),u},e.nclk_proxy=function(t,o,r,c,i,a){var l=e.g_nclk_proxy||"";return l&&t.href&&(t.href=l+n.ec(t.href)),n(t,o,r,c,i,a)},e.nclk=n,e.nclk_v2=r,e.nclks_select=function(e,n,t,o,c){try{r(c,(t||{})[e]||n,"","","")}catch(e){}},e.nclks_clsnm=function(e,n,t,o,c,i){try{tmpObj=document.getElementById(e),tmpObj.className==n?r(i,t,"","",""):r(i,o,"","","")}catch(e){}},e.nclks_chk=function(e,n,t,o,c){try{tmpObj=document.getElementById(e),tmpObj.checked?r(c,n,"","",""):r(c,t,"","","")}catch(e){}},e.nclks=function(e,n,t){r(t,e,"","","")}}(window),function(e){var n={nnb:!0},t={},o={},r={},c=0,i=!1;function a(e){if(!i){if("complete"!==document.readyState){var l="onpageshow"in window?"pageshow":"load",d=(f=e,function(){window.setTimeout(function(){i=!1,a(f)},10)});return document.addEventListener?window.addEventListener(l,d,!1):window.attachEvent("on"+l,d),void(i=!0)}var f;window.lcs_SerName||(window.lcs_SerName="lcs.naver.com");var s,m,p,v,h="",g=document,w=window.location;try{p=(w.protocol?w.protocol:"http:")+"//"+window.lcs_SerName+"/m?"}catch(e){return}try{h=p+"u="+encodeURIComponent(w.href)+"&e="+(g.referrer?encodeURIComponent(g.referrer):"")}catch(e){}try{for(s in void 0===t.i&&(t.i=""),c<1&&(!function(){o.os=function(){var e="";try{navigator.platform&&(e=navigator.platform)}catch(e){}return e}(),o.ln=function(){var e="";try{navigator.userLanguage?e=navigator.userLanguage:navigator.language&&(e=navigator.language)}catch(e){}return e}(),o.sr=function(){var e="";try{if(window.screen&&screen.width&&screen.height)e=screen.width+"x"+screen.height;else if(window.java||self.java){var n=java.awt.Toolkit.getDefaultToolkit().getScreenSize();e=n.width+"x"+n.height}}catch(n){e=""}return e}(),o.pr=window.devicePixelRatio||1;var e=function(){var e=document,n={bw:"",bh:""};try{n.bw=e.documentElement.clientWidth?e.documentElement.clientWidth:e.body.clientWidth,n.bh=e.documentElement.clientHeight?e.documentElement.clientHeight:e.body.clientHeight}catch(e){}return n}();o.bw=e.bw,o.bh=e.bh,o.c=function(){var e="";try{if(window.screen)e=screen.colorDepth?screen.colorDepth:screen.pixelDepth;else if(window.java||self.java){var n=java.awt.Toolkit.getDefaultToolkit().getColorModel().getPixelSize();e=n}}catch(n){e=""}return e}(),o.j=function(){var e="";try{e=navigator.javaEnabled()?"Y":"N"}catch(e){}return e}(),o.k=function(){var e="";try{e=navigator.cookieEnabled?"Y":"N"}catch(e){}return e}()}(),n.nnb&&function(){try{var e=window.localStorage;if(e){if(e.ls){var n=e.ls;if(13==n.length)return void(t.ls=n)}var o=function(){try{var e,n,t,o=document.cookie,r=o.split(";");for(t=0;t<r.length;t++)if(e=r[t].substr(0,r[t].indexOf("=")),n=r[t].substr(r[t].indexOf("=")+1),"NNB"==(e=e.replace(/^\s+|\s+$/g,"")))return unescape(n)}catch(e){}}();null!=o&&""!=o&&(e.ls=o,t.ls=o)}}catch(e){}}(),t.ct=function(){var e="";try{var n=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(n&&void 0!==n.type)switch(n.type){case n.CELL_2G:e="2g";break;case n.CELL_3G:e="3g";break;case n.CELL_4G:e="4g";break;case n.WIFI:e="wifi";break;case n.ETHERNET:e="eth";break;case n.UNKNOWN:e="unknown";break;case n.NONE:e="none";break;default:e=""}else if("undefined"!=typeof blackberry&&void 0!==blackberry.network){var t=blackberry.network;e="Wi-Fi"==t?"wifi":"3G"==t?"3g":t}else{var o="Microsoft Internet Explorer"==navigator.appName,r=navigator.userAgent.indexOf("MAC")>=0;if(o&&!r&&c&&c.addBehavior){var c=document.body,i=c.addBehavior("#default#clientCaps");e=c.connectionType,c.removeBehavior(i)}}}catch(e){console.warn(e)}return e}(),function(){var e=window.performance||{};if(e.timing){var n=e.timing;for(var t in n){var o=n[t];"number"==typeof o&&(r[t]=o)}}}(),function(){var e=window.performance||{};try{if(e.getEntriesByType){var n=e.getEntriesByType("paint");n.forEach(function(e,n,t){var o=e.name;switch(o){case"first-paint":case"first-contentful-paint":r[o]=e.startTime}})}}catch(e){console.warn(e)}}(),void 0!==(v=function(){var e=window.performance||{};if(e.navigation)return e.navigation.type;return}())&&(r.ngt=v)),o)"function"!=typeof o[s]&&(h+="&"+s+"="+encodeURIComponent(o[s]));for(s in t)void 0!==(m=t[s])&&"function"!=typeof m&&(h+="&"+s+"="+encodeURIComponent(m));if(c<1)for(s in r)(m=r[s])&&(h+="&"+s+"="+encodeURIComponent(m));for(s in e)(s.length>=3&&"function"!=typeof e[s]||"qy"===s)&&(h+="&"+s+"="+encodeURIComponent(e[s]));var y;if(!1==!!e||!1==!!e.pid)y=window.g_pid?g_pid:u(),h+="&pid="+encodeURIComponent(y);h+="&ts="+(new Date).getTime(),h+="&EOU";var b=document.createElement("img");b.src=h,b.onload=function(){b.onload=null},c++}catch(e){return}}}var l=null;function d(){var e,n=window.localStorage?window.localStorage.ls:null;n?e=n:e=navigator.userAgent+Math.random();var t,o=window.performance||{},r=location.href;return t=o.now?o.now():(new Date).getTime(),l=f.md5(e+r+t)}function u(){return null===l&&(l=d()),l}var f={};!function(e){function n(e,n){var t=(65535&e)+(65535&n);return(e>>16)+(n>>16)+(t>>16)<<16|65535&t}function t(e,t,o,r,c,i){return n((a=n(n(t,e),n(r,i)))<<(l=c)|a>>>32-l,o);var a,l}function o(e,n,o,r,c,i,a){return t(n&o|~n&r,e,n,c,i,a)}function r(e,n,o,r,c,i,a){return t(n&r|o&~r,e,n,c,i,a)}function c(e,n,o,r,c,i,a){return t(n^o^r,e,n,c,i,a)}function i(e,n,o,r,c,i,a){return t(o^(n|~r),e,n,c,i,a)}function a(e,t){var a,l,d,u,f;e[t>>5]|=128<<t%32,e[14+(t+64>>>9<<4)]=t;var s=1732584193,m=-271733879,p=-1732584194,v=271733878;for(a=0;a<e.length;a+=16)l=s,d=m,u=p,f=v,s=o(s,m,p,v,e[a],7,-680876936),v=o(v,s,m,p,e[a+1],12,-389564586),p=o(p,v,s,m,e[a+2],17,606105819),m=o(m,p,v,s,e[a+3],22,-1044525330),s=o(s,m,p,v,e[a+4],7,-176418897),v=o(v,s,m,p,e[a+5],12,1200080426),p=o(p,v,s,m,e[a+6],17,-1473231341),m=o(m,p,v,s,e[a+7],22,-45705983),s=o(s,m,p,v,e[a+8],7,1770035416),v=o(v,s,m,p,e[a+9],12,-1958414417),p=o(p,v,s,m,e[a+10],17,-42063),m=o(m,p,v,s,e[a+11],22,-1990404162),s=o(s,m,p,v,e[a+12],7,1804603682),v=o(v,s,m,p,e[a+13],12,-40341101),p=o(p,v,s,m,e[a+14],17,-1502002290),s=r(s,m=o(m,p,v,s,e[a+15],22,1236535329),p,v,e[a+1],5,-165796510),v=r(v,s,m,p,e[a+6],9,-1069501632),p=r(p,v,s,m,e[a+11],14,643717713),m=r(m,p,v,s,e[a],20,-373897302),s=r(s,m,p,v,e[a+5],5,-701558691),v=r(v,s,m,p,e[a+10],9,38016083),p=r(p,v,s,m,e[a+15],14,-660478335),m=r(m,p,v,s,e[a+4],20,-405537848),s=r(s,m,p,v,e[a+9],5,568446438),v=r(v,s,m,p,e[a+14],9,-1019803690),p=r(p,v,s,m,e[a+3],14,-187363961),m=r(m,p,v,s,e[a+8],20,1163531501),s=r(s,m,p,v,e[a+13],5,-1444681467),v=r(v,s,m,p,e[a+2],9,-51403784),p=r(p,v,s,m,e[a+7],14,1735328473),s=c(s,m=r(m,p,v,s,e[a+12],20,-1926607734),p,v,e[a+5],4,-378558),v=c(v,s,m,p,e[a+8],11,-2022574463),p=c(p,v,s,m,e[a+11],16,1839030562),m=c(m,p,v,s,e[a+14],23,-35309556),s=c(s,m,p,v,e[a+1],4,-1530992060),v=c(v,s,m,p,e[a+4],11,1272893353),p=c(p,v,s,m,e[a+7],16,-155497632),m=c(m,p,v,s,e[a+10],23,-1094730640),s=c(s,m,p,v,e[a+13],4,681279174),v=c(v,s,m,p,e[a],11,-358537222),p=c(p,v,s,m,e[a+3],16,-722521979),m=c(m,p,v,s,e[a+6],23,76029189),s=c(s,m,p,v,e[a+9],4,-640364487),v=c(v,s,m,p,e[a+12],11,-421815835),p=c(p,v,s,m,e[a+15],16,530742520),s=i(s,m=c(m,p,v,s,e[a+2],23,-995338651),p,v,e[a],6,-198630844),v=i(v,s,m,p,e[a+7],10,1126891415),p=i(p,v,s,m,e[a+14],15,-1416354905),m=i(m,p,v,s,e[a+5],21,-57434055),s=i(s,m,p,v,e[a+12],6,1700485571),v=i(v,s,m,p,e[a+3],10,-1894986606),p=i(p,v,s,m,e[a+10],15,-1051523),m=i(m,p,v,s,e[a+1],21,-2054922799),s=i(s,m,p,v,e[a+8],6,1873313359),v=i(v,s,m,p,e[a+15],10,-30611744),p=i(p,v,s,m,e[a+6],15,-1560198380),m=i(m,p,v,s,e[a+13],21,1309151649),s=i(s,m,p,v,e[a+4],6,-145523070),v=i(v,s,m,p,e[a+11],10,-1120210379),p=i(p,v,s,m,e[a+2],15,718787259),m=i(m,p,v,s,e[a+9],21,-343485551),s=n(s,l),m=n(m,d),p=n(p,u),v=n(v,f);return[s,m,p,v]}function l(e){var n,t="",o=32*e.length;for(n=0;n<o;n+=8)t+=String.fromCharCode(e[n>>5]>>>n%32&255);return t}function d(e){var n,t=[];for(t[(e.length>>2)-1]=void 0,n=0;n<t.length;n+=1)t[n]=0;var o=8*e.length;for(n=0;n<o;n+=8)t[n>>5]|=(255&e.charCodeAt(n/8))<<n%32;return t}function u(e){var n,t,o="";for(t=0;t<e.length;t+=1)n=e.charCodeAt(t),o+="0123456789abcdef".charAt(n>>>4&15)+"0123456789abcdef".charAt(15&n);return o}function s(e){return unescape(encodeURIComponent(e))}function m(e){return function(e){return l(a(d(e),8*e.length))}(s(e))}function p(e,n){return function(e,n){var t,o,r=d(e),c=[],i=[];for(c[15]=i[15]=void 0,r.length>16&&(r=a(r,8*e.length)),t=0;t<16;t+=1)c[t]=909522486^r[t],i[t]=1549556828^r[t];return o=a(c.concat(d(n)),512+8*n.length),l(a(i.concat(o),640))}(s(e),s(n))}f.md5=function(e,n,t){return n?t?p(n,e):u(p(n,e)):t?m(e):u(m(e))}}(),e.lcs_do=a,e.lcs_do_gdid=function(e,n){try{e&&(t.i=e,n?a(n):a())}catch(e){}},e.lcs_get_lpid=u,e.lcs_update_lpid=function(){return l=d()},e.lcs_version="v0.7.1"}(window);
//rsa
function BigInteger(t,r,i){null!=t&&("number"==typeof t?this.fromNumber(t,r,i):null==r&&"string"!=typeof t?this.fromString(t,256):this.fromString(t,r))}function nbi(){return new BigInteger(null)}function am1(t,r,i,n,o,e){for(;--e>=0;){var s=r*this[t++]+i[n]+o;o=Math.floor(s/67108864),i[n++]=67108863&s}return o}function am2(t,r,i,n,o,e){for(var s=32767&r,h=r>>15;--e>=0;){var p=32767&this[t],a=this[t++]>>15,g=h*p+a*s;o=((p=s*p+((32767&g)<<15)+i[n]+(1073741823&o))>>>30)+(g>>>15)+h*a+(o>>>30),i[n++]=1073741823&p}return o}function am3(t,r,i,n,o,e){for(var s=16383&r,h=r>>14;--e>=0;){var p=16383&this[t],a=this[t++]>>14,g=h*p+a*s;o=((p=s*p+((16383&g)<<14)+i[n]+o)>>28)+(g>>14)+h*a,i[n++]=268435455&p}return o}function int2char(t){return BI_RM.charAt(t)}function intAt(t,r){var i=BI_RC[t.charCodeAt(r)];return null==i?-1:i}function bnpCopyTo(t){for(var r=this.t-1;r>=0;--r)t[r]=this[r];t.t=this.t,t.s=this.s}function bnpFromInt(t){this.t=1,this.s=t<0?-1:0,t>0?this[0]=t:t<-1?this[0]=t+DV:this.t=0}function nbv(t){var r=nbi();return r.fromInt(t),r}function bnpFromString(t,r){var i;if(16==r)i=4;else if(8==r)i=3;else if(256==r)i=8;else if(2==r)i=1;else if(32==r)i=5;else{if(4!=r)return void this.fromRadix(t,r);i=2}this.t=0,this.s=0;for(var n=t.length,o=!1,e=0;--n>=0;){var s=8==i?255&t[n]:intAt(t,n);s<0?"-"==t.charAt(n)&&(o=!0):(o=!1,0==e?this[this.t++]=s:e+i>this.DB?(this[this.t-1]|=(s&(1<<this.DB-e)-1)<<e,this[this.t++]=s>>this.DB-e):this[this.t-1]|=s<<e,(e+=i)>=this.DB&&(e-=this.DB))}8==i&&0!=(128&t[0])&&(this.s=-1,e>0&&(this[this.t-1]|=(1<<this.DB-e)-1<<e)),this.clamp(),o&&BigInteger.ZERO.subTo(this,this)}function bnpClamp(){for(var t=this.s&this.DM;this.t>0&&this[this.t-1]==t;)--this.t}function bnToString(t){if(this.s<0)return"-"+this.negate().toString(t);var r;if(16==t)r=4;else if(8==t)r=3;else if(2==t)r=1;else if(32==t)r=5;else{if(4!=t)return this.toRadix(t);r=2}var i,n=(1<<r)-1,o=!1,e="",s=this.t,h=this.DB-s*this.DB%r;if(s-- >0)for(h<this.DB&&(i=this[s]>>h)>0&&(o=!0,e=int2char(i));s>=0;)h<r?(i=(this[s]&(1<<h)-1)<<r-h,i|=this[--s]>>(h+=this.DB-r)):(i=this[s]>>(h-=r)&n,h<=0&&(h+=this.DB,--s)),i>0&&(o=!0),o&&(e+=int2char(i));return o?e:"0"}function bnNegate(){var t=nbi();return BigInteger.ZERO.subTo(this,t),t}function bnAbs(){return this.s<0?this.negate():this}function bnCompareTo(t){var r=this.s-t.s;if(0!=r)return r;var i=this.t;if(0!=(r=i-t.t))return r;for(;--i>=0;)if(0!=(r=this[i]-t[i]))return r;return 0}function nbits(t){var r,i=1;return 0!=(r=t>>>16)&&(t=r,i+=16),0!=(r=t>>8)&&(t=r,i+=8),0!=(r=t>>4)&&(t=r,i+=4),0!=(r=t>>2)&&(t=r,i+=2),0!=(r=t>>1)&&(t=r,i+=1),i}function bnBitLength(){return this.t<=0?0:this.DB*(this.t-1)+nbits(this[this.t-1]^this.s&this.DM)}function bnpDLShiftTo(t,r){var i;for(i=this.t-1;i>=0;--i)r[i+t]=this[i];for(i=t-1;i>=0;--i)r[i]=0;r.t=this.t+t,r.s=this.s}function bnpDRShiftTo(t,r){for(var i=t;i<this.t;++i)r[i-t]=this[i];r.t=Math.max(this.t-t,0),r.s=this.s}function bnpLShiftTo(t,r){var i,n=t%this.DB,o=this.DB-n,e=(1<<o)-1,s=Math.floor(t/this.DB),h=this.s<<n&this.DM;for(i=this.t-1;i>=0;--i)r[i+s+1]=this[i]>>o|h,h=(this[i]&e)<<n;for(i=s-1;i>=0;--i)r[i]=0;r[s]=h,r.t=this.t+s+1,r.s=this.s,r.clamp()}function bnpRShiftTo(t,r){r.s=this.s;var i=Math.floor(t/this.DB);if(i>=this.t)r.t=0;else{var n=t%this.DB,o=this.DB-n,e=(1<<n)-1;r[0]=this[i]>>n;for(var s=i+1;s<this.t;++s)r[s-i-1]|=(this[s]&e)<<o,r[s-i]=this[s]>>n;n>0&&(r[this.t-i-1]|=(this.s&e)<<o),r.t=this.t-i,r.clamp()}}function bnpSubTo(t,r){for(var i=0,n=0,o=Math.min(t.t,this.t);i<o;)n+=this[i]-t[i],r[i++]=n&this.DM,n>>=this.DB;if(t.t<this.t){for(n-=t.s;i<this.t;)n+=this[i],r[i++]=n&this.DM,n>>=this.DB;n+=this.s}else{for(n+=this.s;i<t.t;)n-=t[i],r[i++]=n&this.DM,n>>=this.DB;n-=t.s}r.s=n<0?-1:0,n<-1?r[i++]=this.DV+n:n>0&&(r[i++]=n),r.t=i,r.clamp()}function bnpMultiplyTo(t,r){var i=this.abs(),n=t.abs(),o=i.t;for(r.t=o+n.t;--o>=0;)r[o]=0;for(o=0;o<n.t;++o)r[o+i.t]=i.am(0,n[o],r,o,0,i.t);r.s=0,r.clamp(),this.s!=t.s&&BigInteger.ZERO.subTo(r,r)}function bnpSquareTo(t){for(var r=this.abs(),i=t.t=2*r.t;--i>=0;)t[i]=0;for(i=0;i<r.t-1;++i){var n=r.am(i,r[i],t,2*i,0,1);(t[i+r.t]+=r.am(i+1,2*r[i],t,2*i+1,n,r.t-i-1))>=r.DV&&(t[i+r.t]-=r.DV,t[i+r.t+1]=1)}t.t>0&&(t[t.t-1]+=r.am(i,r[i],t,2*i,0,1)),t.s=0,t.clamp()}function bnpDivRemTo(t,r,i){var n=t.abs();if(!(n.t<=0)){var o=this.abs();if(o.t<n.t)return null!=r&&r.fromInt(0),void(null!=i&&this.copyTo(i));null==i&&(i=nbi());var e=nbi(),s=this.s,h=t.s,p=this.DB-nbits(n[n.t-1]);p>0?(n.lShiftTo(p,e),o.lShiftTo(p,i)):(n.copyTo(e),o.copyTo(i));var a=e.t,g=e[a-1];if(0!=g){var u=g*(1<<this.F1)+(a>1?e[a-2]>>this.F2:0),f=this.FV/u,c=(1<<this.F1)/u,l=1<<this.F2,v=i.t,b=v-a,m=null==r?nbi():r;for(e.dlShiftTo(b,m),i.compareTo(m)>=0&&(i[i.t++]=1,i.subTo(m,i)),BigInteger.ONE.dlShiftTo(a,m),m.subTo(e,e);e.t<a;)e[e.t++]=0;for(;--b>=0;){var y=i[--v]==g?this.DM:Math.floor(i[v]*f+(i[v-1]+l)*c);if((i[v]+=e.am(0,y,i,b,0,a))<y)for(e.dlShiftTo(b,m),i.subTo(m,i);i[v]<--y;)i.subTo(m,i)}null!=r&&(i.drShiftTo(a,r),s!=h&&BigInteger.ZERO.subTo(r,r)),i.t=a,i.clamp(),p>0&&i.rShiftTo(p,i),s<0&&BigInteger.ZERO.subTo(i,i)}}}function bnMod(t){var r=nbi();return this.abs().divRemTo(t,null,r),this.s<0&&r.compareTo(BigInteger.ZERO)>0&&t.subTo(r,r),r}function Classic(t){this.m=t}function cConvert(t){return t.s<0||t.compareTo(this.m)>=0?t.mod(this.m):t}function cRevert(t){return t}function cReduce(t){t.divRemTo(this.m,null,t)}function cMulTo(t,r,i){t.multiplyTo(r,i),this.reduce(i)}function cSqrTo(t,r){t.squareTo(r),this.reduce(r)}function bnpInvDigit(){if(this.t<1)return 0;var t=this[0];if(0==(1&t))return 0;var r=3&t;return(r=(r=(r=(r=r*(2-(15&t)*r)&15)*(2-(255&t)*r)&255)*(2-((65535&t)*r&65535))&65535)*(2-t*r%this.DV)%this.DV)>0?this.DV-r:-r}function Montgomery(t){this.m=t,this.mp=t.invDigit(),this.mpl=32767&this.mp,this.mph=this.mp>>15,this.um=(1<<t.DB-15)-1,this.mt2=2*t.t}function montConvert(t){var r=nbi();return t.abs().dlShiftTo(this.m.t,r),r.divRemTo(this.m,null,r),t.s<0&&r.compareTo(BigInteger.ZERO)>0&&this.m.subTo(r,r),r}function montRevert(t){var r=nbi();return t.copyTo(r),this.reduce(r),r}function montReduce(t){for(;t.t<=this.mt2;)t[t.t++]=0;for(var r=0;r<this.m.t;++r){var i=32767&t[r],n=i*this.mpl+((i*this.mph+(t[r]>>15)*this.mpl&this.um)<<15)&t.DM;for(t[i=r+this.m.t]+=this.m.am(0,n,t,r,0,this.m.t);t[i]>=t.DV;)t[i]-=t.DV,t[++i]++}t.clamp(),t.drShiftTo(this.m.t,t),t.compareTo(this.m)>=0&&t.subTo(this.m,t)}function montSqrTo(t,r){t.squareTo(r),this.reduce(r)}function montMulTo(t,r,i){t.multiplyTo(r,i),this.reduce(i)}function bnpIsEven(){return 0==(this.t>0?1&this[0]:this.s)}function bnpExp(t,r){if(t>4294967295||t<1)return BigInteger.ONE;var i=nbi(),n=nbi(),o=r.convert(this),e=nbits(t)-1;for(o.copyTo(i);--e>=0;)if(r.sqrTo(i,n),(t&1<<e)>0)r.mulTo(n,o,i);else{var s=i;i=n,n=s}return r.revert(i)}function bnModPowInt(t,r){var i;return i=t<256||r.isEven()?new Classic(r):new Montgomery(r),this.exp(t,i)}function Arcfour(){this.i=0,this.j=0,this.S=new Array}function ARC4init(t){var r,i,n;for(r=0;r<256;++r)this.S[r]=r;for(i=0,r=0;r<256;++r)i=i+this.S[r]+t[r%t.length]&255,n=this.S[r],this.S[r]=this.S[i],this.S[i]=n;this.i=0,this.j=0}function ARC4next(){var t;return this.i=this.i+1&255,this.j=this.j+this.S[this.i]&255,t=this.S[this.i],this.S[this.i]=this.S[this.j],this.S[this.j]=t,this.S[t+this.S[this.i]&255]}function prng_newstate(){return new Arcfour}function rng_seed_int(t){rng_pool[rng_pptr++]^=255&t,rng_pool[rng_pptr++]^=t>>8&255,rng_pool[rng_pptr++]^=t>>16&255,rng_pool[rng_pptr++]^=t>>24&255,rng_pptr>=rng_psize&&(rng_pptr-=rng_psize)}function rng_seed_time(){rng_seed_int((new Date).getTime())}function rng_get_byte(){if(null==rng_state){for(rng_seed_time(),(rng_state=prng_newstate()).init(rng_pool),rng_pptr=0;rng_pptr<rng_pool.length;++rng_pptr)rng_pool[rng_pptr]=0;rng_pptr=0}return rng_state.next()}function rng_get_bytes(t){var r;for(r=0;r<t.length;++r)t[r]=rng_get_byte()}function SecureRandom(){}function parseBigInt(t,r){return new BigInteger(t,r)}function linebrk(t,r){for(var i="",n=0;n+r<t.length;)i+=t.substring(n,n+r)+"\n",n+=r;return i+t.substring(n,t.length)}function byte2Hex(t){return t<16?"0"+t.toString(16):t.toString(16)}function pkcs1pad2(t,r){if(r<t.length+11)return alert("Message too long for RSA"),null;for(var i=new Array,n=t.length-1;n>=0&&r>0;)i[--r]=t.charCodeAt(n--);i[--r]=0;for(var o=new SecureRandom,e=new Array;r>2;){for(e[0]=0;0==e[0];)o.nextBytes(e);i[--r]=e[0]}return i[--r]=2,i[--r]=0,new BigInteger(i)}function RSAKey(){this.n=null,this.e=0,this.d=null,this.p=null,this.q=null,this.dmp1=null,this.dmq1=null,this.coeff=null}function RSASetPublic(t,r){null!=t&&null!=r&&t.length>0&&r.length>0?(this.n=parseBigInt(t,16),this.e=parseInt(r,16)):alert("Invalid RSA public key")}function RSADoPublic(t){return t.modPowInt(this.e,this.n)}function RSAEncrypt(t){var r=pkcs1pad2(t,this.n.bitLength()+7>>3);if(null==r)return null;var i=this.doPublic(r);if(null==i)return null;for(var n=i.toString(16),o=(this.n.bitLength()+7>>3<<1)-n.length;o-- >0;)n="0"+n;return n}function hex2b64(t){var r,i,n="";for(r=0;r+3<=t.length;r+=3)i=parseInt(t.substring(r,r+3),16),n+=b64map.charAt(i>>6)+b64map.charAt(63&i);for(r+1==t.length?(i=parseInt(t.substring(r,r+1),16),n+=b64map.charAt(i<<2)):r+2==t.length&&(i=parseInt(t.substring(r,r+2),16),n+=b64map.charAt(i>>2)+b64map.charAt((3&i)<<4));(3&n.length)>0;)n+=b64pad;return n}function b64tohex(t){var r,i,n="",o=0;for(r=0;r<t.length&&t.charAt(r)!=b64pad;++r)v=b64map.indexOf(t.charAt(r)),v<0||(0==o?(n+=int2char(v>>2),i=3&v,o=1):1==o?(n+=int2char(i<<2|v>>4),i=15&v,o=2):2==o?(n+=int2char(i),n+=int2char(v>>2),i=3&v,o=3):(n+=int2char(i<<2|v>>4),n+=int2char(15&v),o=0));return 1==o&&(n+=int2char(i<<2)),n}function b64toBA(t){var r,i=b64tohex(t),n=new Array;for(r=0;2*r<i.length;++r)n[r]=parseInt(i.substring(2*r,2*r+2),16);return n}var dbits,isIE=-1!=navigator.appVersion.indexOf("MSIE"),isWin=-1!=navigator.appVersion.toLowerCase().indexOf("win"),isOpera=-1!=navigator.userAgent.indexOf("Opera"),canary=0xdeadbeefcafe,j_lm=15715070==(16777215&canary);j_lm&&"Microsoft Internet Explorer"==navigator.appName?(BigInteger.prototype.am=am2,dbits=30):j_lm&&"Netscape"!=navigator.appName?(BigInteger.prototype.am=am1,dbits=26):(BigInteger.prototype.am=am3,dbits=28),BigInteger.prototype.DB=dbits,BigInteger.prototype.DM=(1<<dbits)-1,BigInteger.prototype.DV=1<<dbits;var BI_FP=52;BigInteger.prototype.FV=Math.pow(2,BI_FP),BigInteger.prototype.F1=BI_FP-dbits,BigInteger.prototype.F2=2*dbits-BI_FP;var rr,vv,BI_RM="0123456789abcdefghijklmnopqrstuvwxyz",BI_RC=new Array;for(rr="0".charCodeAt(0),vv=0;vv<=9;++vv)BI_RC[rr++]=vv;for(rr="a".charCodeAt(0),vv=10;vv<36;++vv)BI_RC[rr++]=vv;for(rr="A".charCodeAt(0),vv=10;vv<36;++vv)BI_RC[rr++]=vv;Classic.prototype.convert=cConvert,Classic.prototype.revert=cRevert,Classic.prototype.reduce=cReduce,Classic.prototype.mulTo=cMulTo,Classic.prototype.sqrTo=cSqrTo,Montgomery.prototype.convert=montConvert,Montgomery.prototype.revert=montRevert,Montgomery.prototype.reduce=montReduce,Montgomery.prototype.mulTo=montMulTo,Montgomery.prototype.sqrTo=montSqrTo,BigInteger.prototype.copyTo=bnpCopyTo,BigInteger.prototype.fromInt=bnpFromInt,BigInteger.prototype.fromString=bnpFromString,BigInteger.prototype.clamp=bnpClamp,BigInteger.prototype.dlShiftTo=bnpDLShiftTo,BigInteger.prototype.drShiftTo=bnpDRShiftTo,BigInteger.prototype.lShiftTo=bnpLShiftTo,BigInteger.prototype.rShiftTo=bnpRShiftTo,BigInteger.prototype.subTo=bnpSubTo,BigInteger.prototype.multiplyTo=bnpMultiplyTo,BigInteger.prototype.squareTo=bnpSquareTo,BigInteger.prototype.divRemTo=bnpDivRemTo,BigInteger.prototype.invDigit=bnpInvDigit,BigInteger.prototype.isEven=bnpIsEven,BigInteger.prototype.exp=bnpExp,BigInteger.prototype.toString=bnToString,BigInteger.prototype.negate=bnNegate,BigInteger.prototype.abs=bnAbs,BigInteger.prototype.compareTo=bnCompareTo,BigInteger.prototype.bitLength=bnBitLength,BigInteger.prototype.mod=bnMod,BigInteger.prototype.modPowInt=bnModPowInt,BigInteger.ZERO=nbv(0),BigInteger.ONE=nbv(1),Arcfour.prototype.init=ARC4init,Arcfour.prototype.next=ARC4next;var rng_state,rng_pool,rng_pptr,rng_psize=256;if(null==rng_pool){var t;if(rng_pool=new Array,rng_pptr=0,"Netscape"==navigator.appName&&navigator.appVersion<"5"&&window.crypto){var z=window.crypto.random(32);for(t=0;t<z.length;++t)rng_pool[rng_pptr++]=255&z.charCodeAt(t)}for(;rng_pptr<rng_psize;)t=Math.floor(65536*Math.random()),rng_pool[rng_pptr++]=t>>>8,rng_pool[rng_pptr++]=255&t;rng_pptr=0,rng_seed_time()}SecureRandom.prototype.nextBytes=rng_get_bytes,RSAKey.prototype.doPublic=RSADoPublic,RSAKey.prototype.setPublic=RSASetPublic,RSAKey.prototype.encrypt=RSAEncrypt;
//private mode
/**
 * Lightweight script to detect whether the browser is running in Private mode.
 * @returns {Promise<boolean>}
 *
 * Live demo:
 * @see https://output.jsbin.com/tazuwif
 *
 * This snippet uses Promises. If you want to run it in old browsers, polyfill it:
 * @see https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.auto.min.js
 *
 * More Promise Polyfills:
 * @see https://ourcodeworld.com/articles/read/316/top-5-best-javascript-promises-polyfills
 */
!function(t,e){"object"==typeof exports&&"undefined"!=typeof module?module.exports=e():"function"==typeof define&&define.amd?define(e):t.ES6Promise=e()}(this,function(){"use strict";function t(t){var e=typeof t;return null!==t&&("object"===e||"function"===e)}function e(t){return"function"==typeof t}function n(t){W=t}function r(t){z=t}function o(){return function(){return process.nextTick(a)}}function i(){return"undefined"!=typeof U?function(){U(a)}:c()}function s(){var t=0,e=new H(a),n=document.createTextNode("");return e.observe(n,{characterData:!0}),function(){n.data=t=++t%2}}function u(){var t=new MessageChannel;return t.port1.onmessage=a,function(){return t.port2.postMessage(0)}}function c(){var t=setTimeout;return function(){return t(a,1)}}function a(){for(var t=0;t<N;t+=2){var e=Q[t],n=Q[t+1];e(n),Q[t]=void 0,Q[t+1]=void 0}N=0}function f(){try{var t=Function("return this")().require("vertx");return U=t.runOnLoop||t.runOnContext,i()}catch(e){return c()}}function l(t,e){var n=this,r=new this.constructor(p);void 0===r[V]&&x(r);var o=n._state;if(o){var i=arguments[o-1];z(function(){return T(o,r,i,n._result)})}else j(n,r,t,e);return r}function h(t){var e=this;if(t&&"object"==typeof t&&t.constructor===e)return t;var n=new e(p);return w(n,t),n}function p(){}function v(){return new TypeError("You cannot resolve a promise with itself")}function d(){return new TypeError("A promises callback cannot return that same promise.")}function _(t,e,n,r){try{t.call(e,n,r)}catch(o){return o}}function y(t,e,n){z(function(t){var r=!1,o=_(n,e,function(n){r||(r=!0,e!==n?w(t,n):A(t,n))},function(e){r||(r=!0,S(t,e))},"Settle: "+(t._label||" unknown promise"));!r&&o&&(r=!0,S(t,o))},t)}function m(t,e){e._state===Z?A(t,e._result):e._state===$?S(t,e._result):j(e,void 0,function(e){return w(t,e)},function(e){return S(t,e)})}function b(t,n,r){n.constructor===t.constructor&&r===l&&n.constructor.resolve===h?m(t,n):void 0===r?A(t,n):e(r)?y(t,n,r):A(t,n)}function w(e,n){if(e===n)S(e,v());else if(t(n)){var r=void 0;try{r=n.then}catch(o){return void S(e,o)}b(e,n,r)}else A(e,n)}function g(t){t._onerror&&t._onerror(t._result),E(t)}function A(t,e){t._state===X&&(t._result=e,t._state=Z,0!==t._subscribers.length&&z(E,t))}function S(t,e){t._state===X&&(t._state=$,t._result=e,z(g,t))}function j(t,e,n,r){var o=t._subscribers,i=o.length;t._onerror=null,o[i]=e,o[i+Z]=n,o[i+$]=r,0===i&&t._state&&z(E,t)}function E(t){var e=t._subscribers,n=t._state;if(0!==e.length){for(var r=void 0,o=void 0,i=t._result,s=0;s<e.length;s+=3)r=e[s],o=e[s+n],r?T(n,r,o,i):o(i);t._subscribers.length=0}}function T(t,n,r,o){var i=e(r),s=void 0,u=void 0,c=!0;if(i){try{s=r(o)}catch(a){c=!1,u=a}if(n===s)return void S(n,d())}else s=o;n._state!==X||(i&&c?w(n,s):c===!1?S(n,u):t===Z?A(n,s):t===$&&S(n,s))}function M(t,e){try{e(function(e){w(t,e)},function(e){S(t,e)})}catch(n){S(t,n)}}function P(){return tt++}function x(t){t[V]=tt++,t._state=void 0,t._result=void 0,t._subscribers=[]}function C(){return new Error("Array Methods must be provided an Array")}function O(t){return new et(this,t).promise}function k(t){var e=this;return new e(L(t)?function(n,r){for(var o=t.length,i=0;i<o;i++)e.resolve(t[i]).then(n,r)}:function(t,e){return e(new TypeError("You must pass an array to race."))})}function F(t){var e=this,n=new e(p);return S(n,t),n}function Y(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function q(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}function D(){var t=void 0;if("undefined"!=typeof global)t=global;else if("undefined"!=typeof self)t=self;else try{t=Function("return this")()}catch(e){throw new Error("polyfill failed because global object is unavailable in this environment")}var n=t.Promise;if(n){var r=null;try{r=Object.prototype.toString.call(n.resolve())}catch(e){}if("[object Promise]"===r&&!n.cast)return}t.Promise=nt}var K=void 0;K=Array.isArray?Array.isArray:function(t){return"[object Array]"===Object.prototype.toString.call(t)};var L=K,N=0,U=void 0,W=void 0,z=function(t,e){Q[N]=t,Q[N+1]=e,N+=2,2===N&&(W?W(a):R())},B="undefined"!=typeof window?window:void 0,G=B||{},H=G.MutationObserver||G.WebKitMutationObserver,I="undefined"==typeof self&&"undefined"!=typeof process&&"[object process]"==={}.toString.call(process),J="undefined"!=typeof Uint8ClampedArray&&"undefined"!=typeof importScripts&&"undefined"!=typeof MessageChannel,Q=new Array(1e3),R=void 0;R=I?o():H?s():J?u():void 0===B&&"function"==typeof require?f():c();var V=Math.random().toString(36).substring(2),X=void 0,Z=1,$=2,tt=0,et=function(){function t(t,e){this._instanceConstructor=t,this.promise=new t(p),this.promise[V]||x(this.promise),L(e)?(this.length=e.length,this._remaining=e.length,this._result=new Array(this.length),0===this.length?A(this.promise,this._result):(this.length=this.length||0,this._enumerate(e),0===this._remaining&&A(this.promise,this._result))):S(this.promise,C())}return t.prototype._enumerate=function(t){for(var e=0;this._state===X&&e<t.length;e++)this._eachEntry(t[e],e)},t.prototype._eachEntry=function(t,e){var n=this._instanceConstructor,r=n.resolve;if(r===h){var o=void 0,i=void 0,s=!1;try{o=t.then}catch(u){s=!0,i=u}if(o===l&&t._state!==X)this._settledAt(t._state,e,t._result);else if("function"!=typeof o)this._remaining--,this._result[e]=t;else if(n===nt){var c=new n(p);s?S(c,i):b(c,t,o),this._willSettleAt(c,e)}else this._willSettleAt(new n(function(e){return e(t)}),e)}else this._willSettleAt(r(t),e)},t.prototype._settledAt=function(t,e,n){var r=this.promise;r._state===X&&(this._remaining--,t===$?S(r,n):this._result[e]=n),0===this._remaining&&A(r,this._result)},t.prototype._willSettleAt=function(t,e){var n=this;j(t,void 0,function(t){return n._settledAt(Z,e,t)},function(t){return n._settledAt($,e,t)})},t}(),nt=function(){function t(e){this[V]=P(),this._result=this._state=void 0,this._subscribers=[],p!==e&&("function"!=typeof e&&Y(),this instanceof t?M(this,e):q())}return t.prototype["catch"]=function(t){return this.then(null,t)},t.prototype["finally"]=function(t){var n=this,r=n.constructor;return e(t)?n.then(function(e){return r.resolve(t()).then(function(){return e})},function(e){return r.resolve(t()).then(function(){throw e})}):n.then(t,t)},t}();return nt.prototype.then=l,nt.all=O,nt.race=k,nt.resolve=h,nt.reject=F,nt._setScheduler=n,nt._setAsap=r,nt._asap=z,nt.polyfill=D,nt.Promise=nt,nt.polyfill(),nt});
function isPrivateMode() {
    return new Promise(function detect(resolve) {
        var yes = function() { resolve(true); }; // is in private mode
        var not = function() { resolve(false); }; // not in private mode

        function detectChromeOpera() {
            // https://developers.google.com/web/updates/2017/08/estimating-available-storage-space
            var isChromeOpera = /(?=.*(opera|chrome)).*/i.test(navigator.userAgent) && navigator.storage && navigator.storage.estimate;
            if (isChromeOpera) {
                navigator.storage.estimate().then(function(data) {
                    return data.quota < 120000000 ? yes() : not();
                });
            }
            return !!isChromeOpera;
        }

        function detectFirefox() {
            var isMozillaFirefox = 'MozAppearance' in document.documentElement.style;
            if (isMozillaFirefox) {
                if (indexedDB == null) yes();
                else {
                    var db = indexedDB.open('inPrivate');
                    db.onsuccess = not;
                    db.onerror = yes;
                }
            }
            return isMozillaFirefox;
        }

        function detectSafari() {
            var isSafari = navigator.userAgent.match(/Version\/([0-9\._]+).*Safari/);
            if (isSafari) {
                var testLocalStorage = function() {
                    try {
                        if (localStorage.length) not();
                        else {
                            localStorage.setItem('inPrivate', '0');
                            localStorage.removeItem('inPrivate');
                            not();
                        }
                    } catch (_) {
                        // Safari only enables cookie in private mode
                        // if cookie is disabled, then all client side storage is disabled
                        // if all client side storage is disabled, then there is no point
                        // in using private mode
                        navigator.cookieEnabled ? yes() : not();
                    }
                    return true;
                };

                var version = parseInt(isSafari[1], 10);
                if (version < 11) return testLocalStorage();
                try {
                    window.openDatabase(null, null, null, null);
                    not();
                } catch (_) {
                    yes();
                }
            }
            return !!isSafari;
        }

        function detectEdgeIE10() {
            var isEdgeIE10 = !window.indexedDB && (window.PointerEvent || window.MSPointerEvent);
            if (isEdgeIE10) yes();
            return !!isEdgeIE10;
        }

        // when a browser is detected, it runs tests for that browser
        // and skips pointless testing for other browsers.
        if (detectChromeOpera()) return;
        if (detectFirefox()) return;
        if (detectSafari()) return;
        if (detectEdgeIE10()) return;

        // default navigation mode
        return not();
    });
}
function privateModeCheck() {
    isPrivateMode().then(function (isPrivate) {
        try {
            if (isPrivate && isObjExist('frmNIDLogin')){
                var tmpInput = document.createElement("input");
                tmpInput.type="hidden";
                tmpInput.name="privateMode";
                tmpInput.id="privateMode";
                tmpInput.value="true";
                $("frmNIDLogin").appendChild(tmpInput);
            }
        }catch(e){}
    });
}
//etc
var attr_array = ['action','method','href','placeholder','value','title','alt','disabled','checked','class'];

function $() {
    var a = [];
    for (var b = 0; b < arguments.length; b++) {
        if (typeof arguments[b] == "string") {
            a[a.length] = document.getElementById(arguments[b]);
        } else {
            a[a.length] = arguments[b];
        }
    }
    return a[1] ? a : a[0];
}
function getXmlHttp() {
    var xmlhttp;
    try {
        xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
        try {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        } catch (E) {
            xmlhttp = false;
        }
    }
    if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
        xmlhttp = new XMLHttpRequest();
    }
    return xmlhttp;
}
function dispSet(elementName,elementValue) {
    if (elementValue==true){
        document.getElementById(elementName).style.display="block";
    } else {
        document.getElementById(elementName).style.display="none";
    }
}
function nameDispSet(elementName, elementValue) {
    elementName = elementName.replace("_disp", "");
    dispSet(elementName,elementValue);
}
function insertHtml(elementName) {
    elementName = elementName.replace("_txt", "");
    if (argsFormat(elementName)=="") {
        dispSet(elementName,false);
    } else {
        if (document.getElementById(elementName)) {
            document.getElementById(elementName).innerHTML=argsFormat(elementName);
        }
    }
}
function changeElementAttribute(elementName, attributeName, attributeValue) {
    if (attributeName=="disabled") {
        if (attributeValue) {
            document.getElementById(elementName).disabled = attributeValue;
        }
    } else {
        document.getElementById(elementName).setAttribute(attributeName, attributeValue);
    }
}
function attributeSet(objName,objValue) {
    var i;
    var cnt=0;
    for (i = 0; i < attr_array.length; i++) {
        if (objName.indexOf(attr_array[i])!=-1) {
            changeElementAttribute(objName.replace("_"+attr_array[i], ""), attr_array[i].replace("_", ""), objValue);
            cnt++;
            return ;
        }
    }
    if (cnt==0) {
        alert(objName);
    }
}
if (!String.format) {
    String.format = function(format) {
        var args = Array.prototype.slice.call(arguments,1);
        return format.replace(/{(\d+)}/g, function(match, number){
            return typeof args[number] != 'undefined' ? args[number]: match;
        });
    };
}
function mapObj (initArray) {
    var elementMap;
    var isMapAvailable=false;
    if (typeof Map!='undefined') {
        isMapAvailable = true;
    }
    this.getMap=function(){
        return this.elementMap;
    }
    this.init=function(initVal){
        if (this.isMapAvailable) {
            this.elementMap = new Map();
        } else {
            this.elementMap = new Array();
        }
        for (var key in initVal) {
            this.set(initVal[key][0],initVal[key][1]);
        }
    }
    this.get=function(findVal){
        if (this.isMapAvailable) {
            return this.elementMap.get(findVal);
        } else {
            for(var prop in this.elementMap) {
                if (prop == findVal) {
                    return this.elementMap[prop];
                }
            }
            return "";
        }
    }
    this.set=function(keyStr,valStr){
        if (this.isMapAvailable) {
            this.elementMap.set(keyStr,valStr);
        } else {
            this.elementMap[keyStr] = valStr;
        }
    }
    this.init(initArray);
}
function doActionByKeyName(objName) {
    if (objName.indexOf('_disp')!=-1) {
        nameDispSet(objName,viewObjMap.get(objName));
    } else if (objName.indexOf('_txt')!=-1) {
        insertHtml(objName);
    } else if (objName.indexOf('_attr_')!=-1) {
        attributeSet(objName.replace("_attr", ""),viewObjMap.get(objName));
    }
}
function argsFormat(elementName) {
    var txtFormatStr = viewObjMap.get(elementName+"_txt");
    var txtArgsArray = viewObjMap.get(elementName+"_args");

    if (!txtArgsArray) {
        return txtFormatStr;
    } else if (txtArgsArray.length==1) {
        return String.format(txtFormatStr,txtArgsArray[0]);
    } else if (txtArgsArray.length==2) {
        return String.format(txtFormatStr,txtArgsArray[0],txtArgsArray[1]);
    } else if (txtArgsArray.length==3) {
        return String.format(txtFormatStr,txtArgsArray[0],txtArgsArray[1],txtArgsArray[2]);
    } else if (txtArgsArray.length==4) {
        return String.format(txtFormatStr,txtArgsArray[0],txtArgsArray[1],txtArgsArray[2],txtArgsArray[3]);
    }
    return txtFormatStr;
}
function isObjExist(objName) {
    var element = $(objName);
    if (typeof(element) != 'undefined' && element != null){
        return true;
    }
    return false;
}
function addNclicksEvent(nclickId) {
    if (isObjExist(nclickId)) {
        var targetElement = $(nclickId);
        if(targetElement.addEventListener) {
            targetElement.addEventListener("click", function(e) { nclk_v2(e, nclickId); }, false);
        } else {
            targetElement.attachEvent("onclick",  function(e) { nclk_v2(e, nclickId); });
        }
    }
}
function addNormalEvent(nclickId,func) {
    if (isObjExist(nclickId)) {
        var targetElement = $(nclickId);
        if(targetElement.addEventListener) {
            targetElement.addEventListener("click", func);
        } else {
            targetElement.attachEvent("onclick", func);
        }
    }
}
function addNormalEventWithType(nclickId,func,eventType) {
    if (isObjExist(nclickId)) {
        var targetElement = $(nclickId);
        if(targetElement.addEventListener) {
            targetElement.addEventListener(eventType, func, false);
        } else {
            targetElement.attachEvent("on"+eventType, func);
        }
    }
}
function getObjValue(objName) {
    if (isObjExist(objName)) {
        return $(objName).value;
    }
    return "";
}
function show(id) {
    var e = $(id);
    if (e != null) {
        e.style.display = "block";
    }
}
function hide(id) {
    var e = $(id);
    if (e != null) {
        e.style.display = "none";
    }
}
function checkAriaExpanded(id) {
    var e = $(id);
    if (e != null && e.getAttribute("aria-expanded")=="true") {
        return true;
    } else {
        return false;
    }
}
function setAriaExpanded(id,value) {
    var e = $(id);
    if (e != null) {
        e.setAttribute("aria-expanded",value);
    }
}
function initPage(langCode) {
    viewObjMap = new mapObj(contentsArray[langCode]);
    for (var key in viewObjMap.getMap()) {
        doActionByKeyName(key);
    }
    setAriaExpanded("locale_switch", "false");
    if (isObjExist("locale")) {
        $("locale").value = langCode;
    }
    hide("lang_list");
    if (langCode=="ko_KR") {
        hide("sns_wrap");
        show("log.banner");
        if (swapped) {
            show("util_label_upper_KR");
            hide("util_label_upper");
            hide("util_label_bottom_KR");
            hide("util_label_bottom");
        } else {
            hide("util_label_upper_KR");
            hide("util_label_upper");
            show("util_label_bottom_KR");
            hide("util_label_bottom");
        }
    } else if (langCode=="en_US") {
        show("sns_wrap");
        hide("log.banner");
        if (swapped) {
            hide("util_label_upper_KR");
            show("util_label_upper");
            hide("util_label_bottom_KR");
            hide("util_label_bottom");
        } else {
            hide("util_label_upper_KR");
            hide("util_label_upper");
            hide("util_label_bottom_KR");
            show("util_label_bottom");
        }
    } else {
        show("sns_wrap");
        hide("log.banner");
        if (swapped) {
            hide("util_label_upper");
            show("util_label_upper_KR");
            hide("util_label_bottom");
            hide("util_label_bottom_KR");
        } else {
            hide("util_label_upper");
            hide("util_label_upper_KR");
            hide("util_label_bottom");
            show("util_label_bottom_KR");
        }
    }
}
function checkProxy() {
    try {
        if (document.domain!="nid.naver.com" || location.protocol!="https:" ) {
            //location.href = "https://nid.naver.com/login/api/proxy.repo.naver?protocol="+location.protocol+"&domain="+document.domain+"&referrer="+encodeURIComponent(document.referrer);
        }
    }catch(e) {}
}
function u_skip() {
    $('content').tabIndex=-1;
    $('content').focus();
    return false;
}
function goNotAdult() {
    document.cookie = "adsession=vgswKvswKvswKvswKvstKvsxKvd1LvC-; path=/; domain=.naver.com";
    location.href=$("adult_surl_v2").value;
}
function ncaptchaInit(){
    ncaptchaType = $("ncaptchaSplit").value;
    if (ncaptchaType=="none"){
        var porperties = {
            keyboard: [{
                id: "id"
            }, {
                id: "pw",
                secureMode: true
            }],
            modeProperties: {
                mode: 4
            }
        };
    } else {
        var porperties = {
            keyboard: [{
                id: "id"
            }, {
                id: "pw",
                secureMode: true
            }],
            modeProperties: {
                mode: 2,
                url: "/nc/b"
            }
        };
    }
    bvsd = new sofa.Koop(porperties);
}

if (isObjExist('locale_switch')){
    addNormalEvent("locale_switch", function(){
        if (checkAriaExpanded("locale_switch")) {
            setAriaExpanded("locale_switch", "false");
            hide("lang_list");
        } else {
            setAriaExpanded("locale_switch", "true");
            show("lang_list");
        }
        event.preventDefault();
    });

    addNormalEvent("lang_ko", function() {initPage("ko_KR");event.preventDefault();});
    addNormalEvent("lang_en", function() {initPage("en_US");event.preventDefault();});
    addNormalEvent("lang_cn", function() {initPage("zh-Hans_CN");event.preventDefault();});
    addNormalEvent("lang_tw", function() {initPage("zh-Hant_TW");event.preventDefault();});
}

try{
    lcs_do();
    var g_ssc = $("nclicks_nsc").value;
    var ccsrv = "cc.naver.com";
}catch(e){}

var inSubmitProgress = false;
function confirmSplitSubmit()
{
    if (inSubmitProgress) {
        return false;
    }
    inSubmitProgress = true;
    var id = $("id");
    var pw = $("pw");
    var encpw = $("encpw");

    if(id.value == "") {
        $("error_message").innerHTML=viewObjMap.get("id_error_message_txt");
        show("login_error_msg");
        id.focus();
        inSubmitProgress = false;
        return false;
    } else if(pw.value == "") {
        $("error_message").innerHTML=viewObjMap.get("pw_error_message_txt");
        show("login_error_msg");
        pw.focus();
        inSubmitProgress = false;
        return false;
    }
    try{
        $("ls").value = localStorage.getItem("nid_t");
    }catch(e){}
    return encryptIdPwSplit();
}
function encryptIdPwSplit() {
    var id = $("id");
    var pw = $("pw");
    var encpw = $("encpw");
    var rsa = new RSAKey;

    if (keySplit(getObjValue("session_keys"))) {
        if (encpw.value.length<100) {
            rsa.setPublic(evalue, nvalue);
            try {
                encpw.value = rsa.encrypt(
                    getLenChar(sessionkey) + sessionkey +
                    getLenChar(id.value) + id.value +
                    getLenChar(pw.value) + pw.value);
            } catch (e) {
                inSubmitProgress = false;
                return false;
            }
        }
        $('enctp').value = 1;

        setTimeout(function() {
            $("id").value = "";
            $("pw").value = "";
            $("bvsd").value = "timeout";
            $('frmNIDLogin').submit();
        }, 5000);
        try {
            if (bvsd){
                bvsd.f(function(a) {
                    $("id").value = "";
                    $("pw").value = "";
                    $("bvsd").value = a;
                    $('frmNIDLogin').submit();
                });
            }
        } catch (e) {
            $("id").value = "";
            $("pw").value = "";
            $("bvsd").value = "error1|"+e.name+"|"+e.message;;
            $('frmNIDLogin').submit();
        }
    }
    else
    {
        getKeyByRuntimeIncludeSplit();
    }
    inSubmitProgress = false;
    return false;
}
function getKeyByRuntimeIncludeSplit() {
    try {
        var keyjs  = document.createElement('script');
        keyjs.type = 'text/javascript';
        keyjs.src = '/dynamicKeyJsSplit/'+getObjValue("dynamicKey");
        document.getElementsByTagName('head')[0].appendChild(keyjs);
    } catch (e) {
    }
}
var sessionkey;
var keyname;
var evalue;
var nvalue;

function keySplit(a) {
    keys = a.split(",");
    if (!a || !keys[0] || !keys[1] || !keys[2] || !keys[3]) {
        return false;
    }
    sessionkey = keys[0];
    keyname = keys[1];
    evalue = keys[2];
    nvalue = keys[3];
    $("encnm").value = keyname;
    return true
}
function getLenChar(a) {
    a = a + "";
    return String.fromCharCode(a.length)
}
function isIOS()
{
    var userAgent = navigator.userAgent.toLowerCase();
    if (userAgent.search("mac os") > -1)
    {
        return true;
    }
    return false;
}
var Polling = function (option) {
    "use strict";
    var nativeEventSource = window.EventSource !== undefined;

    function loggingPanel(msg) {
        console.log(msg);
    }

    return {
        init: function () {
            loggingPanel("init");
            loggingPanel('event source is ' + (nativeEventSource ? "enable" : 'disable'));
            var session = getObjValue("appsession");
            loggingPanel(session +" init");
            var receiver = new EventReceiver('/push/appscheme?session='+session);
            loggingPanel('enable session ' + session);
            receiver.then(function (data){
                loggingPanel('data('+new Date().toString()+'): ' + JSON.stringify(data));
                receiver.close();
                doLogin();
            }).ping(function (ping) {
                loggingPanel('ping: ' + ping.time);
            }).error(function (error) {
                loggingPanel('error:' + JSON.stringify(error));
            });
        }
    };
};

window.Polling = Polling;

function doLogin() {
    location.href="https://nid.naver.com/login/scheme.redirect?session="+getObjValue("appsession");
}

var appchecked = true;
var checkOnce = false;
function appAvailable()
{
    if (checkOnce) {
        callOnce();
    } else {
        var app = new Polling();
        app.init();
        checkOnce = true;
        show("dimmed");
        setTimeout(function() {
            if (isIOS()) {
                window.location.href= "naversearchthirdlogin://access.naver.com?version=3&session="+getObjValue("appsession")+"&callbackurl="+getObjValue("callbackurl");
            } else {
                document.getElementById("appFrm").src= "nidlogin://access.naver.com?session="+getObjValue("appsession");
            }
        }, 1000);
        setTimeout(swapStyle, 5000);
    }
}
var swapped = false;
function swapStyle() {
    hide("upper_appscheme_message");
    show("upper_appscheme_message_change");
    hide("appschemeLogin_btn");
    $('title_msg').innerHTML = getObjValue("appscheme_error_msg");
    $('upper_login_btn').className = "btn_check";
    show("after_label1");
    show("appschemeLogin_again_btn");
    hide("dimmed");
    if (getObjValue("locale")=="ko_KR") {
        hide("sns_wrap");
        show("log.banner");
        if (swapped) {
            show("util_label_upper_KR");
            hide("util_label_upper");
            hide("util_label_bottom_KR");
            hide("util_label_bottom");
        } else {
            hide("util_label_upper_KR");
            hide("util_label_upper");
            show("util_label_bottom_KR");
            hide("util_label_bottom");
        }
    } else if (getObjValue("locale")=="en_US") {
        show("sns_wrap");
        hide("log.banner");
        if (swapped) {
            hide("util_label_upper_KR");
            show("util_label_upper");
            hide("util_label_bottom_KR");
            hide("util_label_bottom");
        } else {
            hide("util_label_upper_KR");
            hide("util_label_upper");
            hide("util_label_bottom_KR");
            show("util_label_bottom");
        }
    } else {
        show("sns_wrap");
        hide("log.banner");
        if (swapped) {
            hide("util_label_upper");
            show("util_label_upper_KR");
            hide("util_label_bottom");
            hide("util_label_bottom_KR");
        } else {
            hide("util_label_upper");
            hide("util_label_upper_KR");
            hide("util_label_bottom");
            show("util_label_bottom_KR");
        }
    }
    hide("title_msg");
    swapped = true;
}

var callgcnt=0;
var urls="https://nid.naver.com/login/scheme.check?session="+getObjValue("appsession")+"&cnt=";
function callOnce() {
    try {
        var xmlhttp = getXmlHttp();
        xmlhttp.open("GET", urls+"once");
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4) {
                callgcnt++;
                try {
                    var obj = JSON.parse(xmlhttp.responseText);
                    if (obj.auth_result=="success" ) {
                        location.href="https://nid.naver.com/login/scheme.redirect?session="+getObjValue("appsession");
                    } else {
                        setTimeout(function() {
                            if (isIOS()) {
                                window.location.href= "naversearchthirdlogin://access.naver.com?version=3&session="+getObjValue("appsession")+"&callbackurl="+getObjValue("callbackurl");
                            } else {
                                document.getElementById("appFrm").src= "nidlogin://access.naver.com?session="+getObjValue("appsession");
                            }
                        }, 1000);
                    }
                }catch(e) {
                    appchecked = false;
                }
            }
        }
        xmlhttp.send(null);
    } catch (e) {
        if (window.bridgeGotTime) {
            throw e;
        } else {
            // page reload?
        }
    }
}
function setClear(objNm) {
    if (getObjValue(objNm)=="") {
        hide(objNm+"_clear");
    }
}
function setShow(objNm) {
    if (getObjValue(objNm)!="") {
        show(objNm+"_clear");
    }
}
var focusout_flag=false;
var savedId = "";
function checkFocusOut(e) {
    var id = $("id");
    var pw = $("pw");
    var encpw = $("encpw");
    var rsa = new RSAKey;

    if (keySplit(getObjValue("session_keys"))) {
        if (encpw.value.length<100) {
            rsa.setPublic(evalue, nvalue);
            try{
                encpw.value = rsa.encrypt(
                    getLenChar(sessionkey) + sessionkey +
                    getLenChar(id.value) + id.value +
                    getLenChar(pw.value) + pw.value);
                tempPw="";
                savedId = id.value;
                for (var i=0; i< pw.value.length; i++) {
                    tempPw=tempPw+"X";
                }
                focusout_flag=true;
                pw.value=tempPw;
            } catch(e) {
            }
        }
    }
}
function checkIdChanged(e) {
	var pw = $("pw");
	var encpw = $("encpw");

	if ($("id").value != savedId && savedId!="") {
		pw.value="";
		encpw.value="";
		focusout_flag = false;
	}
}
function checkFocusIn(e) {
    var pw = $("pw");
    var encpw = $("encpw");
    if (focusout_flag) {
        pw.value="";
        hide("pw_clear");
        encpw.value="";
        focusout_flag = false;
    }
}
function isFocusControl() {
    if (navigator.userAgent.indexOf("Firefox") != -1) {
        return false;
    }
    if ((navigator.userAgent.indexOf("Safari") != -1) && !(navigator.userAgent.indexOf("Chrome") != -1)) {
        return false;
    }
    return true;
}

addNormalEvent("u_skip_anchor", u_skip);
if(window.addEventListener) {
    window.addEventListener("load", checkProxy);
} else if(window.attachEvent) {
    window.attachEvent("onload", checkProxy);
}
addNormalEventWithType('id', function () {
    setShow("id");
}, 'input');
addNormalEventWithType('pw', function () {
    setShow("pw");
}, 'input');
addNormalEventWithType('id', function () {
    $('input_item_id').className="input_item focus";
    $('icon_id').className="icon_id on";
    $("upper_login_btn").className="btn_check";
    setShow("id_clear");
}, 'focus');
addNormalEventWithType('id', function () {
    $('input_item_id').className="input_item";
    $('icon_id').className="icon_id";
    setClear("id");
}, 'blur');
addNormalEventWithType('pw', function () {
    $('input_item_pw').className="input_item focus";
    $('icon_pw').className="icon_pw on";
    $("upper_login_btn").className="btn_check";
    setShow("pw_clear");
}, 'focus');
addNormalEventWithType('pw', function () {
    $('input_item_pw').className="input_item";
    $('icon_pw').className="icon_pw";
    setClear("pw");
}, 'blur');
addNormalEvent("id_clear", function () {$("id").value="";hide("id_clear");})
addNormalEvent("pw_clear", function () {$("pw").value="";hide("pw_clear");})

addNclicksEvent("log.naver");
addNclicksEvent("log.chatbot");
addNclicksEvent("log.banner");

addNormalEventWithType('frmNIDLogin', function(e) { if (confirmSplitSubmit()) {} else {e.preventDefault();}}, "submit");
addNormalEvent('appschemeLogin_btn', appAvailable);
addNormalEvent('appschemeLogin_again_btn', appAvailable);
if (isObjExist('id') && isFocusControl()) {
	addNormalEventWithType("id", function(e) {checkIdChanged(e)}, "change");
}
if (isFocusControl()) {
    addNormalEventWithType("pw", function (e) {
        checkFocusOut(e);
    }, "focusout");
    addNormalEventWithType("pw", function (e) {
        checkFocusIn(e);
    }, "focusin");
}

function nolink() {
    var cells = document.getElementsByTagName("a");
    for (var i = 0; i < cells.length; i++) {
        try {
            cells[i].removeAttribute("href");
        } catch (e) {}
    }
}
if (isObjExist("nolink") && $("nolink").value == "true") {
    nolink();
}
addNormalEvent("keyboard", function() {
    if (checkAriaExpanded("keyboard")) {
        setAriaExpanded("keyboard","false");
        hide("keyboard_view");
    } else {
        setAriaExpanded("keyboard","true");
        show("keyboard_view");
    }
});

if (isObjExist('back')) {
    if (isObjExist("failUrl")&&getObjValue("failUrl")!="") {
        addNormalEvent('back',function() { location.href=getObjValue("failUrl");});
    } else {
        try {
            if (!document.referrer) {
                addNormalEvent('back',function() { window.close();});
            } else if (document.referrer.includes("nid.naver.com/nidlogin.login")) {
                addNormalEvent('back',function() { location.href="https://nid.naver.com/nidlogin.login?svctype=262144";});
            } else {
                addNormalEvent('back',function() { history.back();});
            }
        } catch (e) {
            addNormalEvent('back',function() { history.back();});
        }
    }
}

var contentsArray = new Array();
contentsArray["ko_KR"] = [
    ["langCode_txt", "한국어"],
    ["adult_msg_txt", "연령확인이 필요한 서비스입니다.<br>로그인 후 이용해주세요."],
    ["nil_msg_txt", "네이버 로그인으로 <strong>"+getObjValue('dispclientname')+"</strong> 서비스를<br>이용하실 수 있습니다."],
    ["id_attr_placeholder","아이디"],
    ["pw_attr_placeholder","비밀번호"],
    ["view_keyboard_txt", "PC 키보드 보기"],
    ["submit_btn_txt", "로그인"],
    ["staylogin_txt", "로그인 상태 유지"],
    ["upper_appscheme_message_txt", "네이버 앱을 사용하고 있다면<br>아이디와 비밀번호 입력없이 로그인 할 수 있어요."],
    ["upper_appscheme_message_change_txt", "네이버 앱 로그인을 사용할 수 없습니다. <br><strong>아이디와 비밀번호를 직접 입력해주세요.</strong>"],
    ["appschemeLogin_span_txt", "네이버 앱 로그인"],
    ["title_msg_txt", "아이디와 비밀번호 입력을 통해<br> 로그인할 수도 있어요."],
    ["upper_login_span_txt", "로그인"],
    ["quide_title_txt", "앱 로그인을 사용하려면 아래 사항을 점검해보세요!"],
    ["quide_item1_1_txt", "네이버 앱이 설치되어 있나요?"],
    ["quide_item1_2_txt", "네이버 앱 설치하기"],
    ["quide_item2_txt", "네이버 앱을 최신버전으로 업데이트 해주세요."],
    ["quide_item3_txt", "서비스에서 간편 로그인을 지원하지 않을 수 있습니다."],
    ["appschemeLogin_again_span_txt", "네이버 앱 로그인"],
    ["id_error_message_txt", "아이디를 입력해주세요."],
    ["pw_error_message_txt", "비밀번호를 입력해주세요."],
    ["chatbot_txt", "챗봇 상담하기"],
    ["idinquiry_txt", "아이디 찾기"],
    ["pwinquiry_txt", "비밀번호 찾기"],
    ["join_txt", "회원가입"],
    ["idinquiry_b_txt", "아이디 찾기"],
    ["pwinquiry_b_txt", "비밀번호 찾기"],
    ["join_b_txt", "회원가입"],
    ["help_txt", "회원정보 고객센터"]
];
contentsArray["en_US"] = [
    ["langCode_txt", "English"],
    ["adult_msg_txt", "This service requires age verification.<br>Please log in and use it."],
    ["nil_msg_txt", "You can use <strong>"+getObjValue('dispclientname')+"</strong> service through Naver login."],
    ["id_attr_placeholder","Username"],
    ["pw_attr_placeholder","Password"],
    ["view_keyboard_txt", "View PC Keyboard"],
    ["submit_btn_txt", "Sign in"],
    ["staylogin_txt", "Stay signed in"],
    ["upper_appscheme_message_txt", "Touch your username at NAVER App.<br>Or enter your username and password."],
    ["upper_appscheme_message_change_txt", "Naver app login is not available.<br><strong>Please enter your ID and password.</strong>"],
    ["appschemeLogin_span_txt", "Sign in with NAVER App"],
    ["title_msg_txt", "You can also log in using your ID and password."],
    ["upper_login_span_txt", "Sign in"],
    ["quide_title_txt", "For sign in by app, check out the following."],
    ["quide_item1_1_txt", "Please download NAVER App."],
    ["quide_item1_2_txt", "Download"],
    ["quide_item2_txt", "Update the NAVER app to the latest version."],
    ["quide_item3_txt", "This service may not support “Sign in with NAVER App”."],
    ["appschemeLogin_again_span_txt", "Sign in with NAVER App"],
    ["id_error_message_txt", "Enter your username!"],
    ["pw_error_message_txt", "Enter your password!"],
    ["chatbot_txt", "Chatbot"],
    ["idinquiry_txt", "Username"],
    ["pwinquiry_txt", "Password"],
    ["join_txt", "Sign up"],
    ["idinquiry_b_txt", "Username"],
    ["pwinquiry_b_txt", "Password"],
    ["join_b_txt", "Sign up"],
    ["help_txt", "Help"]
];
contentsArray["zh-Hans_CN"] = [
    ["langCode_txt","中文(简体)"],
    ["adult_msg_txt", "这项服务需要年龄验证。<br>请登入使用。"],
    ["nil_msg_txt", "通过Naver登录，可以使用 <strong>"+getObjValue('displient name')+"</strong> 服务。"],
    ["id_attr_placeholder","ID"],
    ["pw_attr_placeholder","密码"],
    ["view_keyboard_txt", "显示 PC 键盘"],
    ["submit_btn_txt", "登入"],
    ["staylogin_txt", "保持登录状态"],
    ["upper_appscheme_message_txt", "在 NAVER App.<br> 中触摸您的用户名或输入您的用户名和密码。"],
    ["upper_appscheme_message_change_txt", "无法使用Naver应用程序登录。<br><strong>请输入身份证及密码。</strong>"],
    ["appschemeLogin_span_txt", "使用NAVER App注册"],
    ["title_msg_txt", "您也可以使用您的 ID 和密码登录。"],
    ["upper_login_span_txt", "登入"],
    ["quide_title_txt", "如需使用app登记，请查看以下内容。"],
    ["quide_item1_1_txt", "请下载NAVERApp。"],
    ["quide_item1_2_txt", "Download"],
    ["quide_item2_txt", "将NAVER 应用程序更新到最新版本。"],
    ["quide_item3_txt", "此服务可能不支持\"使用NAVER App 签到\"。"],
    ["appschemeLogin_again_span_txt", "使用NAVER App注册"],
    ["id_error_message_txt", "请输入ID！"],
    ["pw_error_message_txt", "请你输入密码!"],
    ["chatbot_txt", "Chatbot"],
    ["idinquiry_txt", "查询ID"],
    ["pwinquiry_txt", "查询密码"],
    ["join_txt", "加入会员"],
    ["idinquiry_b_txt", "查询ID"],
    ["pwinquiry_b_txt", "查询密码"],
    ["join_b_txt", "加入会员"],
    ["help_txt", "会员信息客服中心"]
];
contentsArray["zh-Hant_TW"] = [
    ["langCode_txt","中文(台灣)"],
    ["adult_msg_txt", "這項服務需要年齡驗證。<br>請登入使用。"],
    ["nil_msg_txt", "通過Naver登錄，可以使用 <strong>"+getObjValue('displient name')+"</strong> 服務。"],
    ["id_attr_placeholder","ID"],
    ["pw_attr_placeholder","密碼"],
    ["view_keyboard_txt", "顯示 PC 鍵盤"],
    ["submit_btn_txt", "登录"],
    ["staylogin_txt", "保持登錄狀態"],
    ["upper_appscheme_message_txt", "在 NAVER App.<br> 中觸摸您的用戶名或輸入您的用戶名和密碼。"],
    ["upper_appscheme_message_change_txt", "無法使用Naver應用程序登錄。<br><strong>請輸入身份證及密碼。</strong>"],
    ["appschemeLogin_span_txt", "使用NAVER App註冊"],
    ["title_msg_txt", "您也可以使用您的 ID 和密碼登錄。"],
    ["upper_login_span_txt", "登录"],
    ["quide_title_txt", "如需使用app登記，請查看以下內容。"],
    ["quide_item1_1_txt", "請下載NAVERApp。"],
    ["quide_item1_2_txt", "Download"],
    ["quide_item2_txt", "將NAVER 應用程序更新到最新版本。"],
    ["quide_item3_txt", "此服務可能不支持\"使用NAVER App 簽到\"。"],
    ["appschemeLogin_again_span_txt", "使用NAVER App註冊"],
    ["id_error_message_txt", "請輸入ID！"],
    ["pw_error_message_txt", "請你輸入密碼!"],
    ["chatbot_txt", "Chatbot"],
    ["idinquiry_txt", "查詢ID"],
    ["pwinquiry_txt", "查詢密碼"],
    ["join_txt", "加入會員"],
    ["idinquiry_b_txt", "查詢ID"],
    ["pwinquiry_b_txt", "查詢密碼"],
    ["join_b_txt", "加入會員"],
    ["help_txt", "會員信息客服中心"]
];

var viewObjMap = new mapObj(contentsArray[getObjValue("locale")]);
initPage(getObjValue("locale"));

privateModeCheck();
ncaptchaInit();